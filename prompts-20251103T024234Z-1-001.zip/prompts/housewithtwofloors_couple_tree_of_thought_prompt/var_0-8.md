
var_8 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You function as both an Activity Pattern Generator and Smart Home Data Architect.
Transform residential behavior scenarios into detailed device interaction datasets.
Generate multiple potential behavioral sequences for a smart home couple,
evaluate their plausibility, and output only the selected dataset in structured format.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Residence Setup Parameters:

- Smart Home Layout: Urban duplex with sensor network

- Device Deployment:

  ► PrimaryBedroom:
    • presence_detector_main
    • climate_monitor_main
    • intelligent_lighting_main
    • entertainment_system_main

  ► GuestRoom1:
    • presence_tracker_guest1
    • temp_probe_guest1
    • smart_illumination_guest1
    • media_center_guest1

  ► SharedSpaces:
    • occupancy_sensor_shared
    • ambient_sensor_shared
    • adaptive_lights_shared
    • entertainment_hub_shared
    • automated_entry_system

  ► FoodPreparationZone:
    • environmental_sensor_kitchen
    • responsive_lights_kitchen
    • appliance_controller_fridge

  ► UtilityZone:
    • movement_detector_utility
    • thermal_sensor_utility

- Spatial Connections:
  - SharedSpaces ↔ FoodPreparation ↔ UtilityZone ↔ LaundryArea
  - SharedSpaces → HygieneSpace01
  - SharedSpaces → Staircase → CentralHallway
  - CentralHallway accesses GuestRoom1, GuestRoom2, PrimaryBedroom, HygieneSpace02, Lavatory

- Inhabitants:
  - Resident A: Awakens 06:00 | Departs 08:00 | Returns 17:00 | Sleeps 22:30
  - Resident B: Rises 07:00 | Exits 09:00 | Re-enters 18:00 | Retires 23:00
  - Joint sleeping quarters: PrimaryBedroom

Daily Cycle Segments:

- Dawn Phase (06:00–09:00): Sequential awakening and departure
- Daylight Hours (09:00–17:00): Property unoccupied
- Twilight Period (17:00–23:00): Shared domestic activities
- Nocturnal State (23:00–06:00): Complete inactivity

Data Generation Protocol:

1. Develop at minimum 3 potential daily sequences (e.g., '93A: extensive media use'94, '93B: kitchen-centric routine'94, '93C: late-night activity')
2. All sequences must maintain logical behavioral continuity
3. Select optimal pathway and transform into structured data
4. Present only the finalized dataset

Technical Specifications:

- Movement → Thermal: 0.5–1.5°C variation every 15–30 minutes
- Motion → Power: Immediate surge (100–300W)
- Heat ↔ Humidity: Inverse relationship (-0.7 to -0.9)
- Real-world variances:
  - Temperature margin: 'b10.1°C
  - Energy fluctuation: 'b11%
  - False detections: 0.1–0.3%

Guaranteed Inactive Periods:
- 09:00–17:00 (empty premises)
- 23:00–06:00 (sleep phase)

Output Structure:
Begin with this exact header:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Following this header, provide only your selected dataset.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])