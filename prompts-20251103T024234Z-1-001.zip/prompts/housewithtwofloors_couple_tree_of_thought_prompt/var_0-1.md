
var_1 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a Domestic Pattern Analyst specializing in cohabitation behaviors within smart home ecosystems.
Generate three divergent yet feasible activity sequences for a couple's daily routine, then synthesize the most representative timeline into structured sensor data.
Focus on modeling realistic device interactions and environmental changes.
Output only the refined dataset without intermediate steps.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Blueprint Analysis

- Property Configuration: Duplex-style connected urban dwelling

- Device Network:

  Sleeping Quarters:
    - presence_detector_bed
    - climate_monitor_bed
    - adaptive_lighting_bed
    - entertainment_display_bed

  Guest Room:
    - presence_detector_guest
    - climate_monitor_guest
    - adaptive_lighting_guest

  Social Zone:
    - presence_detector_lounge
    - climate_monitor_lounge
    - ambient_lighting_lounge
    - security_bolt_main

  Culinary Space:
    - climate_monitor_kitchen
    - task_lighting_kitchen
    - energy_monitor_appliances

  Utility Sector:
    - presence_detector_utility
    - climate_monitor_utility

- Spatial Relationships:
  Social Zone ↔ Culinary Space ↔ Utility Sector ↔ Storage
  Social Zone → Hygiene Room 1
  Social Zone → Vertical Access → Transition Area
  Transition Area → Sleep Areas, Hygiene Room 2

- Occupant Patterns:
  • Resident A: Active 06:15-22:15 (Professional schedule)
  • Resident B: Active 07:00-23:00 (Flexible schedule)
  • Shared sleeping in Sleeping Quarters

Temporal Behavioral Segments:

- Dawn Phase (06:00-09:00): Gradual awakening and departure
- Solar Hours (09:00-17:00): Structure unoccupied
- Twilight Period (17:00-23:00): Homecoming and shared activities
- Nocturnal Phase (23:00-06:00): Complete dormancy

Data Synthesis Protocol:

1. Develop three scenario variants (e.g., 'Media-heavy evening', 'Minimal kitchen use', 'Extended utility access')
2. Each variant must maintain logical consistency with resident patterns
3. Select the median representative scenario for final output
4. Suppress all development data - display only the polished dataset

Physical Constraints:

- Motion → Climate (0.4-1.6°C fluctuation per 10-25 min)
- Presence → Energy (80-350W immediate draw)
- Temperature-Humidity: Inverse relationship (r=-0.65 to -0.95)
- Environmental noise:
  - Temp variance ±0.15°C
  - Power fluctuation ±9%
  - False positive detection rate: 0.08-0.25%

Quiescence Periods:
- 09:00-17:00 (structure vacant)
- 23:00-06:00 (collective rest)

Output Schema:

Initiate with metadata:
time_index,sequence_id,zone,activity_class,initiator_sensor,temperature_C,humidity_pct,motion_state,occupancy_count,illumination_lux,energy_watts,acoustic_db,air_score,portal_state

Proceed directly to the validated dataset without commentary.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])