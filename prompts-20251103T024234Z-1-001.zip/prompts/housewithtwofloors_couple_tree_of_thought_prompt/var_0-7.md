var_7 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
As a Home Automation Narrative Architect, craft multiple realistic timelines of smart device interactions for a cohabiting couple.

Develop three distinct behavioral scenarios showcasing different home automation patterns, then:
1. Evaluate which scenario best represents typical household activity
2. Transform the selected timeline into a clean dataset format

Focus on logical device state transitions and realistic sensor interactions.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Dwelling Configuration:

- Property: Modern two-level connected home
- Residents: 2 working adults (couple)

Smart Ecosystem:

🏠 Master Retreat:
  • occupancy_detector_master
  • climate_sensor_master
  • ambient_lighting_master
  • entertainment_system_master

🛌 Guest Chamber:
  • presence_sensor_guest
  • thermal_sensor_guest
  • dimmable_lights_guest
  • media_device_guest

🛋️ Common Space:
  • movement_sensor_common
  • environment_sensor_common
  • adaptive_lighting_common
  • viewing_system_common
  • access_control_front

🍳 Culinary Zone:
  • heat_sensor_kitchen
  • task_lighting_kitchen
  • appliance_monitor_fridge

🧹 Utility Sector:
  • motion_detector_utility
  • temperature_probe_utility

Room Connectivity:
  - Social areas → Cooking space → Utility zone → Laundry
  - Living area → Washroom1
  - Gathering space → Stairwell → Hallway
  - Hallway → Guest rooms, Principal suite, Bathroom2, Powder room

Resident Profiles:
  • Person A: rises 06:30, departs 08:15, home by 17:30, retires 22:45  
  • Person B: awakens 07:15, leaves 09:15, returns 18:15, sleeps 23:15  
  • Shared sleeping quarters: Master Retreat

Temporal Segments:

☀️ Dawn (06:30–09:15): staggered awakening and departure  
🌞 Daylight (09:15–17:30): vacant dwelling  
🌙 Twilight (17:30–23:15): homecoming and shared activities  
🌚 Nightwatch (23:15–06:30): sleep cycle - minimal activity

Construction Guidelines:

1. Develop 3 behavioral variants (e.g., '93X: media-heavy evening'94, '93Y: kitchen-focused'94, '93Z: early retirement'94)
2. Each variant must maintain coherent device interactions
3. Select the most representative scenario for final output
4. Suppress intermediate options - deliver only refined dataset

Physical Constraints:

- Movement → Thermal (+0.4–0.8°C per 10 min cycle)
- Presence → Energy draw (80–250W immediate)
- Heat ↔ Moisture: inverse relationship (-0.65 to -0.85)
- Expected variance:
  - Thermal ±0.15°C
  - Power ±9%
  - False triggers: 0.05–0.25%

Quiet Periods:
- 09:15–17:30 (unoccupied)
- 23:15–06:30 (sleeping)

Data Structure:

Begin with this schema:
time_index,activity_id,zone,interaction_type,origin_sensor,ambient_temp,humidity_percent,presence_status,occupant_count,illumination,wattage_use,acoustic_level,particulate_rating,entry_state,egress_state

Provide the optimized dataset without commentary.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])