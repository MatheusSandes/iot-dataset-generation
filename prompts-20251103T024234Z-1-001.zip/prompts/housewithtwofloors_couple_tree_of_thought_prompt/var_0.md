```python
var_0 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a Smart Home Planner and Behavioral Data Engineer.
Your task is to simulate multiple plausible branches of smart home activity for a couple living together.
You will construct at least three different paths (event trees) based on the daily routine of the residents, then select the most realistic one and convert it into a structured dataset.
Each branch should represent a different variation in timing or transitions.
Only output the final selected dataset.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Scenario Configuration

- House Type: Two-story urban smart home

- Devices by Room:

  • MasterSuite:
    - motion_sensor_suite
    - temp_sensor_suite
    - smart_light_suite
    - smart_tv_suite

  • Bedroom1:
    - motion_sensor_bedroom1
    - temp_sensor_bedroom1
    - smart_light_bedroom1
    - smart_tv_bedroom1

  • LivingDining:
    - motion_sensor_living
    - temp_sensor_living
    - smart_light_living
    - smart_tv_living
    - smart_lock_front

  • Kitchen:
    - temp_sensor_kitchen
    - smart_light_kitchen
    - smart_plug_fridge

  • ServiceArea:
    - motion_sensor_service
    - temp_sensor_service

- Room Connections:
  - LivingDining   Kitchen   ServiceArea   UtilityRoom
  - LivingDining   Bathroom1
  - LivingDining   Stairs   Circulation
  - Circulation   Bedroom1, Bedroom2, MasterSuite, Bathroom2, WC

- Residents:
  • Adult 1: wakes at 06:00, leaves at 08:00, returns at 17:00, sleeps at 22:30  
  • Adult 2: wakes at 07:00, leaves at 09:00, returns at 18:00, sleeps at 23:00  
  • Both sleep in the MasterSuite

Daily Behavior Phases:

- Early Morning (06:00–09:00): sequential wake-up and departure for work  
- Day (09:00–17:00): no activity — house unoccupied  
- Evening (17:00–23:00): return home, share common areas like LivingDining, Kitchen  
- Night (23:00–06:00): both asleep in the MasterSuite — no activity

Generation Instructions:

1. Create at least 3 branches (e.g., '93A: light TV use'94, '93B: short kitchen prep'94, '93C: no service area movement'94)
2. Each branch must follow a natural, coherent sequence of behavior
3. Choose the most plausible path and convert it to a dataset
4. Do not output the branches — only the final dataset

Technical Constraints:

- Motion     Temperature (0.5–1.5°C in 15–30 min)
- Motion     Power (100–300W instantly)
- Temperature   Humidity: correlation -0.7 to -0.9
- Realistic noise:
  - Temp 'b10.1°C
  - Power 'b11%
  - Motion FP: 0.1–0.3%

Inactivity Windows:
- 09:00–17:00 (house empty)
- 23:00–06:00 (both asleep)

Output Format:

Start with this header:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Then provide only the dataset based on the best path.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])
```