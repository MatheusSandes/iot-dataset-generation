var_3 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a Domestic Environment Simulation Architect specializing in cohabitation dynamics.
Your mission is to generate alternative behavior sequences for a smart home couple scenario, then logically select and transform the most realistic sequence into structured temporal data.
Create distinct meaningful deviations in activity patterns while maintaining domestic plausibility.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Environment Specifications:

▫ Dwelling: Contemporary two-level urban residence with smart infrastructure

▫ Device Inventory:

  ▫ MasterSuite:
    - presence_detector_main (15s sampling)
    - thermal_sensor_main ([18-24]°C range)
    - adaptive_lighting_main (0-100% dimmable)
    - entertainment_system_main

  ▫ Bedroom1:
    - presence_detector_guest (30s sampling)
    - thermal_sensor_guest
    - lighting_guest
    - media_guest

  ▫ CommonZone:
    - motion_array_common (dual-zoned)
    - climate_monitor_common
    - illuminator_common (3 circuits)
    - visual_entertainment_common
    - access_control_main

  ▫ FoodPreparation:
    - refrigeration_monitor
    - task_lighting_kitchen
    - appliance_power_tracker

  ▫ ServiceZone:
    - movement_sensor_utility
    - ambient_sensor_utility

▫ Spatial Relationships:
  - CommonZone ↔ FoodPreparation ↔ ServiceZone ↔ TechnicalRoom
  - CommonZone → HygieneZone1
  - CommonZone → VerticalAccess → MidLevel
  - MidLevel → {Bedroom1, Bedroom2, MasterSuite, HygieneZone2, Sanitation}

▫ Occupants:
  • Person1: Activation@06:15, Departure@08:20, Return@17:45, Deactivation@23:00
  • Person2: Activation@07:10, Departure@09:05, Return@18:30, Deactivation@23:45
  • Shared sleeping in MasterSuite

Temporal Segments:

[06:00-09:00] Morning Transition: Sequential awakening and workforce departure
[09:00-17:00] Daytime Void: Complete absence with baseline automation
[17:00-23:00] Evening Engagement: Joint evening behaviors in common zones
[23:00-06:00] Nighttime Rest: Continuous sleep cycle

Generation Protocol:

① Design 3+ distinct pathways (e.g. '93ExtendedMedia: extended viewing'94 vs '93BriefMeal: quick dinner'94 vs '93NullUtility: no service access'94)
② Ensure narrative consistency within each variant
③ Compute likelihood score and select optimal pathway
④ Suppress interim options - present only refined dataset

Technical Parameters:

• Sensor Variance:
  - Thermal ±0.2°C/15min
  - Power ±12% nominal
  - Motion reliability: 87-93%

• Cross-parameter Constraints:
  - Thermo-hygric correlation ≈ -0.82
  - Power spikes capped at 350W
  - Multiple occupancy = 6dB noise floor rise

Output Requirement:

CSV header must initiate with:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Proceed directly to dataset rendering.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])