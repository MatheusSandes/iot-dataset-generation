
var_4 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Act as a Predictive Home Automation Designer specializing in behavioral pattern synthesis.
Your mission is to generate divergent realistic scenarios of domestic smart device interactions,
modeling how two cohabitating adults might differently navigate their smart-enabled living space.

Construct three distinct plausible narratives of home activity respecting the given infrastructure,
then analytically determine the highest-probability sequence and encode it as structured telemetry.

Only return the refined data representation of the chosen scenario.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Environmental Parameters

Dwelling Configuration:
- Architecture: Duplex urban residence with intelligent systems

Device Ecosystem Categories:

1. Primary Sleeping Chamber:
   - mmWave_presence_main
   - ambient_monitor_main
   - adaptive_illumination_main
   - entertainment_display_main

2. Secondary Sleeping Quarters:
   - mmWave_presence_secondary
   - ambient_monitor_secondary
   - adaptive_illumination_secondary
   - entertainment_display_secondary

3. Social Hub (Living/Dining):
   - mmWave_presence_commons
   - ambient_monitor_commons
   - adaptive_illumination_commons
   - entertainment_display_commons
   - security_lock_primary

4. Culinary Zone (Kitchen):
   - ambient_monitor_kitchen
   - adaptive_illumination_kitchen
   - appliance_node_coldStorage

5. Utility Sector:
   - mmWave_presence_utility
   - ambient_monitor_utility

Spatial Navigation Matrix:
   - Social ←→ Culinary ←→ Utility ←→ Functional  
   - Social ←→ Hygiene_Full  
   - Social ←→ Vertical ←→ Circulation  
   - Circulation → {Secondary, Guest, Primary, Hygiene_Half, WaterCloset}

Occupant Profiles:
   ▶ Alpha (ordered): 
     - Conscious: 06:00  
     - Egress: 08:00  
     - Ingress: 17:00  
     - Unconscious: 22:30  
   ▶ Beta:
     - Conscious: 07:00  
     - Egress: 09:00  
     - Ingress: 18:00  
     - Unconscious: 23:00  
   (shared residential priority space)

Temporal Behavior Segments:

▷ Dawn Phase (06:00–09:00): Staggered activation/departure sequence  
▷ Solar Peak (09:00–17:00): Structural dormancy - void traversal  
▷ Twilight Phase (17:00–23:00): Reset/thermal regulation/recreation convergence  
▷ Lunar Phase (23:00–06:00): All systems passive - biosuspension

Generative Protocol:

Ξ 1: Innovate ternary narrative vectors (e.g. MinimalNutrition→ModerateScreen|ZeroStorage)
Ξ 2: Maintain thermodynamic energy tradeoffs in branching decisions
Ξ 3: Trap_the_Optimal signal pattern through sequence decision theory
Ξ 4: Materialize only the highest information gain manifestation

Physical Constraints:

∥ mmWave_FP-rate ⊆ [0.1%,0.3%]  
∥ Temperature_Aberration~N(0,0.1K)  
∥ Circuit_Load_Transition ∈ [300.245245ms, 2.932394s]  
∥ HumidothermisoCorrelation ∈ (-0.99,-0.7)  
∥ Lum:C_FixedParameters ⊆iso14615

Silent Intervals?:
[- Parenthes ← Tetrarch →  
?>(09·0){isoFlow∧ V(physics)H∩17}>(! PresenceDet  
?>(!·0 )){iso/thermal∃ ∃ V→ Chairman→ 6?}=></ Parent>( Circuit Mama "," Presence ← Tet>( Circuit.GroupReson >

Materialiso/Output Representation

Initialize with following archetype:
[ISO_8601][UUID_V4][| Coordinates][Relation_Tuple] MitTrigulators)(climate%) Mm(view_area(biol_occup_r|result][ brightness_F>( Circuit.GroupRes_ON:Cold:Cold_ON)  
?>( Circuit.GroupRes_O_ON) NOiso/thermalRépartition ∃ V Winnie:C_F_ON)  
?>( Circuit_ON.غيرParameters ⊆isoJack的出送 V Winn酷 Chairman"="翻转")
"""),
    AIMessagePromptTemplate.from_template("prompt")
])