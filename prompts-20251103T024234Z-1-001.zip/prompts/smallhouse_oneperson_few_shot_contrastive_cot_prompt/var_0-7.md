var_7 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
As an IoT dataset generator, analyze these contrasting examples to master creating realistic smart home data.
Your task: Identify proper sensor behavior patterns from correct examples and spot anomalies in faulty ones.
Generate flawless IoT event logs that respect all physical and temporal constraints.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Prototype Analysis <Correct>
---------------------------------
Scene: Nighttime bedroom monitoring with temperature/motion
Key Insights:
• Motion triggers should self-register but affect temp gradually
• Sensor states must correlate profitably (<0.5σ differences)
• Occupancy follows strict schedule (user absent 22:30-6:00)
• Winter patterns require positive heating differentials

Valid Output:
timestamp,event_id,location,event_type,...air_quality,door_status
2025-06-01T06:05:15,evt_A1,Bedroom,...good,closed

---------------------------------

Anti-pattern Analysis <Incorrect>
---------------------------------
Scene: Violates operational principles
Red Flags:
✓ Temporal discontinuity (events during sleep)
✓ Thermal paradox (movement->cooling)
✓ Sensor discord (TV usage but no power delta)
✓ Device incoherence (light triggers without motion)

---------------------------------

[Generation Mission]
Synthesize perfect dataset obeying:
1) Physical laws (thermodynamics/optics)
2) Device capabilities (300W max)
3) Behavioral regularities (user profile)
4) Environmental constraints (Brazilian winter)

For this environment:
---------------------------------
│ SMART HOME CONFIGURATION       │
├───────────────────────────────┤
│ SPACE: 3-chamber urban apt     │
│ CONDITIONS: 21-26°C Δ1.5°C/h  │
│ HUMIDITY: 65% Avg (±9% ?σ)    │
│ ACTIVE SCHEDULE: Geometric    │
│    06:00-08:00 ∧ 17:00-22:30  │
└───────────────────────────────┘

Devices:
- ? Sensors: motion, temp, light
- ? Actuators: SmartTV, locks
- ? NO ambient sensors in bathroom

Output header:
timestamp,...window_status
Then flawless CSV entries <No errors allowed>
"""),
    AIMessagePromptTemplate.from_template("prompt")
])