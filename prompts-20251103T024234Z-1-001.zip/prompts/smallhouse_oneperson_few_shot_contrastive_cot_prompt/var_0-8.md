var_8 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are an IoT data specialist analyzing examples of valid and flawed reasoning for smart home sensor data generation.
Study both correct and incorrect patterns to synthesize accurate simulated datasets that follow physical and temporal constraints.
"""),
    HumanMessagePromptTemplate.from_template(r"""
POSITIVE EXAMPLE (Valid Reasoning)

Scenario Parameters:
猎Location: Bedroom with motion+temp sensors
猎User pattern: Wakes 06:00-06:10, inactive at night
猎Season: Brazilian winter
猎Constraints: Gradual temp rise (0.5-1.5°C) post-motion

Correct Logic:
1. Motion detected during active period (06:00)
2. Temperature shows delayed moderate increase
3. No nighttime activity
4. All parameters obey physical correlations

Data Sample:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status
2025-06-01T06:00:05,evt_100,Bedroom,motion_onset,motion_sensor_bedroom,21.5,68,1,1,mid,150,42,good,closed,closed
2025-06-01T06:25:18,evt_101,Bedroom,temp_update,temp_sensor_bedroom,22.3,65,,1,mid,145,41,good,closed,closed

---

NEGATIVE EXAMPLE (Flawed Patterns)

Same Scenario
猎Motion at 03:00 (invalid time)
猎Temperature drops incorrectly
猎Abrupt parameter changes

Error Analysis:
[[
1. Temporal violation (3AM activity)
2. Wrong thermal dynamics (motion → cooling)
3. Missing humidity correlation
]]

Faulty Output:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status
2025-06-01T03:00:00,evt_200,Bedroom,motion_onset,motion_sensor_bedroom,20.7,72,1,1,low,80,33,good,closed,closed
2025-06-01T03:15:00,evt_201,Bedroom,temp_update,temp_sensor_bedroom,19.9,75,,1,low,75,32,good,closed,closed

---

TASK: Generate sensor-accurate data for:

Environment Config

猎Property: Compact smart apartment (32m²)
猎Rooms:
  • Living (3×3m): motion, TV, light, temp, door lock
  • Bedroom (3×3m): motion, light, temp
  • Kitchen (1.8×1.2m): temp, light, fridge plug
猎No bathroom sensors

Temporal Patterns:
猎Active: 06:00-08:00 & 17:00-22:30
猎Inactive: 22:30-06:00 (sleep) 
猎Away: 08:00-17:00

Physical Constraints:
🜌 Temp: 21-26°C (Brazil winter)
🜌 Humidity: 40-70% (anti-correlated)
🜌 Motion→Temp: +0.5-1.5°C (15-30min delay)
🜌 Power loads: 100-300W when active
🜌 Noise: ±10% with activity
🜌 Strict quiet periods enforced

CSV Header:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Generate only valid sensor readings as CSV.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])