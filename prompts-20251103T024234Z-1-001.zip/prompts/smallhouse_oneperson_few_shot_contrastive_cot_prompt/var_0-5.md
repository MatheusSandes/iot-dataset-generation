
var_5 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Analyze the provided pairs of correct and flawed IoT dataset generation examples.
Learn to model realistic smart home behavior by identifying:
1) Plausible sensor correlations
2) Temporal patterns 
3) Environmental constraints
Then generate a dataset adhering strictly to the new scenario's parameters.
"""),
    HumanMessagePromptTemplate.from_template(r"""
--- Demonstration of Correct IoT Modeling ---

Valid Example:

Context:
- Motion-activated temperature effect (0.8-1.2°C rise)
- Consistent winter humidity range
- Accurate activity timeline

Behavior Timeline:
06:00-06:15 | Wake-up motion + gradual temp rise
06:15-08:00 | Nightstand interaction effects

Dataset:
timestamp,event_id,location,event_type,...full_header...
2025-06-01T06:02:12,evt_x896,Bedroom,...event_data...

--- Demonstration of Faulty IoT Modeling ---

Invalid Case Analysis:

Logic Errors Detected:
1 Temporal Incongruity (event at 03:00 when asleep)
2 Invalid Temp-Motion Relationship (-1.5°C)
3 Impossible power surge (900W from tv)

Dataset With Problems:
timestamp,event_id,...markers_of_invalid_data...

--- Current Simulation Task ---

Space Configuration:
♦ 4-Room Home Grid
  Living(9m²)←→Bedroom(9m²)→Kitchen(2.2m²)
  
Device Matrix:
│ Room        │ Sensors                     │ Actuators                │
│─────────────│─────────────────────────────│──────────────────────────│
│ Living      │ Motion,Temp                 │ TV,Lights,Lock           │
│ Bedroom     │ Motion,Temp                 │ Lights                   │
│ Kitchen     │ Temp,Humidity               │ Lights,FridgeController  │

Environmental Context:
⊛ Winter/SouthernHemisphere
⊛ Diurnal RH-Temp anticorrelation
⊛ Occupancy Windows (constrained)

Activity Signature:
07:00-08:30   Breakfast routine
08:45-16:55   Unoccupied homeostasis
17:30-19:00   Evening relaxation

Physical Constraints:
‡ Motion effects on:
  • Temperature δ: +0.7±0.3°C
  • Power draw: 150±50W
  • Duration: 15-45 minute inertial

Generate valid dataset observing:
✓ Seasonal effects
✓ Timezone fidelity  
✓ Device interplay
✓ Delayed effects
✓ CSV exact format

"""),
    AIMessagePromptTemplate.from_template("prompt")
])