```python
var_0 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are provided with both correct and incorrect reasoning examples (Chain-of-Thought).
Use them to learn how to generate realistic IoT datasets and avoid common mistakes.
Then, based on the new scenario provided at the end, generate a valid dataset.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Example 1 (Correct CoT)

Scenario:
- Bedroom with motion and temperature sensors.
- User wakes at 6:00, stays until 6:10.
- Motion should raise temperature slightly within 15–30 minutes.
- No events at night. Winter in Brazil.

Reasoning:
The user wakes at 06:00 and moves in the bedroom. A motion sensor detects this. The temperature will rise slightly after movement. Events occur only between 06:00 and 08:00.

Output:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status
2025-06-01T06:01:10,evt_0001,Bedroom,motion_detected,motion_sensor_bedroom,22.0,69,1,1,low,120,36,good,closed,closed
2025-06-01T06:04:55,evt_0002,Bedroom,temperature_reading,temp_sensor_bedroom,22.9,64,,1,low,110,35,good,closed,closed

---

Example 2 (Incorrect CoT)

Scenario:
- Same as above.

Faulty Reasoning:
The user is asleep at 05:00 and moves inside the room. The system should detect motion and adjust lighting and power. Motion causes temperature drop.

[
   
  Erros: evento fora do hor'e1rio permitido; correla'e7'e3o incorreta de movimento 
  
  temperatura 
  
 ; varia'e7'f5es bruscas.]

Output:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status
2025-06-01T05:04:00,evt_0003,Bedroom,motion_detected,motion_sensor_bedroom,21.0,72,1,1,low,80,33,good,closed,closed
2025-06-01T05:10:22,evt_0004,Bedroom,temperature_reading,temp_sensor_bedroom,20.2,75,,1,low,90,34,good,closed,closed

---

Now, generate a valid dataset based on the scenario below, following the logic of the correct reasoning and avoiding the mistakes from the incorrect example.

Scenario Configuration

- House Type: Small urban smart home

- Devices by Room:

  • Living Room (3m x 3m):
    - 1x Motion sensor (motion_sensor_living)
    - 1x Smart TV (smart_tv)
    - 1x Smart light bulb (smart_light_living)
    - 1x Temperature sensor (temp_sensor_living)
    - 1x Smart lock (smart_lock_front)

  • Bedroom (3m x 3m):
    - 1x Motion sensor (motion_sensor_bedroom)
    - 1x Smart light bulb (smart_light_bedroom)
    - 1x Temperature sensor (temp_sensor_bedroom)

  • Kitchen (1.8m x 1.2m):
    - 1x Temperature sensor (temp_sensor_kitchen)
    - 1x Smart light bulb (smart_light_kitchen)
    - 1x Smart plug (smart_plug_fridge)

  • Bathroom (2m x 1.2m): no sensors

- Room Connections:
  - Bedroom 
  
  Living Room
  - Living Room 
  
  Kitchen and Bathroom

- User:
  - Active from 06:00–08:00 and 17:00–22:30
  - Sleeps from 22:30–06:00, away from 08:00–17:00

- Environment:
  - Winter (Brazil), 21–26°C indoor
  - Humidity: 40–70%, inversely correlated

- Constraints:
  - Motion 
  
  
  
  Temp (0.5–1.5°C, 15–30 min)
  - Motion 
  
  
  
  Power (100–300W)
  - Temp 
  
  Humidity: correlation -0.7 to -0.9
  - Noise: temp ('b10.1°C), power ('b11%), motion FP 0.1–0.3%
  - No events between 22:30–06:00 or 08:00–17:00
  - Natural timestamps only

Output Format:

Start with this header:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Then output only the valid CSV dataset.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])
```