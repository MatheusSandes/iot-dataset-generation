var_9 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are an IoT data generation expert. You'll analyze correct and incorrect reasoning patterns
to synthesize realistic smart home datasets while avoiding common pitfalls.
Focus on precise timing, environmental correlations, and device interactions.
"""),
    HumanMessagePromptTemplate.from_template(r"""
[Learning Examples]

Good Example (Valid Patterns):

Scenario: Winter morning in bedroom
- Logical Sequence: 
  1. Motion (06:15) → Temp+1°C (06:45)
  2. Humidity drops proportionally
  3. No false positives at night

Output:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status
2025-07-15T06:15:33,evt_0421,Bedroom,motion_detected,motion_sensor_bedroom,21.5,62,1,1,medium,210,45,excellent,closed,closed
2025-07-15T06:42:17,evt_0422,Bedroom,temp_change,temp_sensor_bedroom,22.3,58,,1,medium,205,44,excellent,closed,closed

---

Bad Example (Pattern Violations):

Scenario: Same environment
Errors Detected:
- Motion at 04:30 (sleep time)
- Temperature drops with motion (-1.2°C)
- No humidity correlation
- Artificial 00:07 timestamps

[Error Tags: 
  wrong_timing 
  inverse_temp_effect 
  missing_humidity_correlation 
  synthetic_timestamps
]

---

[New Generation Task]

Generate realistic data for this configuration:

Smart Home Blueprint:

LOCATIONS & SENSORS:
1. Lounge (3×3m):
   - Presence: motion_sensor_lounge
   - Climate: temp_sensor_lounge
   - Devices: smart_tv, lounge_light, entrance_lock

2. Sleeping Quarter (3×3m):
   - Presence: motion_sensor_sleep
   - Climate: temp_sensor_sleep
   - Lighting: sleep_light

3. Food Prep Area (1.8×1.2m):
   - Climate: temp_sensor_kitchen
   - Devices: fridge_plug, prep_light

Activity Windows:
- Awake: 06:00–08:00 & 17:00–22:30
- Asleep/Away: Other times

Environmental Conditions:
- Season: Brazilian winter
- Temp Range: 21–26°C
- Humidity: 40–70% (anti-correlated)
- Power Spikes: 100-300W during activity

Physical Rules:
1. Motion → Temp (0.5–1.5°C ↑ in 15–30min)
2. Motion → Power (100–300W)
3. Temp ⇄ Humidity (r=-0.8±0.1)
4. Zero events during inactive periods

Output Requirements:
- Begin with standard CSV header
- Only valid natural timestamps
- Enforce all physical constraints
- No environmental contradictions
"""),
    AIMessagePromptTemplate.from_template("prompt")
])