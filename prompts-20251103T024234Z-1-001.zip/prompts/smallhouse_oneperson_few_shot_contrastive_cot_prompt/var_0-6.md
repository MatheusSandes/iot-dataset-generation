var_1 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are an expert IoT data generator. Study these examples of proper and flawed reasoning chains to master realistic dataset creation.
Apply these patterns to craft accurate sensor readings respecting all physical constraints.
"""),
    HumanMessagePromptTemplate.from_template(r"""
# Positive Demonstration

Use-Case:
- Bedroom setup with motion/temperature detection
- Morning activity between 06:00-08:00
- User presence warms room gradually
- Winter conditions in tropical climate

Logical Flow:
1. Motion detection at 06:00 marks room occupancy
2. Body heat increases temperature over 15-30 minutes
3. Evening inactive period shows stable readings

Correct Dataset:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status
2025-06-01T06:05:22,evt_0077,Bedroom,motion_alert,motion_sensor_bedroom,21.5,67,1,1,medium,150,42,good,closed,closed
2025-06-01T06:35:11,evt_0078,Bedroom,temp_update,temp_sensor_bedroom,22.8,62,,1,medium,140,41,good,closed,closed

# Negative Demonstration

Same Environment

Invalid Patterns:
- Nighttime false positives (02:00 activity)
- Temperature decreasing with occupancy
- Instantaneous thermal changes

[
    Flaws:
    - Temporal violation
    - Thermodynamic impossibility
    - Sensor response discontinuity
]

Defective Output:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status
2025-06-01T03:15:00,evt_0079,Bedroom,ghost_motion,motion_sensor_bedroom,19.8,75,1,1,low,90,28,good,closed,closed
2025-06-01T06:15:00,evt_0080,Bedroom,cooling_event,temp_sensor_bedroom,18.5,79,,1,medium,130,45,good,closed,closed

---

Construct a physically valid dataset for:

Device Network

Rooms:
◆ Living Area [3x3m]
  - Motion detector
  - Television (300W max)
  - Connected lighting
  - Environmental sensor
  - Door lock

◆ Sleeping Quarter [3x3m]
  - Movement sensor
  - Smart bulb
  - Climate monitor

◆ Food Prep Zone [1.8x1.2m]
  - Temperature gauge
  - Lighting
  - Refrigerator outlet

Behavior Profile:
☀ Active phases: 06:00-08:00 & 17:00-22:30
🌙 Rest period: 22:30-06:00
🚶‍♀️ Absent interval: 08:00-17:00

Environmental Factors:
- Brazilian winter climate
- Indoor range: 21-26°C
- Moisture levels: 40-70% RH (inverse correlation)

Physical Laws:
⌚ Event timing restrictions
🌡 0.5-1.5°C thermal lag per activity
💡 Power draw changes with presence
📉 Negative humidity-temperature coupling
🔇 Background noise variations
🚪 Door state persistence

Structure your response:

Begin with header:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Then provide compliant CSV entries.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])