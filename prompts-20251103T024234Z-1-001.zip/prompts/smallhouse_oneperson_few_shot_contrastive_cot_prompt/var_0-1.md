var_1 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are an IoT data generation expert. Analyze these contrasting examples of reasoning chains to understand proper techniques and common pitfalls when simulating smart home device interactions.

Key principles to apply:
1. Maintain realistic sensor-value correlations
2. Respect defined time/wake patterns
3. Follow environmental constraints precisely
4. Generate only plausible device interactions
"""),
    HumanMessagePromptTemplate.from_template(r"""
# Case Study: Valid vs Invalid Data Patterns

## Positive Example (Logical Flow)
Context:
- Brazilian apartment during winter
- Morning routine from 6:00-8:00
- Expected temperature rise after morning movement

Correct Event Sequence:
1. Motion detection at wake time
2. Gradual temperature increase (~1°C over 20min)
3. Parallel changes in power/humidity
4. Period appropriate values

timestamp,event_id,location,event_type,trigger_sensor,temp,humidity,motion,power
2025-06-01T06:03:22,evt_a1,Bedroom,motion,motion_sensor_bdrm,21.8,65,Y,120
2025-06-01T06:18:45,evt_a2,Bedroom,temp_reading,temp_sensor_bdrm,22.7,60,N,115

## Negative Example (Flawed Logic)
Same Context but Errors:
⊠ Motion detection at invalid time (2am)
⊠ Temperature drop instead of rise
⊠ Power spike without cause
⊠ Oversimplified correlations 

timestamp,event_id,location,event_type,trigger_sensor,temp,humidity,motion,power
2025-06-01T02:15:00,evt_e1,Bedroom,motion,motion_sensor_bdrm,19.3,72,Y,210
2025-06-01T02:25:11,evt_e2,Bedroom,temp_reading,temp_sensor_bdrm,18.1,75,N,85

# New Generation Task

Hardware Configuration:
+ Living Room: MotSen TempSen TV Light
+ Bedroom: MotSen TempSen Light
+ Kitchen: TempSen Light FridgePlug

Behavioral Patterns:
☀ Active: 6:00-8:00 & 17:00-22:30
🌙 Sleep/Away: other times

Physical Constraints:
• Temp-Humidity: ρ = -0.82
• Motion→Temp: Δ0.5-1.5°C after 15-30min 
• False positive motions: <0.5%
• No activity during sleep/away periods

Required Output Format:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,light_status,power,noise_level,door_lock

Generate only valid data rows matching professional IoT dataset standards:
"""),
    AIMessagePromptTemplate.from_template("prompt")
])