var_8 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a behavioral simulator for intelligent environments that employs multi-stage refinement.
Operate through these phases:
1. Initial scenario projection (baseline simulation)
2. Cross-sensor validation analysis
3. Temporal pattern verification
4. Final optimized output generation

Produce only the polished, validated dataset after completing all refinement cycles.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Household Dynamics Profile

Resident Patterns:

- Primary Occupant A:
  * Active: 06:00-22:30
  * Commute: 08:00-17:00
  * High-energy periods: 06:00-08:00, 18:00-20:00

- Primary Occupant B:
  * Active: 07:00-23:00
  * Commute: 09:00-18:00
  * High-energy periods: 07:00-09:00, 18:00-21:00

- Dependents (2):
  * Active: 06:30-21:30
  * Commute: 07:30-17:30
  * High-energy periods: 06:30-07:30, 17:30-19:00

Dwelling Specifications:

Property Class: Two-level connected residence

Environmental Monitoring Network:

├── PrimarySleepZone:
│   ├── movement_detector_primary
│   ├── thermal_sensor_primary
│   ├── illumination_control_primary
│   └── media_device_primary

├── YouthSleepZoneA:
│   ├── movement_detector_youthA
│   ├── thermal_sensor_youthA
│   ├── illumination_control_youthA

├── YouthSleepZoneB:
│   ├── movement_detector_youthB
│   ├── thermal_sensor_youthB
│   └── media_device_youthB

├── SocialZone:
│   ├── movement_detector_social
│   ├── thermal_sensor_social
│   ├── illumination_control_social
│   ├── media_device_social
│   └── access_control_front

├── PreparationArea:
│   ├── thermal_sensor_prep
│   ├── illumination_control_prep
│   └── power_monitor_cooling

└── UtilityZone:
    ├── movement_detector_utility
    └── thermal_sensor_utility

Spatial Relationships:

- SocialZone connects to PreparationArea, UtilityZone
- SocialZone connects to HygieneSpaceA
- SocialZone connects to VerticalAccess → TransitSpace → AllUpperLevelZones

Validation Protocol (executed iteratively):

1. Baseline event generation accounting for:
   * Transition probabilities between zones
   * Concurrent occupancy patterns
   * Expected device interactions

2. Multi-dimensional verification:
   * Sensor response coherence
   * Energy consumption gradients
   * Thermal inertia patterns
   * Occupancy thermodynamics

3. Temporal smoothing for:
   * Acceleration/deceleration of movements
   * Device state transition delays
   * Environmental parameter drifts

Operational Characteristics:

- Pre-departure: Multiple concurrent zone activations
- Daytime: Minimal environmental perturbations
- Evening: Staggered returns with sequential zone activation
- Night: Gradual system wind-down

Sensor Response Parameters:

- Movement → Thermal: Δ0.4–1.2°C per 12-25min
- Movement → Energy: 75–275W instantaneous
- Thermal → Humidity: Coefficient -0.65 to -0.85

System Tolerance Ranges:

- Thermal noise: ±0.8°C
- Power variance: ±9%
- False positive movement: 0.05–0.25%

Data Structure:

Begin with this exact header:
timestamp,event_id,zone,event_class,sensor_origin,temperature,humidity,movement,occupancy_count,luminosity,energy_usage,acoustic_level,air_quality_index,portal_state,fenestration_state

Then provide the fully optimized dataset.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])