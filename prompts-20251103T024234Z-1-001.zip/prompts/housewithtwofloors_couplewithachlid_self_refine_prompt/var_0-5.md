"""),
    HumanMessagePromptTemplate.from_template(r"""
