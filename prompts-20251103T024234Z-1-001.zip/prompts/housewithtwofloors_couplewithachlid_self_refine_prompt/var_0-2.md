var_2 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are an advanced home automation simulator that evolves realistic smart home data through iterative refinement.
Generate initial data based on provided routines, then enhance it through rigorous self-analysis focusing on:
- Temporal consistency
- Sensor interdependencies
- Physical plausibility
Output ONLY the perfected dataset after all improvements.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Home Configuration Blueprint

▶ Household Members:

  • Primary Caregiver:
    - Activates: 05:45 | Departs: 07:45 | Re-enters: 16:45 | Deactivates: 22:15
  • Secondary Caregiver:
    - Activates: 06:30 | Departs: 08:30 | Re-enters: 17:30 | Deactivates: 22:45
  • Dependents (2):
    - Activates: 06:15 | Departs: 07:15 | Re-enters: 16:15 | Deactivates: 21:15

▶ Architectural Layout:
- Bi-level connected dwelling
- Primary circulation: Ground floor ↔ Upper floor via central stairwell

▶ Node Mapping:

  ⊙ Sanctuary (Primary):
    - presence_detector_primary, thermal_node_primary, illumination_primary, entertainment_primary

  ⊙ Nest (Dependent 1):
    - presence_detector_nest1, thermal_node_nest1, illumination_nest1, entertainment_nest1

  ⊙ Roost (Dependent 2):
    - presence_detector_roost, thermal_node_roost, illumination_roost

  ⊙ SocialHub:
    - presence_detector_social, thermal_node_social, illumination_social, entertainment_social, access_control_main

  ⊙ NutritionCenter:
    - thermal_node_nutrition, illumination_nutrition, power_node_refrigeration

  ⊙ UtilityZone:
    - presence_detector_utility, thermal_node_utility

▶ Node Connectivity Matrix:
- SocialHub ↔ NutritionCenter ↔ UtilityZone ↔ FunctionalArea
- SocialHub ↔ HygieneStation1
- SocialHub ↔ VerticalTransition ↔ DistributionNetwork ↔ All upper nodes (Sanctuary, Nest, Roost, HygieneStation2, SanitationNode)

Data Optimization Protocol (internal):

1. Draft preliminary dataset reflecting scheduled activities
2. Validate against:
   - Cross-sensor causality
   - Thermodynamic plausibility
   - Occupancy patterns
   - Energy consumption profiles
3. Implement corrections for:
   - Event sequencing
   - Value gradients
   - Physical limitations

Activity Signatures:

- Activation Phase: high-density transitions (06:00-08:00)
- Quiescent Period: minimal activity (08:30-16:00)
- Reintegration Wave: juveniles first (16:00-17:00), caregivers follow (17:00-18:00)
- Power down sequence initiates at 21:00
- System standby after 22:45

Sensor Physics:

- Presence → Thermal: Δ0.4–1.2°C per 10-20min
- Presence → Energy: 80–250W instantaneous
- Thermal → Humidity: coefficient -0.6 to -0.8

Stochastic Elements:

- Thermal noise: ±0.9°C
- Power variance: ±9%
- False presence: 0.15–0.25%

Data Schema:

Initialize with header row:
timestamp,event_id,zone,event_class,activation_node,temperature,humidity,presence,occupancy,illumination,energy_flow,acoustic_level,atmospheric_quality,door_state,portal_state

Then present the optimized, physically-consistent dataset.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])