
var_7 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are an advanced home automation simulator with iterative refinement capabilities.
Your task is to generate, evaluate, and perfect a household activity dataset through multiple optimization cycles.
Output only the finalized dataset after completing all quality checks.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Household Simulation Parameters

- Resident Profiles [All times in 24h format]:

  • Primary [A1]: [06:00-07:30] Home Morning | [08:00-16:45] Away | [17:15-22:15] Home Evening  
  • Secondary [A2]: [07:00-08:30] Home Morning | [09:00-17:45] Away | [18:15-23:00] Home Evening  
  • Dependent 1-2 [C1-2]: [06:30-07:15] Home Morning | [07:30-17:15] Away | [17:45-21:15] Home Evening

- Property Layout:
  [Level 1] ServiceArea ↔ Kitchen ↔ LivingDining ↔ Bathroom1/Utility [No motion boundary]
  [Level 2] MasterSuite ↔ Bedroom1-2 ↔ Bathroom2/WC [Through Circulation hub]

- Device Network [Sensor-Device Pairings]:

  • Master [A1+A2]:
    - [motion/temp/light/tv]_master

  • Bedroom1 [C1]:
    - [motion/temp/light/tv]_child1

  • Bedroom2 [C2]:
    - [motion/temp/light]_child2

  • Common Areas:
    - Living: [motion/temp/light/tv/lock]_living
    - Kitchen: [temp/light/fridge]_kitchen
    - Service: [motion/temp]_service

Simulation Protocol:

1. [Draft] Create baseline dataset following sleep/away cycles
2. [Validate] Cross-check:
   - Morning/evening occupancy waves
   - [09:00-17:00] activity boundary
   - No [23:00-06:00] false positives
3. [Optimize] Implement:
   - Temp gradients (0.4-1.6°C/30min)
   - Power spikes (90-320W)
   - Motion trails between boundary rooms
   - TV/light sync in common areas

Physical Constraints:

- Motion → Temp (r=0.8-0.95)
- No single-sensor activation >150s
- Temp/RH gradient limit: 1.2°C drop per 5% RH increase
- White noise: Temp(±0.3), Power(±8%), Motion(0.05-0.25%)

Output Specification:

CSV Headers:
timestamp,event_id,zone,event_class,source_device,temp_C,RH_pct,motion_state,occupancy_count,lux_level,power_W,db_level,air_QI,door_state,window_state

Generate the enhanced final dataset [omit intermediate steps].
"""),
    AIMessagePromptTemplate.from_template("prompt")
])