```python
var_0 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a smart home simulator that iteratively improves your own output.
First, generate a rough version of the dataset based on the household routine.
Then, self-evaluate it using behavioral consistency and sensor logic.
Refine the dataset accordingly.
Only output the final, improved dataset.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Scenario Configuration

- Family Members:

  • Adult 1: wakes at 06:00, leaves at 08:00, returns at 17:00, sleeps at 22:30  
  • Adult 2: wakes at 07:00, leaves at 09:00, returns at 18:00, sleeps at 23:00  
  • Child 1 & Child 2: wake at 06:30, leave at 07:30, return at 17:30, sleep at 21:30

- House Type: Two-story smart home

- Devices by Room:

  • MasterSuite:
    - motion_sensor_suite, temp_sensor_suite, smart_light_suite, smart_tv_suite

  • Bedroom1 (Child 1):
    - motion_sensor_bedroom1, temp_sensor_bedroom1, smart_light_bedroom1, smart_tv_bedroom1

  • Bedroom2 (Child 2):
    - motion_sensor_bedroom2, temp_sensor_bedroom2, smart_light_bedroom2

  • LivingDining:
    - motion_sensor_living, temp_sensor_living, smart_light_living, smart_tv_living, smart_lock_front

  • Kitchen:
    - temp_sensor_kitchen, smart_light_kitchen, smart_plug_fridge

  • ServiceArea:
    - motion_sensor_service, temp_sensor_service

- Room Connectivity:
  - LivingDining   Kitchen   ServiceArea   UtilityRoom
  - LivingDining   Bathroom1
  - LivingDining   Stairs   Circulation   all upper rooms (MasterSuite, Bedroom1, Bedroom2, Bathroom2, WC)

Self-Refinement Plan (internal only):

1. Generate a rough dataset based on expected wake times, motion, and transitions
2. Review dataset for:
   - Sensor correlations
   - Consistency in motion + temperature + power
   - Timing alignment with user routines
   - Inactivity periods
3. Adjust values, timestamps, or sequences to better reflect reality

Behavioral Patterns:

- Morning: high concurrency (Adults + Children), quick room transitions  
- Daytime: house empty from 09:00 to 17:00  
- Evening: children return first, followed by adults  
- Lights and devices turn off near bedtime  
- Silence after 23:00

Sensor Rules:

- Motion     Temp (0.5–1.5°C in 15–30 min)
- Motion     Power (100–300W instantly)
- Temp   Humidity: -0.7 to -0.9

Noise:

- Temp 'b10.1°C  
- Power 'b11%  
- Motion FP: 0.1–0.3%

Output Format:

Start with this header:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Then output the refined, coherent, realistic dataset.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])
```