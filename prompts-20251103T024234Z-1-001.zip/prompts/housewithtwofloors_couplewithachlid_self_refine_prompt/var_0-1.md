var_1 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are an advanced smart home data architect that constructs and optimizes sensor datasets.
Adopt an iterative refinement approach:
1. Draft initial sensor readings based on household patterns
2. Apply multi-dimensional validation checks
3. Implement necessary corrections
Output only the polished final dataset with perfect consistency.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Residence Blueprint

- Occupant Schedules:

  • Parent 1: 
    06:00 - Wake | 07:30 - Depart | 17:15 - Return | 22:15 - Sleep
  • Parent 2:
    06:30 - Wake | 08:00 - Depart | 18:15 - Return | 22:45 - Sleep
  • School Children (2):
    06:45 - Wake | 07:15 - Depart | 16:45 - Return | 21:00 - Sleep

- Property Specifications:
  - Two floors with connected zones
  - Smart sensors throughout

- Device Inventory:

  • PrimaryBedroom:
    - movement_detector_1, climate_monitor_1, lighting_control_1, entertainment_system_1

  • KidsRoomA:
    - movement_detector_2, climate_monitor_2, lighting_control_2

  • KidsRoomB:
    - movement_detector_3, climate_monitor_3

  • SocialArea:
    - movement_detector_main, climate_monitor_main, lighting_control_main, media_system_main, entry_sensor_front

  • FoodPrepZone:
    - climate_monitor_kitchen, lighting_control_kitchen, appliance_monitor_fridge

  • UtilityZone:
    - movement_detector_utility, climate_monitor_utility

- Space Relationships:
  - SocialArea ↔ FoodPrepZone ↔ UtilityZone ↔ LaundrySpace
  - SocialArea → HygieneRoom1
  - SocialArea → AccessPath → UpperLevel → AllUpperSpaces

Quality Assurance Protocol:

1. Generate initial sensor event stream
2. Validate against:
   - Environmental condition correlations
   - Occupancy-driven device activation patterns
   - Travel time between zones
   - Energy consumption rhythms
3. Refine anomalies with precision adjustments

Resident Behavior:

- Pre-08:00 AM: Multiple occupants preparing simultaneously  
- 08:00-16:30: Property vacant  
- 16:30 onward: Gradual returns starting with children  
- 21:00-23:00: Progressive system shutdowns  
- Post-23:00: Complete stillness

Sensor Interdependencies:

- Movement → Climate: +0.6–1.7°C in 10–25 minutes  
- Movement → Energy: 80W–320W instant draw  
- Climate → Moisture: -0.65 to -0.95

Signal Variance:

- Temperature ±9.2°C  
- Power ±8.7%  
- False movements: 0.05–0.25%

Delivery Specification:

Header Requirement:
timestamp,event_id,zone,event_class,activated_sensor,temp_reading,humidity_reading,movement_status,occupancy_count,illumination_level,energy_usage,sound_level,air_index,entry_state,portal_state

Provide only the verified, optimized dataset output.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])