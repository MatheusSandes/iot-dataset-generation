var_6 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are an advanced home automation simulator that creates and perfects smart home activity data.
Follow this optimization cycle:
1. Create initial simulation based on daily schedules
2. Perform multi-dimensional validation (temporal, spatial, device interaction)
3. Iteratively correct detected issues
4. Output only the polished final dataset
"""),
    HumanMessagePromptTemplate.from_template(r"""
Household Profile & Smart Home Details

Resident Schedules:

* Primary Resident:
  - Morning: 06:15 awake / 07:45 depart
  - Evening: 18:30 return / 23:15 sleep
* Secondary Resident:
  - Morning: 07:30 awake / 08:30 depart
  - Evening: 19:00 return / 22:45 sleep
* Youth Residents (2):
  - School days: awake 06:45 / depart 07:15 / return 16:00 / sleep 21:00

Home Layout & Infrastructure:

» Ground Floor:
- EntryArea: presence_sensor_entry, door_contact_front, camera_porch
- GreatRoom: environmental_sensor_living, smart_blinds_south, entertainment_unit
- MealZone: appliance_monitor_kitchen, temp_humidity_sensor, smart_faucet
- Services: vibration_sensor_laundry, smart_water_heater

» Upper Floor:
- PrimarySuite: bedside_sensor, bath_humidity_monitor, circadian_lighting
- YouthRooms:
  * ChamberA: motion_detector_teen1, socket_monitor_desk1
  * ChamberB: presence_sensor_teen2, window_sensor_east
- Utility: smart_mirror_wc, ventilation_control

Logical Checks (internal use only):

[1st Pass] Create baseline simulation:
- Map movement patterns between zones
- Model device state changes
- Generate raw environmental readings

[Validation Criteria]:
√ Device activation sequencing
√ Occupancy-triggered automation
√ Energy consumption patterns
√ Sensor reading plausibility

[Refinement Protocol]:
Δ Synchronize cross-room events
Δ Adjust smart device timing
Δ Introduce smart system noise
Δ Verify realistic empty periods

Environmental Conditions:
- Temperature changes: +0.3° to -0.7° per smart zone
- Humidity correlation: -0.75 to -0.85 on detected presence
- Power spikes: 150-400W on device activation
- Background noise floor: smart blind motor, AC operation

Data Structure Specification:

Required CSV fields (exactly):
record_time,event_identifier,space_id,event_category,origin_device,temp_C,humidity_percent,occupancy_state,illuminance_lux,power_draw_watts,env_noise_db,particulate_levels,portal_status,security_state

Generate the verified smart home activity log.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])