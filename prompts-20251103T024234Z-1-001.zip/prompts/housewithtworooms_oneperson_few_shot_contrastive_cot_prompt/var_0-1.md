
var_1 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a smart home data generation expert. Your task involves:
1. Reviewing correct and flawed behavioral patterns for a solo resident
2. Identifying logical inconsistencies in sensor activations
3. Creating realistic sensor event sequences that reflect natural human behavior
4. Maintaining physical property correlations and temporal consistency
"""),
    HumanMessagePromptTemplate.from_template(r"""
Behavioral Prototypes:

[Valid Pattern]
Resident Timeline:
06:00-07:30 Morning routine (Bedroom1 → Kitchen)
07:30-08:00 Pre-departure (LivingRoom)
08:00-17:00 Away (minimal activity)
17:00-19:30 Evening routine (Kitchen → LivingRoom)
19:30-22:30 Leisure time (LivingRoom)
22:30-06:00 Sleep (Bedroom1)

Sensor Characteristics:
- Motion → Temp rise (0.8±0.3°C over 20±5min)
- Device use → Power spike (200±50W instant)
- Humidity = 65 - (Temp-20)*15 ±5%
- Nighttime motion FP rate: 0.2%

Sample Valid Events:
2025-06-01T06:12:18,evt_001,Bedroom1,motion,motion_bed1,22.1,63,1,1,low,120,32,good,closed,closed  
2025-06-01T06:34:45,evt_002,Kitchen,temp,temp_kitchen,22.8,59,,1,medium,245,35,good,closed,closed

[Invalid Pattern]
Errors Detected:
× Motion during work hours (09:15: Kitchen)
× Temp drop after motion (23.1→21.8)
× Unrealistic power draw (420W for TV)
× Perfectly spaced timestamps (all xx:00:00)

New Scenario Specifications:

Residence Blueprint:
◉ 2BR Urban Apartment (68m² total)
◉ Bedroom1 (Main): 9m²
◉ Bedroom2 (Guest): 9m²
◉ LivingRoom: 9m² with balcony
◉ Kitchen: 2.2m² (galley style)
◉ ServiceArea: 4m² (laundry)

Device Mapping:
┌────────────┬─────────────────────────────┐
│ Location   │ Sensors/Devices            │
├────────────┼─────────────────────────────┤
│ Bedroom1   │ motion1, temp1, light1     │
│ LivingRoom │ motion_LR, temp_LR, TV     │
│ Kitchen    │ fridge_plug, light_kitchen │
└────────────┴─────────────────────────────┘

Resident Profile:
• Gender: Male
• Age: 28
• Occupation: Office worker
• Schedule:
  - Asleep: 23:00-06:00
  - Commuting: 07:45-08:30, 17:00-17:45
  - Home presence: 06:00-07:45, 17:45-23:00

Environmental Context:
• Season: Winter (Southern Hemisphere)
• Baseline temps:
  Night: 21-23°C
  Day: 24-26°C
• Humidity range: 42-68%

Generation Rules:
1. Strictly follow absence periods (work/sleep)
2. Maintain realistic appliance power:
   Fridge: 200±30W
   TV: 180±40W
   Lights: 60±15W
3. Event timestamps must show natural variance (±3min typical)
4. Include 1-2 low-probability events (e.g. late-night bathroom visit)

Required Output Format:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Generate 12-15 realistic events for this configuration.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])