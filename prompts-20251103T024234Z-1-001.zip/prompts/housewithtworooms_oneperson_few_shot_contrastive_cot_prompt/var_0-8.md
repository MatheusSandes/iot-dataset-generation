
var_8 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a smart home dataset synthesizer. You will be shown:
1. A properly reasoned example with logical sensor activations
2. A flawed example with common simulation mistakes
Your task is to learn from both and generate realistic data matching given constraints.
"""),
    HumanMessagePromptTemplate.from_template(r"""
▌Quality Demonstration ▌

✔ Valid Spatial-Temporal Patterns:
- Bedroom (06:15-07:45): Gradual wake-up sequence
- Kitchen (07:50-08:10): Morning activity cluster
- 08:15-17:00: Complete sensor silence
- LivingRoom (17:30-22:20): Evening media consumption

✔ Environmental Correlations:
- Motion → +0.8°C temperature within ≤20 min
- Humidity mirrors temperature inversely (-0.8 coeff)
- Power spikes align with device states changes

✘ Common Pitfalls (to avoid):
1. Activity during commute/work hours (08:00-17:00)
2. Unnatural timestamp intervals (whole minutes only)
3. Violations of device power specifications
4. Inconsistent environmental responses

▌Scenario Parameters▌

⌚ Daily Phases:
06:00-08:00 │ Morning routine 
08:00-17:00 │ Absence (work)
17:00-22:30 │ Evening activities
22:30-06:00 │ Sleep period

🏠 Spatial Configuration:

╒══════════╤═══════════════════════╤════════════════╕
│ Room     │ Sensors/Devices       │ Activity Scope │
╞══════════╪═══════════════════════╪════════════════╡
│ Bedroom1 │ Motion, Temp, Light   │ 06:00-08:00    │
│          │                       │ 22:30-06:00    │
├──────────┼───────────────────────┼────────────────┤
│ Kitchen  │ Temp, Light, Fridge   │ Cooking times  │
├──────────┼───────────────────────┼────────────────┤
│ LivingRm │ Motion, TV, Lights    │ Evening media  │
└──────────┴───────────────────────┴────────────────┘

⚠ Physical Constraints:
• Max power draws:
  - Smart TV: 200W (±15%)
  - Fridge: 300W (cyclic)
• Motion decays in 2-5 minutes
• Light levels (lux):
  Night <>600

▌Required Output▌

Produce a 24-hour dataset respecting:
1. Brazilian winter climate patterns
2. Realistic sensor reaction times
3. Proper event clustering
4. Zero false positives during inactive hours

DATA HEADER (include exactly):
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Generate realistic comma-separated entries with natural timestamp jitter and cross-property validation."""),
    AIMessagePromptTemplate.from_template("prompt")
])