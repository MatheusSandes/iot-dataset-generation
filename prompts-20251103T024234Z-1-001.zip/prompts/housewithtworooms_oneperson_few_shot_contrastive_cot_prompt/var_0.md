    ```python
var_0 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are given two reasoning examples for a smart home scenario with one occupant: one correct and one incorrect.
Analyze both carefully to learn what to do and what to avoid.
Then, generate a valid dataset for a new scenario with similar household conditions.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Example 1 (Correct Chain-of-Thought)

Scenario:
- One adult lives alone
- Sleeps in Bedroom1
- Active from 06:00 to 08:00 and 17:00 to 22:30
- No activity during 08:00–17:00 (at work) and after 22:30 (sleeping)
- Interacts with Bedroom1, Kitchen, LivingRoom, occasionally ServiceArea and Bedroom2
- Sensor activations follow routines and natural noise

Reasoning:
After waking at 06:00, the resident moves in Bedroom1, then enters the Kitchen. Motion raises temperature and triggers power usage. Output is timestamped naturally and idle periods are respected.

Output:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status  
2025-06-01T06:00:25,evt_0001,Bedroom1,motion_detected,motion_sensor_bedroom1,22.0,67,1,1,low,100,34,good,closed,closed  
2025-06-01T06:03:32,evt_0002,Kitchen,power_usage,smart_plug_fridge,,67,,1,medium,220,34,good,closed,closed  
2025-06-01T06:07:50,evt_0003,Kitchen,temperature_reading,temp_sensor_kitchen,23.3,60,,1,medium,240,35,good,closed,closed  
2025-06-01T06:55:18,evt_0004,LivingRoom,power_usage,smart_tv,,62,,1,medium,290,36,good,closed,closed  

---

Example 2 (Incorrect Chain-of-Thought)

Scenario:
Same house and resident.

Faulty Reasoning:
Includes motion and device usage during work hours. Timestamps are uniformly spaced. Temperature decreases after motion. Power consumption reaches unrealistic levels.

Mistakes:
- Activity during 09:00–15:00 (user is at work)
- Inverted motion-temperature correlation
- Excessive power for smart plug
- Timestamps with no variability

Output:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status  
2025-06-01T09:00:00,evt_0005,LivingRoom,motion_detected,motion_sensor_living,24.6,55,1,1,high,360,33,good,closed,closed  
2025-06-01T09:02:00,evt_0006,Kitchen,temperature_reading,temp_sensor_kitchen,23.9,58,,1,medium,250,33,good,closed,closed  
2025-06-01T09:04:00,evt_0007,LivingRoom,power_usage,smart_tv,,56,,1,high,380,33,good,closed,closed  

---

Now generate a correct dataset for the following new scenario:

Scenario Configuration

- House Type: Small urban smart home with two bedrooms

- Devices by Room:

  • Bedroom1 (3m x 3m):
    - motion_sensor_bedroom1
    - temp_sensor_bedroom1
    - smart_light_bedroom1

  • Bedroom2 (3m x 3m):
    - motion_sensor_bedroom2
    - temp_sensor_bedroom2
    - smart_light_bedroom2

  • LivingRoom (3m x 3m):
    - motion_sensor_living
    - temp_sensor_living
    - smart_tv
    - smart_light_living
    - smart_lock_front

  • Kitchen (1.8m x 1.2m):
    - temp_sensor_kitchen
    - smart_light_kitchen
    - smart_plug_fridge

  • ServiceArea:
    - motion_sensor_service
    - temp_sensor_service

  • Bathroom (2m x 1.2m): no sensors

- Room Connections:
  - Bedroom1   LivingRoom
  - Bedroom2   Bathroom
  - Bathroom   ServiceArea   Kitchen
  - LivingRoom   Kitchen

- Resident:
  • Single adult (person1), sleeps in Bedroom1

- Daily Routine:
  • Wakes at 06:00, leaves for work at 08:00, returns at 17:00
  • Sleeps from 22:30 to 06:00
  • Active in Bedroom1 and Kitchen in the morning
  • Active in LivingRoom and Kitchen at night
  • Occasionally accesses Bedroom2 and ServiceArea

- Environment:
  • Winter (Brazil, June)
  • Temperature: 21–26°C
  • Humidity: 40–70% (inverse correlation)

Technical Requirements:

- Motion     Temperature (0.5–1.5°C within 15–30 min)
- Motion     Power (100–300W immediately)
- Temperature   Humidity: correlation -0.7 to -0.9
- Add noise:
  - Temp 'b10.1°C
  - Power 'b11%
  - Motion FP: 0.1–0.3%
- No activity:
  - 23:00–06:00 (sleep)
  - 08:00–17:00 (work)

Output Format:

Begin with this header:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Then provide the valid CSV dataset based on the new scenario.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])
```