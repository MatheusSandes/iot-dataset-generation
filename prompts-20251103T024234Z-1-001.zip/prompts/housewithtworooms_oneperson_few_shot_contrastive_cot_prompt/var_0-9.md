
var_9 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a smart home data generator specializing in realistic occupant behavior patterns.
You will analyze correct and incorrect examples, then create accurate sensor data for a new home configuration.
Focus on creating physically plausible sensor relationships and respecting occupant routines.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Learning Examples:

[VALID EXAMPLE] - Demonstrates correct patterns:
• Accurate temperature-humidity correlation
• Natural time intervals between events
• Activity only during expected time windows
• Sensor readings follow expected physical relationships
• Power consumption within typical appliance ranges

Sample Valid Data:
2025-06-01T06:12:47,evt_0001,Bedroom1,motion_detected,motion_sensor_bedroom1,21.7,68,1,1,low,110,33,good,closed,closed  
2025-06-01T06:16:55,evt_0002,Kitchen,temp_update,temp_sensor_kitchen,22.3,65,,1,medium,225,34,good,closed,closed  
2025-06-01T17:08:12,evt_0003,LivingRoom,device_on,smart_tv,,63,,1,high,280,38,good,closed,closed  

[INVALID EXAMPLE] - Shows common mistakes:
• Impossible sensor value combinations
• Activity during sleep/work periods
• Perfectly regular timestamps
• Disregard for environmental physics
• Extremely high/low readings without cause

Sample Invalid Data:
2025-06-01T03:22:00,evt_0004,Bedroom1,motion_detected,motion_sensor_bedroom1,19.1,72,1,1,high,90,29,good,closed,closed  
2025-06-01T10:00:00,evt_0005,Kitchen,power_spike,smart_plug_fridge,24.0,42,,1,medium,950,30,good,closed,closed  
2025-06-01T10:02:00,evt_0006,Kitchen,temp_drop,temp_sensor_kitchen,18.5,75,,1,medium,215,30,good,closed,closed  

---

New Scenario Specifications:

Residence Layout:
• Primary Spaces: Bedroom1, Kitchen, LivingRoom (connected)
• Secondary Spaces: Bedroom2, ServiceArea (occasionally accessed)
• Bathroom (unsensed pass-through to ServiceArea)

Occupant Pattern:
☼ 06:00-08:00 Morning routine (Bedroom1 → Kitchen)
☼ 08:00-17:00 Away from home
☼ 17:00-22:30 Evening activity (LivingRoom/Kitchen focused)
☼ 22:30-06:00 Sleep period

Device Constraints:
- Temperature sensors: ±0.2°C accuracy with 15 minute update cycle
- Smart lights: 50-150W with motion activation
- TV: 200-400W during use
- Fridge: 100-250W with compressor cycles
- Occupancy: 1 when home, 0 when away

Physical Rules:
▲ Motion → Temp Increase (0.8±0.3°C over 20±10 min)
▲ Active device → Power draw immediately
▼ Temp Increase → Humidity Decrease (Δ-2% per +1°C)
◊ Occasional random sensor noise (<1% of readings)

Required Output Format:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Generate sensor data respecting:
1. The occupant's schedule
2. Device specifications
3. Environmental physics
4. Real-world variability
"""),
    AIMessagePromptTemplate.from_template("prompt")
])