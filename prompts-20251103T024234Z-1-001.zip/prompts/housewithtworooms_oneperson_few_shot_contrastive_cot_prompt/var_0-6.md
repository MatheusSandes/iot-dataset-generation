var_6 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You will analyze contrasting smart home behavior patterns for a solo occupant scenario - one logically consistent, the other flawed. Extract key insights about environmental parameter correlations and temporal rhythms.
"""),
    HumanMessagePromptTemplate.from_template(r"""
# CASE STUDY: SINGLE OCCUPANT HOME AUTOMATION

## VALID EXAMPLE (Pattern Trace)

Setting:
- 32m² smart home in mild climate
- Professional resident (away 08:00-16:00)
- Winter season parameter ranges:
  Temperature: 21–26°C
  Humidity: inversely tracking 40–70%

Device Interactions:
- Morning (06:00-08:00): Bedroom1 → Kitchen
- Evening (17:00-22:30): LivingRoom ↔ Kitchen
- Nocturnal: Minimal Bedroom1 presence after 23:00

Behavior Parameters:
- Motion   Temp Δ: +0.8±0.3°C/20min
- Appliance power: 115±35W per active device
- Sensor ghosting: <0.2% false triggers

Event Log Sample:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status
2025-06-01T06:12:07,evt_1,Bedroom1,motion,motion_sensor_bedroom1,22.4,63,1,1,low,110,33,good,closed,closed
2025-06-01T06:17:22,evt_2,Kitchen,power,smart_plug_fridge,N/A,61,N/A,1,medium,225,34,good,closed,closed
2025-06-01T17:20:15,evt_3,LivingRoom,device,smart_tv,N/A,58,N/A,1,medium,275,40,good,closed,closed

## INVALID EXAMPLE (Anomaly Detection)

Pattern Violations:
- 09:31 - LivingRoom motion while vacant
- 14:00 - Kitchen -3°C drop post-motion
- Continuous 650W phantom load
- Mechanically spaced timestamps
- Sensor cross-talk between floors

Defective Log:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status
2025-06-01T13:00:00,evt_4,Bedroom1,temp,temp_sensor_bedroom1,17.2,75,0,0,low,0,25,good,closed,closed
2025-06-01T13:02:00,evt_5,LivingRoom,motion,motion_sensor_living,24.1,72,1,1,high,680,38,fair,closed,closed

---

# GENERATION TASK: NEW SCENARIO IMPLEMENTATION

Space Configuration:
- Bedroom1 (9m² core space)
  smart_light_bedroom1
  environmental cluster (temp/motion) 
  
- LivingRoom (9m² hub)
  entertainment system cluster
  presence detectors
  access control (smart_lock_front)

Behavioral Constraints:
- Thermal physics:  
  Activity zone ΔT = 0.3–1.1K per 100W 
  Latent heat recovery time: 45±15min
  
- Power envelope:
  Lighting: 80±20W  
  Media: 280±40W
  Refrigeration: 220±30W
  
- Chronobiology:
  06:00–08:00: morning prep phase  
  17:00–22:30: evening active phase
  Sleep/wormhole: >2300 & <0600

Required Output Header:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Produce a physically-consistent 24-hour trace respecting all spatial and temporal constraints.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])