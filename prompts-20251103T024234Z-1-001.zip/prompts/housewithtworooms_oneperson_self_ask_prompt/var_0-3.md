
var_3 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Approach this smart home dataset generation through systematic scenario decomposition.
Break down the living patterns, device interactions, and environmental factors into logical components.
Internally calculate all dependencies before synthesizing the final output.
The goal is to produce a realistic, temporally coherent dataset that reflects actual IoT device behavior.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Configuration Blueprint

RESIDENCE PROFILE:
- Type: Compact urban dwelling (54 total m²)
- Occupant: Single professional (PersonA)
- Sleep/Wake Cycle: 22:30–06:00 (sleeping), 06:00–08:00 (morning routine), 17:00–22:30 (evening activity)

DEVICE MATRIX (by zone):

◈ Private Quarters (Bedroom1 - 9m²):
  • motion_detector_BR1
  • climate_sensor_BR1 (temp/humidity)
  • adaptive_lighting_BR1

◈ Guest Space (Bedroom2 - 9m²):
  • motion_detector_BR2
  • climate_sensor_BR2
  • dimmable_light_BR2

◈ Social Hub (LivingRoom - 9m²):
  • presence_detector_LR
  • environmental_sensor_LR
  • entertainment_system
  • mood_lighting_LR
  • secure_entry_system

◈ Food Prep Zone (Kitchen - 2.16m²):
  • temp_monitor_KT
  • task_lighting_KT
  • appliance_controller_fridge

◈ Utility Area:
  • motion_sensor_UT
  • temp_sensor_UT

◈ Hygiene Space: No monitoring devices

SPATIAL CONNECTIVITY:
  BR1 ↔ Living ↔ Kitchen
  BR2 ↔ Bath ↔ Utility ↔ Kitchen

Key Temporal Patterns:
- Morning (06:00–08:00): BR1→Kitchen→Living
- Evening (17:00–22:30): Living↔Kitchen
- Occasional: BR2/Utility access
- System Quiet Times: 23:00–06:00, 08:00–17:00

Technical Parameters to Model:
▸ Motion-to-Environment: 
  - Temp delta: 0.5–1.5°C over 15–30 min
  - RH correlation: -0.7±0.2
▸ Device Activation:
  - Power surge: 100–300W instant
  - Lighting response: 10–90% brightness
▸ Real-World Imperfections:
  - Sensor drift: ±0.1°C (temp), ±1% (RH)
  - False triggers: 0.1–0.3% probability
  - Event timestamp jitter: ±2 minutes

Validation Checks (internal):
1. Verify circadian rhythm alignment
2. Confirm device interaction causality
3. Ensure spatial movement coherence
4. Validate environmental baselines
5. Check anomaly distribution

Output Specification:

Required CSV Header:
timestamp,event_id,zone,event_class,trigger_device,temperature_c,humidity_pct,motion_state,occupancy_status,light_pct,power_w,noise_db,air_quality_idx,door_state,window_state

Generate only the CSV dataset, excluding any reasoning or interim calculations.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])