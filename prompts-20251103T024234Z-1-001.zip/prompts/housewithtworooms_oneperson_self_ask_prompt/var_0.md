```python
var_0 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Before generating the dataset, ask yourself a series of sub-questions to understand the scenario in depth.
Answer each question internally to guide your reasoning process.
Then generate the final dataset based on your answers.
Do not include the questions or reasoning in the output — only provide the resulting CSV dataset.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Scenario Configuration

- House Type: Small urban smart home with two bedrooms

- Devices by Room:

  • Bedroom1 (3m x 3m):
    - motion_sensor_bedroom1
    - temp_sensor_bedroom1
    - smart_light_bedroom1

  • Bedroom2 (3m x 3m):
    - motion_sensor_bedroom2
    - temp_sensor_bedroom2
    - smart_light_bedroom2

  • LivingRoom (3m x 3m):
    - motion_sensor_living
    - temp_sensor_living
    - smart_tv
    - smart_light_living
    - smart_lock_front

  • Kitchen (1.8m x 1.2m):
    - temp_sensor_kitchen
    - smart_light_kitchen
    - smart_plug_fridge

  • ServiceArea:
    - motion_sensor_service
    - temp_sensor_service

  • Bathroom (2m x 1.2m): no sensors

- Room Connections:
  - Bedroom1   LivingRoom
  - Bedroom2   Bathroom
  - Bathroom   ServiceArea   Kitchen
  - LivingRoom   Kitchen

- Resident:
  • One adult (person1), sleeps in Bedroom1

- Daily Routine:
  • Wakes at 06:00, leaves for work at 08:00, returns at 17:00
  • Sleeps from 22:30 to 06:00
  • Active in Bedroom1 and Kitchen in the morning
  • Active in LivingRoom and Kitchen at night
  • Occasionally accesses Bedroom2 and ServiceArea

Questions to ask yourself (mentally):
- What are the main activity windows?
- What is the most likely sequence of rooms visited after waking?
- What devices and sensors are involved during these movements?
- How does motion influence other variables?
- When is the house inactive?
- Where do anomalies or false positives most likely occur?

Technical Requirements:

- Motion     Temperature (0.5–1.5°C in 15–30 min)
- Motion     Power (100–300W instantly)
- Temperature   Humidity: correlation -0.7 to -0.9
- Add realistic noise:
  - Temperature 'b10.1°C
  - Power 'b11%
  - Motion FP: 0.1–0.3%
- No events during:
  - 23:00–06:00 (sleep)
  - 08:00–17:00 (work)
- Use natural variation in timestamps

Output Format:

Begin with this header:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Then output the CSV dataset (do not include your questions or reasoning).
"""),
    AIMessagePromptTemplate.from_template("prompt")
])
```