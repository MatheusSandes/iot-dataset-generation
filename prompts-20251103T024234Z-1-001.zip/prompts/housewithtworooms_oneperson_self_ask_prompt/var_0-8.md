
var_8 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Deeply analyze the smart home scenario through an internal reasoning process before dataset generation. 
Consider all spatial relationships, temporal patterns, and device interactions.
Validate each logical connection between events and environmental changes.
Generate only the final CSV output without showing intermediate analysis.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Layout Specification

RESIDENCE PROFILE:
- Category: Compact urban dwelling (45 sqm total)
- Occupant: Solo professional (person1, Bedroom1 primary)

ROOM DETAILS:

▲ Sleeping Quarters
  • Master Bedroom (9sqm):
    > Sensor Array: occupancy_bed1, climate_bed1, lighting_bed1
  • Guest Room (9sqm):
    > Sensor Array: presence_bed2, thermal_bed2, illumination_bed2

▲ Common Areas
  ○ Living Space (9sqm):
    > Devices: presence_living, environment_living, entertainment_system
    > Controls: lighting_living, security_lock
  ○ Food Preparation Zone (2.16sqm):
    > Monitoring: climate_kitchen
    > Appliances: lighting_kitchen, refrigeration_unit
  ○ Utility Space:
    > Sensors: activity_service, climate_service

▲ Hygiene Area (2.4sqm): No monitoring

CONNECTIVITY MAP:
  Master ↔ Living ↔ Kitchen ↔ Utility ↔ Bathroom ↔ Guest

TEMPORAL PATTERNS:
06:00-08:00: Morning routine (Sleeping→Common→Food zones)
17:00-22:30: Evening activities (Common→Food zones)
22:30-06:00: Sleep cycle
08:00-17:00: Residence vacant

ANALYSIS CHECKPOINTS (internal only):
• Map typical movement vectors throughout daily cycles
• Identify sensor activation hierarchies
• Model environmental parameter drift patterns
• Pinpoint probable error scenarios
• Establish cause-effect chains between systems

ENGINEERING PARAMETERS:

▲ Sensor Relationships
  - Motion→Climate: Δ0.5-1.5°C/15-30min
  - Movement→Power: 100-300W surge
  - Temp-Humidity: Inverse correlation (r=-0.8±0.1)

▲ Real-World Variance
  - Thermal noise: ±0.1°C
  - Energy fluctuations: ±11%
  - False detection rate: 0.2%±0.1%

▲ Constraints:
  - Silent periods: 23:00-06:00, 08:00-17:00
  - Temporal variation: ±3min natural offset

REQUIRED OUTPUT STRUCTURE:

timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

[Generate CSV dataset only]
"""),
    AIMessagePromptTemplate.from_template("prompt")
])