
var_7 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Engage in comprehensive internal reasoning to construct the dataset. Follow this cognitive process:
1. Analyze all spatial relationships between rooms
2. Model resident behavior patterns across time segments
3. Map device interactions for each behavior state
4. Calculate environmental parameter correlations
5. Simulate sensor interactions with realistic noise

Generate ALL computations internally - output ONLY the final CSV data.
"""),
    HumanMessagePromptTemplate.from_template(r"""
DOMAIN SPECIFICATION

// Architectural Layout
Residence-Type: Compact_SmartHome (48m² total)
Room-Connections:
  B1←→LR→K←→BA→SA
  B2→BA

// Device Inventory
[B1]
- MOT_001 (motion)
- TEMP_001 (temp)
- LGT_001 (light)

[B2]
- MOT_002 
- TEMP_002
- LGT_002

[LR]
- MOT_003
- TEMP_003
- ENT_001 (TV)
- LGT_003
- LOC_001 (front door)

[K]
- TEMP_004
- LGT_004
- PWR_001 (fridge)

[SA]
- MOT_004
- TEMP_005

// Resident Profile
- Single occupant (primary=B1)
- Temporal Pattern:
  06:00-08:00: Morning routine
  08:00-17:00: Absent
  17:00-22:30: Evening activity
  22:30-06:00: Sleep cycle

Required Dynamics:
1. Temperature Fluctuations:
   - Basal range: 18-24°C
   - ΔT/Δt: max 2°C/hour
   - Device impact: +0.5°C per active device

2. Power Consumption:
   - Base load: 50W
   - Active devices: 75-250W instant
   - TV: 120W (±10%)

3. Sensor Error Margins:
   - Temp: ±0.3°C
   - Motion: 99.7% precision
   - Light: 5% tolerance

4. Environmental:
   - Humidity inversely tracks temp (r ≈ -0.8)
   - Occupancy-driven CO2 fluctuation

Data Construction Rules:
- Apply natural activity jitter (±15min)
- Model circadian lighting variation
- Simulate door state changes (LOCKED/UNLOCKED)
- Generate device state transitions:
   OFF→ON→STANDBY→OFF

Strictly maintain this format:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status
"""),
    AIMessagePromptTemplate.from_template("prompt")
])