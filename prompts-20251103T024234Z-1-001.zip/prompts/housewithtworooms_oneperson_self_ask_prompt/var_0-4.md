var_4 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Analyze the living patterns and device interactions through a systematic thought process.
Break down each component of the scenario, evaluate potential interactions,
and simulate realistic device behaviors before generating output.
Maintain complete internal documentation of your reasoning steps,
but provide only the final simulated dataset in CSV format.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Residence Configuration

- Dwelling Type: Compact smart residence with dual sleeping chambers

- Equipment Distribution:

  • SleepChamberA (3x3m):
    - presence_detector_chamberA
    - climate_sensor_chamberA
    - adaptive_illumination_chamberA

  • SleepChamberB (3x3m):
    - presence_detector_chamberB
    - climate_sensor_chamberB
    - adaptive_illumination_chamberB

  • CommonArea (3x3m):
    - presence_detector_common
    - climate_sensor_common
    - entertainment_system
    - adaptive_light_common
    - access_control_front

  • FoodPrepZone (1.8x1.2m):
    - climate_sensor_kitchen
    - task_lighting_kitchen
    - appliance_connector_cooling

  • UtilitySpace:
    - presence_detector_utility
    - climate_sensor_utility

  • HygieneRoom (2x1.2m): no monitoring devices

- Spatial Connectivity:
  - SleepChamberA ↔ CommonArea
  - SleepChamberB ↔ HygieneRoom
  - HygieneRoom ↔ UtilitySpace ↔ FoodPrepZone
  - CommonArea ↔ FoodPrepZone

- Occupant Profile:
  • Single working adult (resident1), occupies SleepChamberA

- Daily Pattern:
  • Awakening at 0600, departure at 0800, return at 1700
  • Rest period: 2230-0600
  • Morning activity concentrated in SleepChamberA and FoodPrepZone
  • Evening activity focused in CommonArea and FoodPrepZone
  • Periodic access to SleepChamberB and UtilitySpace

Analysis Framework (internal):
- Map primary activity periods
- Trace likely movement sequences
- Identify device activation chains
- Model motion-triggered responses
- Determine inactive intervals
- Predict irregular sensor readings

Technical Specifications:

- Presence → Thermal (0.5–1.5°C variation in 15–30 min)
- Presence → Energy (100–300W immediate)
- Thermal ↔ Moisture: inverse relationship (-0.7 to -0.9)
- Incorporate authentic fluctuations:
  - Thermal ±0.1°C
  - Energy ±11%
  - Presence FP rate: 0.1–0.3%
- Zero activity during:
  - 2300-0600 (rest)
  - 0800-1700 (absence)
- Implement organic timestamp variance

Data Structure:

Initiate with these column headers:
timestamp,event_id,zone,interaction_type,initiating_sensor,thermal_reading,moisture_level,presence_status,occupancy_count,illumination_value,energy_usage,acoustic_level,atmosphere_quality,portal_state,aperture_status

Generate the CSV dataset (exclude all analytical steps).
"""),
    AIMessagePromptTemplate.from_template("prompt")
])