var_6 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Construct the dataset through a structured thought process:
1) Analyze the home layout and resident patterns
2) Simulate realistic device interactions
3) Incorporate environmental fluctuations
4) Validate against technical constraints
Present only the final CSV output - exclude all intermediate reasoning.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Configuration Blueprint

# Residential Layout
- Total Area: 12.6m×12.6m (split across 4 floors)
- Floor 1: Bedroom1 (3.5m×4m), Bedroom2 (3.5m×4m)
- Floor 2: LivingRoom (5m×5m), Kitchen (3m×2m)
- Floor 3: Bathroom (2.5m×2m), ServiceArea (2m×2m)
- Floor 4: Storage (no sensors)

# Device Network
‹Bedroom1›
• motion_sensor_b1 (ceiling)
• temp_sensor_b1 (north wall)
• smart_bulb_b1 (main light)

‹Bedroom2›
• motion_sensor_b2 (door)
• temp_sensor_b2 (window)
• smart_bulb_b2 (bedside)

‹LivingRoom›
• motion_sensor_lr (center)
• temp_sensor_lr (TV wall)
• smart_entertainment_system
• ambient_lighting
• entry_lock

‹Kitchen›
• temp_sensor_kit (fridge)
• under_cabinet_lighting
• appliance_monitor

‹ServiceArea›
• motion_sensor_sa (door)
• temp_sensor_sa (water heater)

# Resident Profile
- Single professional (28yo)
- Work schedule: M-F 08:30-18:00
- Typical path:
  Morning: Bedroom1 → Bathroom → Kitchen → LivingRoom → Exit
  Evening: Enter → LivingRoom → Kitchen → (Bedroom1/Bathroom)

# Technical Parameters
∆ Motion triggers:
  - Lights: +180-220W (±15W)
  - Temp variance: 0.8-1.2°C/30min
  - False positives: 0.15% probability

∆ Environmental:
  - Temp/Humidity: r=-0.82
  - Base temp: 21.5°C ± noise(0.3)
  - Device power fluctuation: ±8%

∆ Quiet periods:
  - Sleep: 23:45-06:15
  - Away: 08:15-18:15
  - Random inactivity: 1-2hr/day

Required Data Attributes:
timestamp,event_id,floor,zone,device_id,sensor_reading,power_state,occupancy_flag,environmental_quality

Generate CSV output only.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])