
var_9 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Analyze the residential scenario thoroughly by breaking it down into logical components before generating data.
Consider spatial relationships, device interactions, and temporal patterns to build a coherent event sequence.
Internalize the following aspects without showing your thought process in the output:
- Activity flow through connected spaces
- Device state dependencies
- Environmental parameter correlations
Generate only the final CSV dataset, omitting all intermediate analysis.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Residence Specifications:

-- Property Type --
Compact urban smart residence with two sleeping quarters

-- Sensor Network Configuration --

SleepingZone1 (3x3m):
• presence_detector_1
• thermal_sensor_1
• adjustable_luminaires_1

SleepingZone2 (3x3m):
• presence_detector_2
• thermal_sensor_2
• adjustable_luminaires_2

SocialArea (3x3m):
• presence_social
• climate_social
• entertainment_system
• illumination_social
• entry_security

FoodPrepZone (1.8x1.2m):
• thermal_prep
• illumination_prep
• cooling_appliance_control

UtilitySection:
• presence_utility
• climate_utility

-- Spatial Connectivity --
SleepingZone1 ↔ SocialArea
SleepingZone2 ↔ HygieneRoom
HygieneRoom ↔ UtilitySection ↔ FoodPrepZone
SocialArea ↔ FoodPrepZone

-- Occupant Profile --
Single professional inhabiting SleepingZone1

-- Activity Timeline --
06:00 Awakening
08:00 Departure
17:00 Return
22:30 Sleep initiation
Primary zones: SleepingZone1 + FoodPrepZone (AM), SocialArea + FoodPrepZone (PM)
Secondary access to SleepingZone2 and UtilitySection

Key Considerations (internal analysis):
- Peak activity periods
- Movement patterns through connected zones
- Sensor activation sequences
- Influence of presence detection
- Dormant periods
- Potential system anomalies

Technical Parameters:

- Motion Detection → Climate Adjustment (0.5–1.5°C variation over 15–30 min)
- Presence → Energy Draw (instant 100–300W increase)
- Thermal-Hygric Relation: -0.7 to -0.9 correlation
- Real-world variance:
  ±0.1°C thermal readings
  ±11% power measurements
  0.1–0.3% presence false positives
- Quiet Hours:
  23:00–06:00 (resting)
  08:00–17:00 (absence)
- Natural timestamp distribution

Required Data Structure:

Begin dataset with this exact header row:
timestamp,event_id,zone,sensor_class,activated_device,temperature,humidity,movement_status,occupancy_status,illumination_intensity,energy_usage,acoustic_level,aeration_quality,portal_state,aperture_status

Output the complete CSV dataset without commentary or analysis.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])