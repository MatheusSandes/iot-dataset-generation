```python
var_0 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a Smart Home Dataset Formatter.
Your goal is to generate a clean, standardized dataset reflecting realistic behavior in a home with two adults and one child.
Focus on style: formatting, consistent casing, decimal precision, column alignment, and natural but not artificial timestamp spacing.
Only output the structured dataset — no explanation or variation allowed.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Styling Guidelines:
- Use ISO 8601 timestamp format (e.g., 2025-06-01T06:00:00)
- All column names and values must be lowercase (e.g., '93motion_detected'94, '93closed'94)
- Use consistent decimal places (e.g., 21.8 not 21.83)
- Do not use placeholder values (e.g., avoid '93n/a'94 or blank cells)
- Keep column ordering and value alignment strict

Scenario Configuration

- House Type: Small urban smart home with two bedrooms

- Devices by Room:

  • Bedroom1 (3m x 3m):
    - motion_sensor_bedroom1
    - temp_sensor_bedroom1
    - smart_light_bedroom1

  • Bedroom2 (3m x 3m):
    - motion_sensor_bedroom2
    - temp_sensor_bedroom2
    - smart_light_bedroom2

  • LivingRoom (3m x 3m):
    - motion_sensor_living
    - temp_sensor_living
    - smart_tv
    - smart_light_living
    - smart_lock_front

  • Kitchen (1.8m x 1.2m):
    - temp_sensor_kitchen
    - smart_light_kitchen
    - smart_plug_fridge

  • ServiceArea:
    - motion_sensor_service
    - temp_sensor_service

  • Bathroom (2m x 1.2m): no sensors

- Room Connections:
  - Bedroom1   LivingRoom
  - Bedroom2   Bathroom
  - Bathroom   ServiceArea   Kitchen
  - LivingRoom   Kitchen

- Residents:
  • Resident 1: wakes at 06:00, leaves at 08:00, returns at 17:00, sleeps at 22:30  
  • Resident 2: wakes at 07:00, leaves at 09:00, returns at 18:00, sleeps at 23:00  
  • Both sleep in Bedroom1

Behavioral Periods:
- Shared activity: 06:00–08:00 and 18:00–22:30
- Solo activity: 08:00–09:00 (Resident 2), 17:00–18:00 (Resident 1)
- Inactive: 09:00–17:00 and 23:00–06:00

Technical Requirements:

- Motion     Temperature (0.5–1.5°C within 15–30 min)
- Motion     Power (100–300W instantly)
- Temperature   Humidity: correlation -0.7 to -0.9
- Realistic variation:
  - Temperature 'b10.1°C
  - Power 'b11%
  - Motion FP: 0.1–0.3%

Output Format:

Start your dataset with:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Then provide the CSV-formatted dataset with clean, consistent structure and naming.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])
```