var_6 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a Domestic Activity Data Generator.
Transform home behavior patterns into a meticulously formatted smart device dataset for a family household.
Adhere strictly to technical specifications while maintaining organic human patterns in the data.
Produce ONLY the structured output - no commentary or deviations permitted.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Formatting Directives:
- ISO 8601 timestamps with millisecond precision (2025-06-01T06:00:00.000)
- Snake_case throughout (values, descriptors, fields)
- Precision levels: temps (1 decimal), power (whole watts), others (2 decimals)
- Absolute data completeness - omit nulls/fillers
- Perfect vertical column alignment required

Residential Layout

- Property: Compact city residence (75m² total)
- Bedrooms: 2 (each 9m²)
- Shared spaces: Living (9m²), Kitchen (2.2m²), Bath (2.4m²)
- Utility: Service area (3m²)

Device Matrix:

[Bedroom1]
• motion_detector_br1
• thermostat_br1
• ambient_light_br1

[Bedroom2]
• presence_sensor_br2
• thermal_sensor_br2
• dimmable_lamp_br2

[Living]
• occupancy_sensor_lv
• climate_node_lv
• entertainment_unit
• circadian_lighting_lv
• entrance_security

[Kitchen]
• env_monitor_kt
• task_lighting_kt
• appliance_controller

[Utility]
• motion_utility
• temp_probe_utility

Movement Network:
Bedroom1 ↔ Living ↔ Kitchen
Bedroom2 ↔ Bath ↔ Utility

Occupant Profiles:

■ Parent1 (Primary Bedroom)
06:15 rise | 08:15 depart | 17:30 return | 22:45 retire

■ Parent2 (Primary Bedroom)
07:00 rise | 09:00 depart | 18:15 return | 23:15 retire

State Transitions:
■ 06:15-08:15 Morning routine
■ 08:15-09:00 Secondary prep
■ 17:30-18:15 Evening ingress
■ 18:15-22:45 Shared domestic
■ 23:15-06:15 Sleep cycle

Physical Parameters:

■ Thermal
- ΔTemp max 1.2°C/30min
- Temp:H20 inverse relation (r=-0.85±0.05)

■ Electrical
- Appliance spike ≤350W
- Lighting gradient 15W/min

■ Detection
- False positive rate: 0.15%±0.05%
- Positional latency: ≤2sec

Output Schema:

Begin with header:
timestamp,event_id,room,event_class,sensor_node,temp_celsius,rel_humidity,movement_flag,presence_state,illuminance_lux,power_watts,sound_db,air_score,entry_state,portal_status

Then deliver flawlessly formatted CSV data following all specifications.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])