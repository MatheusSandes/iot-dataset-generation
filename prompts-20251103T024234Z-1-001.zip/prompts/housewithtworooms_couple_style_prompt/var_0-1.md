var_1 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a Residential IoT Data Synthesizer.
Create a rigorously formatted home automation dataset for a family of three.
Prioritize: temporal coherence, physical plausibility, and device interoperability.
Deliver only pristine CSV output without commentary or deviation from specifications.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Formatting Protocol:
- ISO 8601 timestamps with millisecond precision (2025-06-01T06:00:00.000)
- snake_case standardization for all fields and values
- Fixed decimal places: 1 for temperatures, 0 for integers
- Absolute value consistency (no nulls/placeholders)
- Machine-readable column alignment

Dwelling Configuration:

- Property Type: Compact city apartment (75m² total)

- Sensor Grid:

  ▸ Master Bedroom (12m²):
    - mm_wave_presence_bed1
    - environmental_sensor_bed1
    - smart_bulb_bed1

  ▸ Child Room (9m²):
    - pir_motion_bed2
    - climate_sensor_bed2
    - rgb_light_bed2

  ▸ Common Areas:
    - Open Plan Living (18m²):
      * ultrasonic_occupancy_living
      * multi_sensor_living
      * dimmable_light_living
      * streaming_device
      * electronic_lock

    - Galley Kitchen (6m²):
      * thermal_sensor_kitchen
      * task_lighting_kitchen
      * appliance_monitor_fridge

    - Utility Closet:
      * motion_detector_utility
      * temperature_probe_utility

Architectural Flow:
Bedroom1 ⇨ Living ⇨ Kitchen ⇨ Utility
Bedroom2 ⇨ Bathroom (unsensored)

Occupancy Patterns:

» Primary Resident:
- Active: 05:45–08:15 | 17:30–22:45
- Transition: 08:15–09:00 (prep)
- Absent: 09:00–17:30

» Secondary Resident:
- Active: 07:00–09:30 | 18:15–23:15
- Transition: 09:30–10:00
- Absent: 10:00–18:15

» Child:
- Active: 06:30–20:00 (intermittent)
- Sleep: 20:00–06:30

Physical Constraints:

- Thermal Dynamics:
  ±0.3°C/min change rate
  20.0–24.5°C operational range

- Power Signatures:
  Lighting: 50–150W step changes
  Appliances: 200–800W impulses

- Environmental Links:
  Temp ⇨ Humidity: -0.75±0.05
  Motion ⇨ Power: 0.8s latency

Dataset Schema:

Initialize with header row:
timestamp,event_id,zone,sensor_class,activation_source,temp_c,rel_humidity,presence_state,resident_count,illuminance_lux,power_w,acoustic_db,volatile_orgs,egress_state

Generate 24hrs of perfectly formatted sensor telemetry.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])