var_7 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a Precision Home Automation Architect.  
Transform these specifications into a flawlessly structured dataset showing a day in our smart home scenario.  
Deliver only perfectly formatted, realistic sensor data without commentary or deviation from requested patterns.  
"""),
    HumanMessagePromptTemplate.from_template(r"""
Formatting Rules:
- ISO 8601 timestamps with millisecond precision (2025-06-01T06:00:00.000)
- Snake_case for all fields (e.g., "occupancy_status" not "Occupancy")
- Two decimal maximum for all measurements (e.g., "22.50" not "22.5" or "22.498")
- Strict RFC 4180 CSV compliance with quoted strings
- Sequential timestamps with realistic duration variance (±3s noise)

Environment Blueprint:

█ Dwelling Structure:
Split-level urban dwelling (Total: 45.5m²)  
Rooms:  
• MasterSuite (9m²) ← Resident pair  
• JuniorRoom (9m²) ← Child  
• SocialZone (9m²) ← Kitchenette/Lounge  
• UtilityCell (2.16m²) ← Laundry/HVAC  

≡ Device Network:  
⊛ MasterSuite:  
  - presence_array_ms  
  - thermal_unit_ms  
  - smart_panel_ms  

⊛ JuniorRoom:  
  - motion_matrix_jr  
  - thermal_unit_jr  
  - smart_panel_jr  

⊛ SocialZone:  
  - home_theater_sz  
  - illumination_grid_sz  
  - thermal_unit_sz  
  - portal_lock_sz  

⊛ UtilityCell:  
  - motion_matrix_uc  
  - thermal_unit_uc  

⊸ Proximity Graph:  
MasterSuite ↔ SocialZone  
JuniorRoom ↔ UtilityCell  
UtilityCell ↔ SocialZone  

△ Resident Patterns:  
Primary: 06:15–23:45  
  │─ Departure: 07:45–08:15  
  │─ Homebound: 16:30–17:30  
Secondary: 07:00–23:20  
  │─ Departure: 08:45–09:15  
  │─ Homebound: 17:45–18:45  

Expanded Data Signature:

timestamp,event_code,zone,event_category,source_node,temp_c,humidity_pct,motion_state,occupancy_count,illumination_lux,load_watt,audio_db,aqi_index,portal_state,fenestration_status  

Expect perfectly aligned columns with these constraints:  
- Temperature Δ ≤ 0.5°C per 5 minutes  
- Wattage steps = [45, 60, 75, 100, 125, 150, 200]  
- false_positive_rate ∈ [0.08%, 0.25%]  
- 15–37 minute activity cycles  

Generate the full compliant dataset beginning with the header row.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])