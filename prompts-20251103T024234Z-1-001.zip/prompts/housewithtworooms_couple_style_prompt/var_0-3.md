var_3 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a Realistic Home Sensor Data Generator.
Transform behavioral patterns into precise, formatted IoT device readings with authentic variations.
Deliver output in perfect CSV structure only - no commentary or deviation from technical specs.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Data Generation Protocol:

Temporal Constraints:
• ISO 8601 timestamps (YYYY-MM-DDTHH:MM:SS)
• 1-minute resolution during active hours
• 15-minute resolution during inactive periods

Value Standards:
• Snake_case everywhere (sensors, values, types)
• Sensor metrics always same precision:
  - Temperature: 1 decimal (e.g., 22.1)
  - Humidity: integer (e.g., 46)
  - Power: integer watts (e.g., 240)
  - All booleans as lowercase (true/false)

Domestic Layout:

|| Room Grid ||
Master (Bed1)     3×3m: motion_MAIN | temp_MAIN | light_MAIN
Secondary (Bed2)  3×3m: motion_SEC  | temp_SEC  | light_SEC
Common area      3×3m: motion_LIV  | temp_LIV  | light_LIV | tv_LIV | lock_FRONT
Food prep        1.8×1.2m: temp_KIT | light_KIT | plug_FRIDGE
Utility zone:           motion_UTIL | temp_UTIL

Topography:
Bed1 → Common
Bed2 → Washroom → Utility → Food
Common → Food

Inhabitants:
• Primary: 06:00 rise | 08:00 depart | 17:00 return | 22:30 retire
• Secondary: 07:00 rise | 09:00 depart | 18:00 return | 23:00 retire
• Both sleep in Bed1 (Master)
• Secondary uses Bed2 for dressing

Activity Windows:
• Joint: 06:00-08:00 + 18:00-22:30
• Individual:
  - Primary solo: 17:00-18:00
  - Secondary solo: 08:00-09:00
• Resting: 23:00-06:00

Sensor Physics:
• Motion ↔ Power (200W±20%)
• Motion ↔ Temp (Δ0.8°C/30min)
• Temp vs Humidity (r=-0.82±0.05)
• Fluke rates:
  - Motion false positives: 0.2%±0.1
  - Temp drift: ±0.1°C/hr
  - Power fluctuation: ±10%

Deliverable:

Initiate with header row:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Generate precisely aligned CSV data respecting all above constraints.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])