
var_5 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a Home Automation Data Synthesizer.
Transform raw specifications into polished, residential IoT data streams with meticulous formatting.
Key objectives:
1. Generate realistic patterns for a 2-bedroom dwelling
2. Maintain machine-readable precision
3. Enforce strict stylistic conventions
4. Output ONLY the formatted dataset without commentary
"""),
    HumanMessagePromptTemplate.from_template(r"""
Formatter Specifications:

- Temporal Format: ISO 8601 (YYYY-MM-DDTHH:MM:SS)
- Lexical Style: snake_case exclusively
- Numerical Standardization:
  - Temperatures to 1 decimal (e.g. 22.5)
  - Percentages as integers (e.g. 45)
  - Wattage values rounded to whole numbers

Residence Schema:

|| AREA LAYOUT ||
- Bed chambers (3×3m):
  • Master Bedroom (south-west):
    • motion_detector_mbr
    • thermostat_mbr
    • led_mbr
  • Child's Room (south-east)
    • motion_detector_cr
    • thermostat_cr  
    • led_cr

- Common Spaces:
  • Great Room (3×3m, central):
    • motion_detector_lr
    • thermostat_lr
    • smart_panel_lr
    • ambient_led_lr  
    • deadbolt_door
  • Food Prep Zone (1.8×1.2m, north-east):
    • thermostat_kt
    • task_light_kt
    • appliance_monitor_fridge

- Utility Zone:
  • motion_detector_util
  • thermostat_util

- Hygiene Chamber: Unsensored

Resident Patterns:
⊚ Primary Occupant:
  - Awake: 06h00–22h30
  - Absent: 08h00–17h00
⊚ Secondary Occupant:  
  - Awake: 07h00–23h00
  - Absent: 09h00–18h00
⊚ Minor Occupant:
  - Present continuously

Physical Dynamics:
▲ Temperature Flux:
  - Δ ≤1.2°C per 30m window
  - Inverse humidity (-0.8±0.1 coefficient)
◉ Energy Signatures:
  - Baseline: 80–120W
  - Active: +150–250W on detection
⚠ Error Margins:
  - Thermometers: ±0.3°C
  - Motion: 99.7–99.9% accuracy

CSV Construction Rules:

Initialize with header:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Then generate flawlessly aligned data rows matching these specifications exactly.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])