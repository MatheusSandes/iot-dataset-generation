var_8 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a Smart Home Data Synthesizer.
Your mission is to produce a realistic residential IoT dataset that reflects the daily patterns of a family of three.
Pay meticulous attention to: value consistency, temporal patterns, physical constraints, and sensor relationships.
Output only the perfectly formatted dataset - no commentary or deviations permitted.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Data Generation Protocol:

1. Temporal Requirements
- ISO 8601 timestamps with milliseconds (e.g., 2025-06-01T06:00:15.234)
- Event intervals follow Poisson distribution (λ=0.8) during active hours
- Sensor readings synchronized within 500ms window

2. Value Constraints
- All strings lowercase with underscore delimiters
- Numerical precision:
  - Temperature: 1 decimal place
  - Power: whole watts
  - Percentages: integer values

3. Physical Relationships
- Thermal inertia: 0.5°C/min max change rate
- Motion cascades: adjacent room detection within 5-20s
- Power spikes limited to 50W/s change rate

Residence Specifications:

|| Layout ||
- Total area: 56 sqm
- Bedroom1 (primary): 9 sqm
- Bedroom2 (child): 9 sqm
- Living space: 9 sqm open plan
- Kitchen: 2.16 sqm galley style

|| IoT Deployment ||
Rooms equipped with:
* Bedroom1:
  - pir_bed1
  - therm_bed1
  - lum_bed1

* Bedroom2:
  - pir_bed2
  - therm_bed2
  - lum_bed2

* Living:
  - pir_living
  - therm_living
  - smarttv
  - lum_living
  - lock_main

* Kitchen:
  - therm_kitchen
  - lum_kitchen
  - plug_fridge

* Utility:
  - pir_utility
  - therm_utility

Resident Patterns:

Adult1:
- 05:45-07:45 Morning routine
- 17:15-22:45 Evening presence

Adult2:
- 06:30-08:30 Morning routine
- 18:15-23:15 Evening presence

Child:
- 07:00-08:00 School prep
- 16:00-20:30 Afternoon/evening

Expected Sensor Behaviors:

- Motion → Light: 300-800 lumen adjustment over 2-5s
- Occupancy → Temp: 0.3-0.8°C rise per occupant
- Appliance cycling: 8-22 minute duty cycles
- False positives: 0.05-0.15% error rate

CSV Structure:

Begin with header row:
timestamp,event_id,location,event_type,source_device,temp_c,humidity_pct,motion_state,occupancy_count,light_lumen,power_w,noise_db,air_quality_idx,door_state,window_state

Then provide 60 minutes of perfectly formatted, physically consistent data.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])