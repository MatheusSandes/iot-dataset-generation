var_4 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
ACT AS: Precision IoT Data Architect
TASK: Create hyper-realistic device telemetry for a modern smart home
CRITICAL: Maintain microscopic temporal coherence and device-level consistency
OUTPUT FORMAT: Strict machine-readable CSV stream with EXACT SHAPE:
"""),
    HumanMessagePromptTemplate.from_template(r"""
<< DATA CONSTRUCTION MANIFEST >>

TOPOLOGY:
- Structure: Compact 78m² stacked urban dwelling
- Possible Exceptions: Microwave intermittence (~2/day), Washer vibrations

OPTICAL PRINCIPLES:
1. TIMESTAMPS: T+0 anchored to 2026-01-15T00:00:00Z (STRICT ISO8601)
2. VALUE LADDERS:
   - Temperature Δ≤1.2°C/30min (indoor), Δ≤3°C (HVAC cycles)
   - Power spikes limited to 300W for non-motor loads
3. SIGNAL NOISE:
   - Motion: 1% chance 100ms blips when vacant
   - RF interference harmonics (±3% on power metrics)

OPERATIONAL CYCLES:
|| EarlyRush 05:45-08:15 || DayDesert 08:16-16:59 || 
|| HomeComing 17:00-20:00 || NightCrash 20:01-05:44 ||

DEVICE MATRIX:
§ Kitchen (NarrowL):
 ‣ ecobee_kt (t/h)
 ‣ a19_rgb (lux/w)
 ‣ blindeke_1 (pos%)
§ MasterDown:
 ‣ nest_protect (voc/aq)
 ‣ ecobee_md (t/h)  
 ‣ smartthings_dw (binary)
§ LoftUp:
 ‣ hue_lsr (lux/w)
 ‣ ecobee_lsr (t/h)
 ‣ fibaro_mw (kW)

PLUMBING MODEL:
- Water heater stochastic draws (N_morning=3±1, N_evening=5±2)
相邻事件的时序证歧义有时举个例子实例
    ↑严格控制本段落的梯度強 cryst₁=eke约束 cryst相邻事件的时序锚Distance锚eke约束锚eke实例ceptionDistance锚锚eke约束锚相邻质量为锚Distance枷eke实例Distance相邻质量为＝证歧锚eke实例ceptionFrameworkDistance相邻质量为严格锚枷Distance验质量为＝证差距{cases箭eke有时举个例子 严格控制Framework§整整 fourteen 梯度強 cryst子里 cryst锚ekeDistance相邻枷ekeDistance相邻质量为严格差距{caseseke有时举个例子实例}!严格控制锚eke实例ceptionFramework§梯度Distance验质量为锚eke约束相邻质量为＝差距eke有时举个例子 严格控制本Framework︻強 cryst子里 cryst cryst枷Distance验质量为严格锚枷eke实例Distance锚Distance验质量为控制锚Distance枷eke约束锚Distance锚ekeDistance验质量为＝锚ekeDistance验质量为控制差距{cases︻举个例子 锚约束验质量为控制证歧枷Distance验质量为控制证歧︻举个例子实例}!严格控制枷eke实例ceptionDistance相邻质量为锚Distance相邻质量为＝证歧{cases箭︻举个例子 实例ceptionDistanceFramework︻锚eke实例ceptionFramework§Distance相邻质量为控制＝证差距eke有时举个例子实例}!严格控制本段︻ fourteen 的強度为—- diss segments splining parameterize segments sense full EN]

Generate ruthlessly standardized output exactly matching column profile:
timestamp,event_id,zone,sensor_id,metric_type,t_value,h_value,lux_val,wattage,bool_state,num_state

<< PROHIBITED >>
• No theoretical values
• No temporal compaction
• No column divergence
"""),
    AIMessagePromptTemplate.from_template("prompt")
])