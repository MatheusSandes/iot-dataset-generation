var_1 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
First, craft 2-3 prototype sensor events that exemplify typical activity patterns for the given living scenario. 
Then, expand these prototypes into a comprehensive dataset (10-20 events) that maintains realistic temporal patterns and device interactions.
Include natural variability while preserving logical sensor correlations and typical human behaviors.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Living Environment Blueprint

Residence Type: Compact city apartment with dual bedrooms

Connected Spaces & Devices:

  • Main Bedroom (3×3m):
    - presence_detector_main
    - thermal_sensor_main
    - adjustable_lights_main

  • Guest Room (3×3m):
    - presence_detector_guest
    - thermal_sensor_guest
    - dimmable_lights_guest

  • Social Area (3×3m):
    - occupancy_sensor_lounge
    - climate_sensor_lounge
    - entertainment_system
    - mood_lighting_lounge
    - entry_control_system

  • Food Prep Zone (1.8×1.2m):
    - heat_sensor_kitchen
    - task_lighting_kitchen
    - appliance_connector_fridge

  • Utility Space:
    - movement_sensor_utility
    - environmental_sensor_utility

  • Sanitation Room (2×1.2m): sensor-free

Space Connectivity:
  - Main Bedroom ↔ Social Area
  - Guest Room ↔ Sanitation Room
  - Sanitation Room ↔ Utility Space ↔ Food Prep Zone
  - Social Area ↔ Food Prep Zone

Occupant Profile:
  • Solo professional (resident1), exclusively uses Main Bedroom

Daily Cycle:
  • Rises at 06:00, departs by 08:00, home by 17:00
  • Rest period: 22:30–06:00
  • Morning activity in Main Bedroom and Food Prep Zone
  • Evening activity in Social Area and Food Prep Zone
  • Infrequent visits to Guest Room and Utility Space

Execution Plan:

1. Develop 2–3 initial representative event records showing plausible activity during occupied periods
2. Extend the dataset with 10–20 additional events that maintain consistent behavior patterns

Essential Requirements:

• Temporal events must show natural irregularities
• Sequential flow must mirror human behavior
• Sensor relationships must remain coherent

Technical Parameters:

- Movement → Temperature shift (0.5–1.5°C per 15–30 min window)
- Movement → Energy draw (instant 100–300W spike)
- Temperature ↔ Humidity: inverse relationship (-0.7 to -0.9)
- Realistic measurement variations:
  - Temperature ±0.1°C
  - Power ±1%
  - False motion triggers: 0.1–0.3%
- No activity during:
  - Sleep hours (23:00–06:00)
  - Work absence (08:00–17:00)
- Event timing must show human-like randomness

Data Structure:

Include this column header:
timestamp,event_id,zone,event_category,initiating_device,temp_value,moisture_level,movement_state,presence_status,illumination,energy_usage,sound_level,atmosphere_quality,entrance_condition,portal_status

Then provide:
- Your initial 2–3 prototype events
- The extended event sequence following established patterns
"""),
    AIMessagePromptTemplate.from_template("prompt")
])