var_5 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
First craft 3 distinct sensor event examples that accurately depict resident behavior for this smart home scenario.
Using these as behavioral anchors, expand into a comprehensive 15-25 event sequence that maintains temporal logic and device interactions.
Incorporate natural deviations while preserving core behavioral rhythms and sensor correlations.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Residence Blueprint

✦ Architecture: Compact 2-bedroom urban dwelling (42m² total)

✦ Sensor Network:

  ▸ Primary Bedroom (9m²):
    - occupancy_bed1 (mmWave)
    - climate_bed1 (temp/humidity)
    - dimmer_light1 (0-100%)

  ▸ Secondary Bedroom (9m²):
    - motion_bed2 (PIR)
    - thermo_bed2
    - standalone_lamp2

  ▸ Social Zone (9m²):
    - presence_living (3D sensor)
    - enviro_living
    - mood_lights (RGB)
    - entertainment_unit
    - entry_system

  ▸ Food Prep Area (2.1m²):
    - ambient_kitchen
    - undercabinet_leds
    - appliance_monitor

  ▸ Utility Space:
    - motion_utility
    - temp_utility

  ▸ Hygiene Room (2.4m²): Unsensored

✦ Spatial Relationships:
  - Bed1 ↔ Social
  - Bed2 ↔ Hygiene ↔ Utility ↔ Food
  - Social ↔ Food

✦ Occupant Profile:
  - Solo resident (PersonA) using Bed1 exclusively
  - Strict circadian rhythm:
    ↑ 06:00 | 🏠→ 08:00 | ←🏠 17:00 | ↓ 22:30
  - Evening patterns:
    - 17:30-19:30: Food prep + dining
    - 20:00-22:00: Media consumption
    - Weekly laundry (Utility)

Generation Protocol:

❶ Create 3 prototype events demonstrating:
   - Morning wake sequence
   - Evening relaxation pattern
   - Sporadic secondary room access

❷ Extend to 15+ events showing:
   - Gradual climate shifts
   - Appliance power signatures
   - Occupancy propagation
   - Randomized but plausible timings

Data Integrity Rules:

▸ Physical Constraints:
  - Thermofluctuations: 0.4-0.8°C/20min
  - Device activations within 8s of motion
  - Power spikes (150-350W) on engagement

▸ Environmental Dynamics:
  - Inverse temp-humidity coupling (-0.75±0.1)
  - Baseline noise:
    * Climate: ±0.15°C
    * Energy: ±2.3%
    * False detections <0.4%

▸ Temporal Boundaries:
  - Dead zones: 23:30-05:45 & 08:15-16:45
  - Event timestamps show human pacing (±3-9min)

Data Schema:

Begin with header row:
timestamp,event_id,zone,event_class,origin_sensor,celcius,rh%,movement,presence,illumination,wattage,acoustics,aqi,entrance_state,portal_status

Then provide:
- Initial 3 template events
- Sequential expansion maintaining behavioral fidelity
"""),
    AIMessagePromptTemplate.from_template("prompt")
])