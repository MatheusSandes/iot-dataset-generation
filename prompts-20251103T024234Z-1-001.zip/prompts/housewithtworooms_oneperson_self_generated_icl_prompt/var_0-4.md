
var_4 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
First, craft 2-3 authentic sensor event examples that capture the essence of daily life in the described smart home.
Using these as behavioral prototypes, extrapolate a comprehensive dataset (10-20 additional events) that maintains:
- Consistent activity patterns
- Realistic timing variations
- Logical sensor correlations
- Environmental interactions
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Blueprint

<< Residential Profile >>
• Type: Compact urban dwelling (60m² total)
• Occupant: Solo professional (person1)
   - Sleeps in Bedroom1
   - Work hours: 08:00-17:00 (weekdays)
   - Active periods: 06:00-08:00 & 17:00-22:30

<< Sensor Deployment >>

[Bedroom1]
- motion_detector_B1
- thermal_sensor_B1
- adjustable_light_B1

[Bedroom2] (Spare Room)
- presence_sensor_B2
- climate_sensor_B2

[Living Space]
- occupancy_sensor_LR
- environmental_sensor_LR
- entertainment_system
- dimmable_light_LR
- entry_lock

[Kitchen Zone]
- heat_sensor_KT
- task_light_KT
- appliance_monitor_fridge

[Utility Area]
- motion_alarm_UT
- temp_sensor_UT

<< Spatial Connections >>
Bedroom1 ↔ Living Space
Bedroom2 ↔ Bathroom ↔ Utility ↔ Kitchen
Living Space ↔ Kitchen

<< Behavioral Parameters >>
1. Morning Routine (06:00-08:00):
   - Primary activity in Bedroom1 & Kitchen
   - Brief transitions through Living Space

2. Evening Routine (17:00-22:30):
   - Extended Living Space usage
   - Kitchen activity during meal times
   - Rare Bedroom2/Utility access

3. Environmental Considerations:
   - Temperature fluctuations: ±1°C per 15-30min
   - Device power signatures:
     - Lights: 60-120W
     - Electronics: 50-500W
   - Sensor imperfections:
     - Temp accuracy: ±0.3°C
     - False motion detection: 0.2% probability

<< Construction Methodology >>
Phase 1: Create 2-3 foundational events demonstrating:
   - Natural activity sequences
   - Sensor interdependencies
   - Temporal variations (±5min)

Phase 2: Expand dataset while ensuring:
   - Time constraints preserved
   - Behaviorally consistent patterns
   - Realistic sensor noise
   - No events during sleep/work absences

<< Output Specifications >>
Required Header:
timestamp,sensor_id,location,event_category,activated_sensor,temp_C,humidity_pct,motion_state,occupancy_status,light_intensity,power_watts,sound_db,air_quality_idx,door_position,window_position

Then provide:
1. Your initial prototype events
2. Extended dataset maintaining identical behavioral fingerprints
"""),
    AIMessagePromptTemplate.from_template("prompt")
])