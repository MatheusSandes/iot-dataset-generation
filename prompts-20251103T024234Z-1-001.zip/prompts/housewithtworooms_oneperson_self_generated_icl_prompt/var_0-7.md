var_7 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
First, analyze the living patterns and spatial relationships between rooms in the given smart home scenario.
Create 3-5 key behavioral examples showing typical resident interactions with different smart devices.
Then extrapolate these interaction patterns to build a comprehensive 24-hour event log that maintains:
- Device state dependencies
- Activity timing probabilities
- Environmental condition progressions
"""),
    HumanMessagePromptTemplate.from_template(r"""
Living Environment Blueprint

[Residence Profile]
- Structural Layout:
  • Private Spaces: B1 (3x3), B2 (3x3), Bath (2x1.2)
  • Shared Spaces: LR (3x3), Kit (1.8x1.2), SA
  • Movement Paths:
    → B1↔LR↔Kit
    → B2↔Bath↔SA↔Kit

[IoT Deployment]
- Environmental Monitoring:
  • Temperature nodes: All rooms
  • Motion triggers: Living zones + accessways
- Device Network:
  • Lighting: Bedrooms + communal areas
  • Activated during:
    - Morning prep (B1+Kit)
    - Evening relax (LR+Kit)

[Inhabitant Pattern]
- Temporal Model:
  • Dark hours: 23:00-06:00 (sleep)
  • Away hours: 08:00-17:00 (work)
  • Transition buffers: ±30min for routines

Data Construction Requirements:

1. Initialize with 3 prototype events showing:
   - Causality chains (motion→light→power)
   - Environmental drift patterns
   - Transition state timings

2. Scale to full day cycle (18-24 events) preserving:
   - Device activation sequences
   - Thermal dynamics (Δ0.5-1.5°C/15-30min)
   - Absence indicators (baseline states during no activity)

3. Statistical Constraints:
   - Energy usage: Lighting 8-15W standby → 100-300W active
   - Sensor error:
     ✓ Temp: ±0.3°C variation
     ✓ Motion: 1-3 false positives/day
     ✓ Power: ±5% metering fluctuation

Output Specifications:

Begin with metadata headers:
timestamp,zone,node_activated,event_chain,thermal_state,power_state,presence_marker

Then provide:
- 3-5 paradigm events demonstrating interaction logic
- 15+ derived events showing progressive home states
- Required null states during inactive periods
"""),
    AIMessagePromptTemplate.from_template("prompt")
])