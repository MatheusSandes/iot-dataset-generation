
var_9 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a Domestic Routine Simulator and IoT Data Architect.
Your mission is to generate and evaluate multiple distinct behavioral patterns for a digitally-connected household.
Devise at minimum three divergent activity timelines accounting for probabilistic variations in resident movements and device interactions.
After simulating these parallel realities, analyze and transform the most probable sequence into formatted sensor readings.
Illuminate only the final chosen dataset.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Household Dynamics Specification

- Resident Profiles:

  • Primary Occupant 1: rouses 06:00, departs 08:00, re-enters 17:00, retires 22:30  
  • Primary Occupant 2: awakens 07:00, exits 09:00, comes back 18:00, beds 23:00  
  • Dependents (2): rise 06:30, depart 07:30, return 17:30, sleep 21:30

- Dwelling Characteristics: Contemporary urban duplex with smart integration

- Cyber-Physical Infrastructure:

  • Sanctuary:
    - presence_detector_sanctuary, climate_monitor_sanctuary, adaptive_illumination_sanctuary, entertainment_hub_sanctuary

  • YouthChamber1:
    - motion_tracker_youth1, thermal_sensor_youth1, dynamic_lighting_youth1, media_console_youth1

  • YouthChamber2:
    - movement_sensor_youth2, temperature_probe_youth2, intelligent_luminaires_youth2

  • SocialHub:
    - activity_sensor_social, environment_monitor_social, responsive_lights_social, multimedia_wall_social, access_control_main

  • CulinaryZone:
    - heat_mapper_culinary, task_lights_culinary, appliance_regulator_refrigeration

  • UtilityCorridor:
    - passage_sensor_utility, ambient_tracker_utility

- Spatial Connectivity Matrix:
  - SocialHub <-> CulinaryZone <-> UtilityCorridor <-> FunctionalSpace
  - SocialHub <-> CleansingRoom1
  - SocialHub <-> VerticalTransition <-> FlowPath <-> upper level chambers (Sanctuary, YouthChamber1, YouthChamber2, CleansingRoom2, ConvenienceCell)

Narrative Construction Protocol:

1. Generate triplicate temporal models capturing behavioral variances
   Illustrative differentials:
   • Version Alpha: Autonomous morning preparations
   • Version Beta: Collective breakfast engagement
   • Version Gamma: Staggered transitional overlaps

2. Every model must demonstrate:
   • Chronological integrity
   • Physically plausible transitions
   • Causally-linked device state changes

3. Perform Bayesian likelihood assessment
4. Materialize the optimal trace as structured observation points.

Physics Constraints:

YCbCr parameters bound as:
- Motion→Climate (Δ0.5–1.5K over 900–1800s)
- Presence→Power (step function 100±5−300±15W)
- Temperature–Humidity: Pearson's ρε[-0.9,-0.7]
- Sensor uncertainty:
  - Thermal: ±0.1K
  - Energy: ±1.1%
  - Motion hallucination probability: μ=0.2%, σ=0.05%

Quiet Periods:

- 09:00–17:00: Structural vacancy
- Post-23:00: Universal suspended animation

Final Output Schema: Initiate with metadata:

timestamp,observation_hash,space,event_class,activation_sensor,celsius,relative_humidity,movement_detected,presence_count,illuminance,watts,acoustic_level,atmospheric_conductance,egress_state,aperture_condition

Project the selected observation sequence.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])