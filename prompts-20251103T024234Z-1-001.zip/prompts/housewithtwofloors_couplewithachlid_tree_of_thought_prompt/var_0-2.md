var_1 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
As a Home Behavior Simulation Expert, your role is to create diverse possible timelines of smart home interactions for a typical urban household.
Generate multiple alternate scenarios (minimum 3 distinct versions) that vary in resident behaviors and device activations, then determine the most probable sequence to transform into structured time-series data.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Household Dynamics Simulation Brief

Resident Profiles:

◈ Primary Caregiver:
  - Sleeps: 22:00–05:30
  - Commute: Departs 08:30, Returns 16:45

◈ Secondary Caregiver:
  - Sleeps: 23:15–06:45
  - Commute: Departs 09:15, Returns 18:30

◈ Two School-Age Children:
  - Sleep: 21:00–06:15
  - School Transport: Leaves 07:45, Returns 15:00–16:00

Property Specifications:

◆ Smart Dwelling Type: Modern 2-level townhome with automated systems

Device Inventory:

★ Private Quarters (Upper Level):
  - Master Suite: multi-sensor array (motion/thermal/lighting/AV)
  - Child Rooms: environmental sensors with independent lighting controls

★ Common Areas (Ground Level):
  - Gathering Space: omnidirectional motion scanning + climate tracking
  - Food Preparation Zone: appliance monitoring + task lighting
  - Entry Points: access control systems + security sensors

Inter-Zone Pathways:

Ground Floor:
Living Hub ↔ Culinary Space ↔ Utility Cluster ↔ Sanitation Area

Vertical Access:
Central Staircase connects to all upper-level private spaces

Simulation Methodology:

1. Create parallel timeline alternatives considering:
   - Variations in morning preparation sequences
   - Different evening relaxation patterns
   - Alternative occupancy distributions when home

2. For each scenario ensure:
   - Chronological integrity matched to individual schedules
   - Physically plausible room transitions
   - Realistic device interaction sequences

3. Evaluate and select the highest probability scenario
4. Encode as temporal event stream

Technical Parameters:

Sensor Characteristics:
- Thermal measurements fluctuate ±0.8°C hourly
- Load variations: ±15% nominal for active devices
- Motion detection reliability: 92–97%
- Environmental correlations:
  - Temp vs Humidity: -0.75±0.1
  - Activity vs Power: 0.6±0.2

Quiet Periods:
- 09:30–15:00: Minimum occupancy
- 23:30–05:30: Sleep mode

Data Specifications:

CSV Header Requirement:
epoch,event_uid,zone,interaction_category,initiator,ambient_temp,relative_humidity,movement,presence_count,illumination,energy_draw,acoustic_level,particulate_reading,egress_state,fenestration_status

Provide only the optimal scenario's dataset.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])