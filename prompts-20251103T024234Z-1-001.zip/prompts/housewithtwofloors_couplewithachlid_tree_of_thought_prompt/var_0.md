```python
var_0 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a Smart Home Planner and Behavioral Data Engineer.
Your task is to simulate multiple plausible branches of smart home activity for a family of four.
You will construct at least three different paths (event trees) based on the daily routine of the residents, then select the most realistic one and convert it into a structured dataset.
Each branch should represent a different variation in timing or transitions.
Only output the final selected dataset.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Scenario Configuration

- Family Members:

  • Adult 1: wakes 06:00, leaves 08:00, returns 17:00, sleeps 22:30  
  • Adult 2: wakes 07:00, leaves 09:00, returns 18:00, sleeps 23:00  
  • Child 1 and Child 2: wake 06:30, leave 07:30, return 17:30, sleep 21:30

- House Type: Two-story urban smart home

- Devices by Room:

  • MasterSuite:
    - motion_sensor_suite, temp_sensor_suite, smart_light_suite, smart_tv_suite

  • Bedroom1:
    - motion_sensor_bedroom1, temp_sensor_bedroom1, smart_light_bedroom1, smart_tv_bedroom1

  • Bedroom2:
    - motion_sensor_bedroom2, temp_sensor_bedroom2, smart_light_bedroom2

  • LivingDining:
    - motion_sensor_living, temp_sensor_living, smart_light_living, smart_tv_living, smart_lock_front

  • Kitchen:
    - temp_sensor_kitchen, smart_light_kitchen, smart_plug_fridge

  • ServiceArea:
    - motion_sensor_service, temp_sensor_service

- Room Connectivity:
  - LivingDining   Kitchen   ServiceArea   UtilityRoom
  - LivingDining   Bathroom1
  - LivingDining   Stairs   Circulation   all upstairs rooms (MasterSuite, Bedroom1, Bedroom2, Bathroom2, WC)

Tree Generation Strategy:

1. Internally simulate three alternative paths based on household routines.
   Example distinctions:
   • A) Children prepare in separate bedrooms
   • B) All gather in kitchen early
   • C) Parent remains briefly in LivingDining after others depart

2. Each tree should follow:
   • Proper timing per resident
   • Natural transitions between rooms
   • Logical activation of motion, temperature, lights, and power

3. Select the most plausible tree.
4. Convert that tree into a dataset.

Technical Guidelines:

- Motion     Temperature (0.5–1.5°C within 15–30 min)
- Motion     Power (100–300W instantly)
- Temp   Humidity: correlation -0.7 to -0.9
- Sensor noise:
  - Temperature 'b10.1°C
  - Power 'b11%
  - Motion false positive rate: 0.1–0.3%

Inactive Periods:

- 09:00–17:00: House is empty
- After 23:00: All asleep

Output Format:

Start with this header:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Then output the dataset from the best tree branch.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])
```