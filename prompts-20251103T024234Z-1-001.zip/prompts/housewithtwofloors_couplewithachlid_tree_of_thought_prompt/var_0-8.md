var_8 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a Data-Driven Home Automation Architect.
Your mission is to generate and evaluate multiple dynamic smart home activity sequences for a modern family.
Develop three distinct behavioral timelines, assess their realism, then transform the optimal one into structured IoT sensor data.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Residential Simulation Parameters

- Household Composition:
  ▪ Primary Resident: 06:00 wake | 08:00 departure | 17:15 return | 22:15 bedtime
  ▪ Secondary Resident: 07:15 wake | 09:15 departure | 18:30 return | 23:15 bedtime
  ▪ Two Dependents: 06:45 wake | 07:45 departure | 16:45 return | 21:15 bedtime

- Property Details:
  Two-level connected home with smart infrastructure

- Digital Ecosystem:
  
  [PRIMARY ZONE] MasterBedroom:
  • occupancy_sensor, thermal_sensor, adaptive_lighting, entertainment_system
  
  [SECONDARY ZONES] Children's Rooms:
  • room1: presence_detector, climate_sensor, smart_bulb
  • room2: presence_detector, climate_sensor, smart_bulb, white_noise_device
  
  [COMMUNAL AREAS] LivingSpace:
  • people_counter, environmental_sensor, mood_lighting, media_center, access_control
  
  [UTILITY SPACES] ServiceZones:
  • kitchen: appliance_monitor, task_lighting, refrigeration_power_tracker
  • laundry: motion_alert, thermal_sensor

- Spatial Relationships:
  Ground Floor: LivingSpace ↔ Kitchen ↔ Laundry ↔ GuestWC
  Upper Floor: MasterBedroom ↔ ChildrenRooms ↔ FamilyBathroom
  Linked via: CentralStaircase

Simulation Methodology:

1. Create three divergent daily narratives considering:
   • Variant Alpha: Sequential morning routines
   • Variant Beta: Congregated family interactions
   • Variant Gamma: Unusual activity deviations

2. Each scenario must maintain:
   • Chronological integrity
   • Spatially plausible transitions
   • Device activation coherence

3. Designate the most probable scenario.
4. Emit sensor data stream for selected scenario.

Technical Specifications:

- Environmental Dynamics:
  Temperature Δ 0.4–1.6°C / 20min
  Relative Humidity 40–65%
  
- Energy Signatures:
  Lighting Load 50–250W
  Appliance Surge 150–400W

- Sensor Characteristics:
  Thermal Accuracy ±0.3°C
  Power Measurement ±2% error
  2–5% false-positive motion events

Quiet Periods:
• 09:30–16:45: Minimal occupancy
• Post-23:15: Sleep cycle

Output Schema:
[ISO Timestamp],[Event UUID],[Zone],[Event Category],[Source Sensor],[Ambient Temp (°C)],[Humidity (%)],[Motion State],[Occupant Count],[Illuminance (lx)],[Power Draw (W)],[Acoustic Level (dB)],[AQI],[Entry Status],[Fenestration State]

Deliver the optimized sensor dataset.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])