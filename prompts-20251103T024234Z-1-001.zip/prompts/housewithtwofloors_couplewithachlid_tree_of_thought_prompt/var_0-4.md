
var_4 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a Domestic Activity Pattern Simulator specializing in generating realistic smart home sensor data.
For the given family scenario, create three distinct daily activity timelines with measurable home automation events.
Evaluate these timelines and transform the most believable one into structured sensor readings.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Household Configuration Profile

Resident Profiles:

- Primary Caregiver (PCG):
  • Rise: 05:45 | Depart: 08:15 | Return: 17:15 | Sleep: 22:45
- Secondary Caregiver (SCG):
  • Rise: 06:45 | Depart: 09:15 | Return: 18:15 | Sleep: 23:15
- Dependents (DP1 & DP2):
  • Rise: 06:15 | Depart: 07:45 | Return: 17:45 | Sleep: 21:45

Residence Specifications:
- Architecture: Contemporary urban duplex
- Smart Ecosystem:

  • Sleep Quarters:
    - Master: motion, climate, lighting, media
    - Child1: motion, climate, lighting, media
    - Child2: motion, climate, lighting

  • Common Areas:
    - GreatRoom: motion, climate, lighting, entertainment, security
    - FoodPrep: climate, lighting, refrigeration
    - UtilityZone: motion, climate

Room Flow Diagram:
- GreatRoom ↔ FoodPrep ↔ UtilityZone ↔ Laundry
- GreatRoom → Washroom1
- GreatRoom → Staircase → UpperHall → All upper rooms

Timeline Generation Protocol:

1. Develop three diverging daily narratives varying:
   - Morning congregation points
   - Evening relaxation patterns
   - Occupant-specific route deviations

2. Criteria for each narrative:
   - Chronological accuracy
   - Spatial progression logic
   - Sensor activation sequences

3. After evaluation:
   - Choose the most anthropologically valid sequence
   - Generate corresponding device state transitions

Technical Parameters:

- Environmental Sensors:
  • Thermal variance: ±0.8°C per 20 min
  • Humidity-thermal correlation: r = -0.8 ±0.05
- Power Signatures:
  • Device activation: 80-350W instant
- Sensor Imperfections:
  • Thermal error: ±0.2°C
  • Power fluctuation: ±9%
  • Motion false positives: 15-25%

Quiet Periods:
- 09:30-17:00: Unoccupied
- Post-23:15: Sleep mode

Output Specification:

Data Header (include):
timestamp,event_id,zone,event_class,activated_sensor,temp_C,humidity_pct,motion_state,occupants,illuminance_lux,power_W,sound_db,air_quality_idx,door_state,window_state

Then provide the optimal dataset.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])