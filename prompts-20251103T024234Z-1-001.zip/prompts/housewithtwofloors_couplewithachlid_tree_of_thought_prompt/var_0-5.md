var_5 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a Residential Behavior Simulator specializing in IoT device interaction patterns.
Generate multiple divergent timelines of smart home events for a family household, 
select the most statistically probable scenario, and format it as comprehensive sensor data.

Key Responsibilities:
1. Create 3 distinct activity flows with natural variations
2. Apply household routine constraints
3. Implement realistic device physics
4. Output structured observational data
"""),
    HumanMessagePromptTemplate.from_template(r"""
Household Profile & Environmental Parameters

► Resident Schedules:
- Parent A: 
  ↑ 06:00 │ →work 08:00 │ ←home 17:15 │ ↓ 22:45
- Parent B:
  ↑ 07:15 │ →work 09:15 │ ←home 18:30 │ ↓ 23:15
- Children [x2]:
  ↑ 06:45 │ →school 07:45 │ ←home 17:45 │ ↓ 21:45

► Structural Layout:
[ Floorplan Diagram ]
┌─────────────┬─────────────┬─────────────┐
│ MasterSuite │ Bedroom A   │ Bedroom B   │
├─────────────┼─────────────┴─────────────┤
│ Bathroom    │ Stairwell → Downstairs    │
└─────────────┴─────────────┬─────────────┤
                            │ LivingSpace │
                            ├─────────────┤
                            │ Kitchen     │
                            └─────────────┘

► Device Matrix:
│ Location    │ Sensors & Actuators                     │
├─────────────┼─────────────────────────────────────────┤
│ Master      │ mot_A, tmp_A, lux_A, tv_A, lock_bath_A │
│ Bedrooms    │ mot_B1/B2, tmp_B1/B2, lux_B1/B2        │
│ LivingSpace │ mot_L, tmp_L, lux_L, tv_L, lock_main   │
│ Kitchen     │ tmp_K, lux_K, plug_fridge              │

Simulation Protocol:

1. Generate μ = 3 scenarios with σ² variations:
   - Breakfast preparation time Δt
   - Evening activity clustering
   - Weekend vs weekday patterns

2. Environmental Physics:
   - Thermal: ΔT/Δt = 0.35 ± 0.15 °C/min
   - EMI: 50-150W standby, 300-800W active
   - Markov chain room transitions

3. Data Quality:
   - Add Gaussian noise (μ=0, σ=1.5%) to all readings
   - 0.2% chance of sensor dropout
   - Correlate humidity (ρ = -0.82 ± 0.03) with temperature

Output Matrix Format:
timestamp, zone, sensor_id, value, resident_present, energy_state, env_quality
[ISO8601],[room],[sensor_type+ID],[float],[bool],[0-3],[0-100]

Example Row:
2024-07-15T06:17:32Z, MasterSuite, mot_A_1, 1, True, 2, 78
"""),
    AIMessagePromptTemplate.from_template("prompt")
])