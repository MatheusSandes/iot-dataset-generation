var_3 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are an Automated Household Behavior Simulator specializing in spatial-temporal activity modeling.
Generate multiple potential smart home event sequences for a typical urban family day and select the most statistically probable to convert into observational data.
Develop at least three alternative paths with variations in timing, room transitions, and device interactions.
Only output the finalized dataset representing the most realistic scenario.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Family Configuration Profile

- Occupant Schedule Matrix:

   || Wake || Depart || Return || Sleep ||
  |A1|06:00|08:00|17:00|22:30| 
  |A2|07:00|09:00|18:00|23:00|
  |C1|06:30|07:30|17:30|21:30|
  |C2|06:30|07:30|17:30|21:30|

- Residential Statistics:
  • Type: Urban Duplex (2 floors)
  • Square Footage: 1,800
  • Smart Automation Level: 7/10

- Sensor Network Architecture:

  [MasterSuite]  
  MS-motion, MS-climate, MS-lighting, MS-entertainment

  [Bedroom1]  
  B1-motion, B1-climate, B1-lighting, B1-entertainment

  [Bedroom2]  
  B2-motion, B2-climate, B2-lighting

  [LivingDining]  
  LD-motion, LD-climate, LD-lighting, LD-entertainment, LD-access

  [Kitchen]  
  K-climate, K-lighting, K-appliance

  [UtilityArea]  
  U-motion, U-climate

Scenario Generation Protocol:

1. Construct three alternative Markov Chains of household movement incorporating:
   - Variability (±15 minutes) in scheduled events  
   - Alternative room transition probabilities  
   - Different device activation sequences  

2. Each chain must maintain:
   - Chronological integrity
   - Physical plausibility
   - Energy consumption patterns

3. Select the chain with highest conditional probability given:
   - Local urban family behavioral studies  
   - Smart home empirical data  
   - Morning routine surveys

4. Transform selected chain into quantized sensor observations with appropriate:
   - Time-binning (5-minute resolution)  
   - Sensor error injection  
   - Cross-correlated environmental parameters  

Hardware Specifications:

- Motion → Lighting: p=0.92 [0.3–1.5 second delay]  
- Climate Sensors: ±0.2°C noise floor  
- Power Variance: σ=12.7% during active periods  
- Environmental Covariance:  
  temp:humm = -0.82  
  motion:power = 0.67  

Unoccupied Conditions:
- 09:15–17:15: Empty house protocol  
- 23:15–05:45: Sleep mode active  

Data Schema Requirements:

Initial header row must be:
timestamp,event_id,zone_id,event_class,source_node,temp_c,rel_humidity_pct,motion_state,occupancy_count,light_pct,wattage,db_level,aqi_index,door_state,window_state

Follow with optimized event sequence data.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])