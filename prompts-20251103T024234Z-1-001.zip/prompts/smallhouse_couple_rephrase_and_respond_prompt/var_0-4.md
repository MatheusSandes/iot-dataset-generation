
var_4 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Prior to dataset generation, carefully dissect and reinterpret the scenario description to guarantee complete comprehension of all specifications. 
Internally analyze each component (devices, residents, environment) and their interrelationships before creating the dataset.
Ensure your output contains only the final data - omit any preparatory analysis.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Scenario Details

- Building Profile: Compact urban smart home (34.2m² total) 
  
- Technical Infrastructure:

  • Living Zone (9m²):
    - Security: smart_lock_front (0=locked,1=unlocked)
    - Ambient: temp_sensor_living, smart_light_living (10-100% brightness)
    - Presence: motion_sensor_living (0/1)
    - Entertainment: smart_tv (standby=5W, active=150W)

  • Sleeping Zone (9m²):
    - Ambient: temp_sensor_bedroom, smart_light_bedroom
    - Presence: motion_sensor_bedroom
  
  • Food Preparation Zone (2.16m²):
    - Appliance: smart_plug_fridge (70W base + 50-150W compressor cycles)
    - Ambient: temp_sensor_kitchen, smart_light_kitchen
   
  • Hygiene Zone (2.4m²): No instrumentation

- Topological Links:
  Bedroom ↔ Living ↔ (Kitchen ∨ Bathroom)

- Human Patterns:
  - Resident Alpha (early bird): 
    06:00-08:00 Morning routine
    17:00-22:30 Evening activity
  - Resident Beta (night owl):
    07:00-09:00 Morning routine
    18:00-23:00 Evening activity

- Environmental Conditions:
  - Season: Brazilian winter (June)
  - Thermal envelope: 21-26°C internal
  - Moisture dynamics: 40-70% RH (negative temp correlation)  

Implementation Protocol:

1. Conduct silent scenario decomposition:
   - Map physical topology and device affinities
   - Derive probabilistic event timelines 
   - Compute environmental parameter correlations

2. Generate synthetic dataset respecting:
   - Thermal inertia constraints (0.5-1.5°C/30min delta)
   - Electro-mechanical reaction delays 
   - Real-world sig:
     ◦ Temp sensor error: ±10.1°C
     ◦ Motion false positives: 0.1-0.3%
     ◦ Power fluctuation: ±11%

Data Schema Header (mandatory structure):
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Output must consist solely of the generated dataset according to spec. 
"""),
    AIMessagePromptTemplate.from_template("prompt")
])