
var_6 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Perform a thorough comprehension check by internally reconstructing the home automation scenario - visualize device placements, resident routines, and environmental factors before proceeding.
Ensure every technical constraint and behavioral pattern is accounted for in your mental model.
When confident in your understanding, generate the dataset strictly adhering to all specifications.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Configuration Blueprint

▶ Architectural Layout
- Smart Home Dimensions: Compact urban dwelling
- Room Matrix:
  ⬥ Living Area (9m²): 
    ▪ Tracking: motion_sensor_living
    ▪ Entertainment: smart_tv
    ▪ Lighting: smart_light_living
    ▪ Climate: temp_sensor_living
    ▪ Security: smart_lock_front

  ⬥ Sleeping Quarter (9m²):
    ▪ Presence: motion_sensor_bedroom
    ▪ Ambience: smart_light_bedroom
    ▪ Thermal: temp_sensor_bedroom

  ⬥ Food Prep Zone (2.16m²):
    ▪ Climate: temp_sensor_kitchen
    ▪ Illumination: smart_light_kitchen
    ▪ Appliance: smart_plug_fridge

  ⬥ Hygiene Area (2.4m²): Unmonitored

▶ Connectivity Map
- Bedroom ⇄ Living Room
- Living Room ↣ Kitchen + Hygiene Area

▶ Occupation Patterns
- Primary Resident:
  ☀ 06:00 Activation | 08:00 Departure | 17:00 Return | 22:30 Deactivation
- Secondary Resident:
  ☀ 07:00 Activation | 09:00 Departure | 18:00 Return | 23:00 Deactivation

▶ Environmental Profile
- Season: Brazilian Winter (June)
- Thermal Range: 21–26°C
- Moisture: 40–70% (inverse thermal correlation)

Implementation Protocol:

1. Build a complete mental simulation including:
   - Spatial relationships between all monitored zones
   - Resident interaction timelines
   - Equipment response behaviors

2. Enforce these physical laws:
   - Motion → Thermal shift (0.5–1.5°C/15–30min)
   - Motion → Energy spike (100–300W instant)
   - Thermal-Humidity coefficient: -0.7 to -0.9

3. Apply realistic imperfections:
   - ±0.1°C thermal variance
   - ±1% power fluctuation
   - 0.1–0.3% false motion detection

4. Observe mandatory inactivity periods:
   - 23:00–06:00 (Sleep cycle)
   - 09:00–17:00 (Unoccupied)

5. Implement natural event timing (irregular intervals)

Data Specification:

timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Generate exclusively the dataset after completing your internal verification.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])