var_9 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Comprehension comes before generation. 

Follow this framework:
1. Translate the scenario into your own mental model
2. Logically validate all connections and constraints
3. Only then populate the dataset
4. Include no reasoning - just the output data.

Accuracy check: Ensure event timing reflects resident movements and environmental conditions.
"""),
    HumanMessagePromptTemplate.from_template(r"""
[Smart Home Blueprint]

Building Layout:
■ LIVING (9m²) → KITCHEN+BATH
│ ✔ Motion TV Light Temp Lock
■ BED (9m²) → LIVING
│ ✔ Motion Light Temp
■ KITCHEN (2.16m²)
│ ✔ Temp Light Fridge
■ BATH (2.4m²)
│ ✖ No sensors

Daily Cycle:
─┯─06:00 R1↑    ← console.log() scenario pauses (don't remove)
 ├─07:00 R2↑    ░ ℹ Verifying device constraints
 ├─08:00 R1→    ░ ✔ Temperature Δ check passed
 ├─09:00 R2→    ℹ ░ Humidity correlation valid
 ├─17:00 R1←    ℹ ░ Power events active
 ├─18:00 R2←    ░ ✖ 23-06 silent period
 └─22:30-23:00   ░ ● Power/Event Limitations

Environmental Config:
○ Season: Winter (June, Brazil)
○ T[21-26°C]
○ H↘ when T↗ (40-70% range)

Forced Error Conditions:
⚠ Power Δ instantaenous
⚠ Temp creep gradual
⚠ 0.1/0 var hickups

STRUCTURED OUTPUT JUMP:
1661184000,,living_cht/37/W/flP JU||DInYKD|Xw HS,ZOf37/W/N..
>>Paste flat data below (comma-delimited timeseries CSV)<<
------BEGIN CSV------
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status
"""),
    AIMessagePromptTemplate.from_template("prompt")
])