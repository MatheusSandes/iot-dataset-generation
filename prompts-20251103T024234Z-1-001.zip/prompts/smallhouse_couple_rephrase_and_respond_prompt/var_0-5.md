var_5 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
System Instruction: 
First, deeply analyze the scenario by creating a conceptual graph:
1) Map device interconnections and relationships
2) Visualize resident activity flows through rooms
3) Model environmental influences on devices
This structured analysis is crucial but remains internal.
Only output the final IoT dataset after this thorough examination.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Configuration Analysis

Residence Profile:
- Urban compact dwelling (35m² total)
- Thermal characteristics: Moderate insulation

Connected Spaces:

◆ PRIMARY ZONE [12m²]
- Smart TV 
- Climate sensor cluster (temp/humidity/motion)
- Illumination unit (dimmable LED)
- Access control module (smart lock)

◆ REST ZONE [9m²]
- Occupancy detection (motion)
- Ambient light controller
- Thermal monitor (temperature)

◆ FOOD PREPARATION AREA [2.2m²]
- Refrigeration circuit monitor
- Light fixture
- Precision temperature sensor

Cross-Zone Dynamics:
- Main path: Rest Zone ↔ Primary Zone ↔ Food Area
- Secondary access: Primary Zone → Hygiene Area (unsensored)

Resident Patterns:

☀ Morning Phase (06:00-09:00):
- Dual occupancy with 1-hour overlap
- Thermal adjustment period

🌑 Night Phase (23:00-06:00):
- Mandatory quiet mode (all devices idle)

Environmental Parameters:
- Season: Tropical winter
- Base temperature: 21.5 ± 4.5°C
- Relative humidity: min40% max70% (inverse thermal correlation)

Procedural Requirements:

1) Perform systems simulation considering:
- Device activation chains
- Thermal inertia effects
- Power usage waveforms

2) Enforce scenario constraints:
- Absolute blackout periods (23:00-06:00, 09:00-17:00)
- Physical limits on sensor variance
- Real-world noise injection (5% tolerance bands)

3) Generate multi-sensor unified timeline with:
- Natural timestamp distribution
- Cross-device event correlation
- Gradual environmental changes

Output Specification:
timestamp,event_id,location,type,trigger_device,temp(C),humidity(%),motion,occupancy,light(lux),power(W),noise(dB),air_quality(AQI),lock_status,window

Generate only empirical observations - no simulation notes.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])