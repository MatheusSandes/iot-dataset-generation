
var_7 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
First, internally conceptualize the scenario by identifying all critical components, relationships, and technical constraints. 
Analyze how these elements interact temporally and spatially.
Only after completing this systematic analysis should you generate the IoT dataset.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Space Specifications:

- Dwelling: Compact smart residence in urban setting

- Room Layout with Devices:

  ◈ Main Living Area (9m²):
    ➤ Activity detector (motion_livingSpace)
    ➤ Entertainment system (tv_entertain)
    ➤ Adaptive lighting (light_mainSpace)
    ➤ Thermal monitor (temp_mainZone)
    ➤ Entry security (entry_lock)

  ◈ Sleeping Quarters (9m²):
    ➤ Presence indicator (motion_sleepZone)
    ➤ Ambient lighting (light_restSpace)
    ➤ Climate sensor (temp_sleepZone)

  ◈ Food Preparation Zone (2.16m²):
    ➤ Heat gauge (temp_foodZone)
    ➤ Task lighting (light_workSpace)
    ➤ Appliance controller (plug_coolingUnit)

  ◈ Sanitation Area (2.4m²): No instrumentation

- Spatial Relationships:
  Sleeping Quarters ↔ Main Living Area ↔ 
  (Food Prep Zone + Sanitation Area)

- Occupant Patterns:

  ▷ Primary Resident:
    - Rises 06:00 | Departs 08:00 | Returns 17:00 | Retires 22:30

  ▷ Secondary Resident:
    - Rises 07:00 | Departs 09:00 | Returns 18:00 | Retires 23:00

- Environmental Conditions:
  - Season: Southern winter (June)
  - Interior thermal range: 21–26°C
  - Moisture content: 40–70% (negative correlation with temperature)

Implementation Requirements:

1. Conduct cognitive modeling of:
   • Equipment distribution and zone connectivity
   • Temporal cycles (awake overlap, absence period, evening interaction)
   • Operational boundaries and restrictions

2. Create physically plausible dataset demonstrating:
   - Thermal inertia effects
   - Event-triggered state transitions
   - Environmental interdependence

Technical Parameters:

- Activity → Temperature (Δ0.5–1.5°C per 15–30 min)
- Motion → Energy demand (Δ100–300W instantaneous)
- Thermal-moisture correlation: -0.7 to -0.9
- Real-world imperfections:
  - Thermal ±0.3°C | Power ±12% | Activity false positives (0.1–0.3%)
- Inactive periods:
  - 23:00–06:00 (rest phase)
  - 09:00–17:00 (unoccupied phase)
- Timestamps should show natural human rhythm patterns

Expected Output Structure:

Begin with exact header:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Provide only the final processed datastream.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])