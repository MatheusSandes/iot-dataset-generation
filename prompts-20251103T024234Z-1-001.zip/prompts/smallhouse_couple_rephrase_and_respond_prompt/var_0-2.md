var_2 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Carefully analyze the IoT scenario through multiple perspectives before generating data:
1) Spatial mapping of devices and room adjacencies
2) Temporal patterns of resident activities
3) Environmental conditions and sensor correlations

Generate the most probable sensor events while considering:
- Physical constraints of the smart home
- Behavioral patterns of residents
- Natural variations in sensor readings

Output only the final dataset with no explanatory content.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Configuration Blueprint

■ Spatial Configuration:
╠══ Residential Structure (Urban compact dwelling)
║
╠══ Room Matrix:
║   ⊛ Living Area (9m²): 
║     ✦ Environmental: temp_sensor_living, motion_sensor_living
║     ✦ Appliances: smart_tv, smart_light_living
║     ✦ Security: smart_lock_front
║
║   ⊛ Sleeping Quarters (9m²):
║     ✦ Environmental: temp_sensor_bedroom, motion_sensor_bedroom  
║     ✦ Lighting: smart_light_bedroom
║
║   ⊛ Food Preparation Zone (2.16m²):
║     ✦ Environmental: temp_sensor_kitchen
║     ✦ Appliances: smart_light_kitchen, smart_plug_fridge
║
║   ⊛ Sanitary Facility (2.4m²): No electronic monitoring

■ Temporal Patterns:
• Primary Occupant:
  - Active phases: 06:00-08:00 | 17:00-22:30
• Secondary Occupant:
  - Active phases: 07:00-09:00 | 18:00-23:00
• Common Quiet Hours: 23:00-06:00
• Vacant Period: 09:00-17:00

■ Environmental Parameters:
• Climate: Southern hemisphere winter
• Thermal Range: 21-26°C (indoor)
• Moisture: 40-70% RH (inverse temp correlation)

■ Technical Specifications:
╠══ Sensor Interdependencies:
║   • Motion → Thermal delta (0.5-1.5°C/15-30min)
║   • Motion → Power surge (100-300W instant)
║   • Thermal-Humidity: r ≈ -0.8
║
╠══ Realistic Error Margins:
║   • Temp: ±0.1°C
║   • Power: ±1%  
║   • Motion: 0.1-0.3% false positives
║
╠══ Absolute Constraints:
║   • Zero activity during sleep/vacant hours
║   • Non-periodic timestamp generation

■ Required Output Structure:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

■ Critical Reminder:
Generate only the dataset with no interpretive content.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])