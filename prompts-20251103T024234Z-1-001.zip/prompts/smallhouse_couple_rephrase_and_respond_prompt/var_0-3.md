var_3 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
First, interpret the home automation scenario by identifying key components: devices, residents' schedules, environmental conditions, and technical relationships.
Synthesize this understanding into clear logical patterns before data generation.
Omit all analytical steps from final output - deliver only the structured dataset.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Blueprint

- Residence: Compact urban dwelling (48m² total)

- Device Deployment:

  ▲ Living Area (9m²)
    ↳ Security: motion_sensor_living, smart_lock_front  
    ↳ Climate: temp_sensor_living  
    ↳ Media: smart_tv  
    ↳ Lighting: smart_light_living  

  ▼ Sleeping Quarters (9m²)
    ↳ Presence: motion_sensor_bedroom  
    ↳ Environment: temp_sensor_bedroom  
    ↳ Illumination: smart_light_bedroom  

  ► Food Preparation Zone (2.16m²)
    ↳ Appliance: smart_plug_fridge  
    ↳ Ambient: temp_sensor_kitchen, smart_light_kitchen  

  ◄ Hygiene Area (2.4m²): No instrumentation  

- Spatial Connections:
  Bedroom ⇄ Living Area ⇄ (Kitchen + Bathroom)  

- Occupant Patterns (Weekdays):

  ► Primary User:
    Active: 06:00-08:00 | 17:00-22:30  
    Dormant: 22:30-06:00  

  ► Secondary User:
    Active: 07:00-09:00 | 18:00-23:00  
    Dormant: 23:00-07:00  

- Climatic Context:
  ► Season: Southern winter  
  ► Indoor Parameters:
    - Thermal: 21-26°C daily fluctuation  
    - Moisture: 40-70% RH (inverse thermal relationship)  

Generation Protocol:

1. Establish device interaction matrix:
   - Movement → Climate (0.7-1.3°C/20min)
   - Climate → Humidity (ρ ≈ -0.8)
   - Presence → Energy (150-250W step)

2. Inject environmental stochasticity:
   - ±0.2°C instrument error
   - 0.15% spurious motion detection
   - ±8% power measurement variance

3. Enforce quiescent periods:
   - Nocturnal: 23:00-06:00  
   - Diurnal: 09:00-17:00  

4. Apply temporal randomness:
   - ±25% event timing deviation  

Data Specification:

Initial line must match exactly:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Provide exclusively the generated dataset without commentary.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])