var_9 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You simulate realistic smart home behavior by understanding human routines and appliance interactions. 
Compare device triggers to natural human rhythms — kitchen appliances waking with the family, televisions reflecting entertainment patterns, and thermostats adjusting to household presence.
Generate only raw IoT data output without explanatory commentary or analogies.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Residential Blueprint

Imagine an active suburban smart home with dual-income parents and middle school children, where device activations mirror human activity cycles.

Key Behavioral Patterns:

- **Pre-Dawn**: Minimal activity except occasional early riser
- **Morning Rush**: High appliance usage, multiple motion triggers, thermostat adjustments
- **School/Work Hours**: Standby mode with only background systems active
- **Afternoon Transition**: Gradual reoccupation starting with children
- **Evening Hub**: Centralized family time in common areas
- **Night Cycle**: Reduced activity with localized bedroom usage

---

- Structure: 2,800 sqft colonial with finished basement

- Smart Equipment:

  • Primary Suite:
    - occupancy_sensor_master
    - climate_control_master
    - lighting_zones_master
    - media_system_master

  • Junior Bedrooms:
    - presence_detector_roomA
    - environmental_sensor_roomA
    - smart_bulbs_roomA
    - presence_detector_roomB  
    - environmental_sensor_roomB
    - smart_bulbs_roomB

  • Common Areas:
    - motion_array_living
    - climate_monitor_living
    - accent_lighting_living
    - entertainment_system
    - secure_entry_system

  • Food Prep Zone:
    - thermal_sensor_kitchen
    - task_lighting_kitchen
    - appliance_monitor_fridge

  • Utility Spaces:
    - motion_detector_laundry
    - temp_probe_laundry

Floor Connectivity:

- Living Hub ↔ Upper Level ↔ Sleeping Quarters
- Living Hub ↔ Culinary Zone ↔ Service Areas
- Living Hub ↔ Guest Washroom

Occupant Schedule:

  • Parent A: rises 05:45, departs 07:45, returns 16:30, retires 22:00
  • Parent B: rises 06:15, departs 08:15, returns 17:45, retires 22:30
  • Student X: rises 06:30, departs 07:15, returns 15:45, retires 20:30
  • Student Y: rises 06:30, departs 07:15, returns 15:45, retires 20:30

Technical Parameters:

- Motion → Climate (Δ0.75–2.25°C per 10–20 min)
- Motion → Energy (150–400W immediate draw)
- Climate ↔ Humidity: inverse relationship (-0.65 to -0.85)
- Error Margins:
  - Temp ±0.2°C
  - Power ±12%
  - False Motion: 0.15–0.35%

Quiet Periods:

- 08:30–15:30 (minimal activity window)
- 22:30–05:30 (sleep cycle)

Output Structure:

Begin with CSV header:
timestamp,zone,event_id,event_category,activated_device,temp_read,humidity_val,movement_flag,occupancy_status,luminosity,wattage_usage,sound_value,air_readings,entry_state,portal_status

Generate continuous data reflecting these living patterns.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])