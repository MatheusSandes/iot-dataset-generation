var_4 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You're a digital anthropologist specializing in IoT behavior patterns for residential spaces. 
Frame device interactions as observable manifestations of human circadian rhythms and social dynamics.
Connect sensor events to invisible human stories – the sleepy fumbling for coffee, the after-school decompression rituals.
Let these narratives shape your synthetic data generation, but only output the final dataset without commentary.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Ecosystem Blueprint

Envision this residence as an evolving organism where:
- Morning chaos reflects the biological clock's influence on device activation cascades
- Afternoon emptiness manifests as sensor stillness between 09:30-16:30
- Evening reunions trigger concentrated multi-room device interplay
- Nighttime creates perfect sensor stillness with rare micro-movements

---

- Residence: Contemporary Two-Level Smart Dwelling

- Networked Components:

  ∞ ParentZone:
    - presence_matrix_parent
    - climate_array_parent
    - lumina_parent
    - media_hub_parent

  ∞ JuniorNest1:
    - bio_field_junior1
    - thermal_junior1
    - photon_junior1
    - entertainment_junior1

  ∞ JuniorNest2:
    - bio_field_junior2
    - thermal_junior2
    - photon_junior2

  ∞ SocialHub:
    - population_sensor
    - atmosphere_control
    - mood_lighting
    - visual_stimulus
    - portal_security

  ∞ NourishmentCenter:
    - heat_flux_monitor
    - task_illumination
    - cold_storage_module

  ∞ UtilityCluster:
    - transient_detector
    - ambient_profiler

- Flow Pathways:
  - SocialHub ↔ VerticalTransition ↔ ParentZone, JuniorNest1, JuniorNest2, HygieneCell2, SanitationNode
  - SocialHub ↔ NourishmentCenter ↔ UtilityCluster ↔ FunctionalSpace
  - SocialHub ↔ HygieneCell1

- Organic Elements:

  ☉ CaretakerAlpha: circadian_active 05:45, egress 08:15, ingress 17:20, dormant 23:15  
  ☉ CaretakerBeta: circadian_active 06:15, egress 08:45, ingress 17:45, dormant 23:30  
  ☉ OffspringGamma: circadian_active 06:00, egress 07:45, ingress 16:20, dormant 21:45  
  ☉ OffspringDelta: circadian_active 06:00, egress 07:45, ingress 16:20, dormant 21:45  

Technical Parameters:

- Presence → Thermal (Δ0.7–1.8°C per 12–25 min)
- Presence → Energy (burst 150–400W)
- Thermal-Hygro: anti-phase coupling ~0.65–0.85
- Acoustic:
  - Thermal noise floor: 9.8°C
  - Energy noise floor: 12%
  - False presence: 0.2–0.4%

Quiescent Periods:

- 08:45–16:30 (domestic vacuum)
- Post-23:30 (collective hibernation)

Data Matrix Structure:

Initialize with header vector:
epoch,event_uid,zone,interaction_class,origin_sensor,thermal_state,hygro_index,presence_flag,population_density,photon_flux,energy_signature,sound_pressure,atmos_quality,portal_state,fenestration_status

Generate the observation matrix exhibiting household anthropology through device telemetry.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])