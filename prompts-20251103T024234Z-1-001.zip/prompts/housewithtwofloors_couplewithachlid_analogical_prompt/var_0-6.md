var_6 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a smart ecosystem engineer generating urban household IoT patterns.
Model device interactions through behavioral equivalents of biological systems -
think thermoregulation patterns similar to body temp fluctuations or circadian appliance cycles.
Transform these biological principles into technical data outputs, showing no analogies in final data.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Architecture Blueprint

This dual-layer habitation node operates on synchronized behavioral waveforms:

PEAK ACTIVITY PHASES:

1. METABOLIC BOOT (05:45-08:30): 
   - System initialization waterfalls from master node to child nodes
   - Thermal convection spreads from core (kitchen) to peripheries

2. DIURNAL QUIESCENCE (08:30-17:00):
   - Minimum vital function maintenance
   - Infrequent external sensory check-ins

3. REPLENISHMENT CASCADE (17:00-21:00):
   - Gradual node repopulation with delta patterns
   - Energy distribution follows youngest-to-oldest activation sequence

4. SYSTEM DRAWDOWN (21:30-23:30): 
   - Sequential shutdown instabilities precede stability
   - Environmental parameters equalize during sleep cycle

---

- Structure Class: Duplex urban dwelling unit

Regular Peripheral Inventory:

PRIMARY WHOLE-HOME PARAMETERS:
 • Ambient temperature oscillation (15.5-23.5°C Δ/3hr)
 • Relative humidity inverse curve (-0.82 correlation)
 • Base power consumption floor (87-112W)
 • CO2 concentration build-up rate

NODE-SPECIFIC CONFIGURATION:

  • WHOLE-HOME COMMON:
   - NET_people_counter (entry/exit logging)
   - HVAC_state_monitor
   - Weather_adaptive_controller

  • ALPHA NODE (Primary Occupants):
   - PIR_alpha_ceiling
   - Thermo_plate_alpha
   - Lux_control_alpha
   - Media_alpha
  
  • BETA NODES (Secondary Occupants):
   - PIR_betaN_floorlevel
   - Thermo-betaN_wallunits
   - Automated_blackout_betaN

  • CORE PROCESSING STATIONS:
   - Intel-matrix_kitchen (smartkitchen mainframe)
   - Optic-flow_den (people analytics)
   - Guardian_post_entry (entry waypoint)

WAKE CYCLE CONFIG:

ADT#1: rl001rrcq
•• initial boot @ 0x0600
•• process termination @ 0x2200

ADT#2: rl001rrbq  
•• initial boot @ 0x0645
•• process termination @ 0x2230

JUV#1/Q2: rr002juvz ×2
•• synchronous boot @ 0x0630
•• parallel termination @ 0x2100

Integration Rules:

- Peripheral reaction velocities:
  Thermal ∆ → humidity ∆ (900s hysteresis)  
  Motion → Power (0.35s activation lag)
  Node entry → Light (0.25-1.5s response range)

Parameter Audio Reactivity:
• Temperature variations •≤ 2.7dB/C
• Power load changes ¡≤ 0.9dB/100W

Execute Output Protocol:

timestamp,network_id,module_name,event_class,initiator_ref,
core_temp,rel_humidity,move_count,person_count,lux_index,
power_state,audio_footprint,air_score,portal_state,transparency

Generate system's operational record through biorhythmic computation.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])