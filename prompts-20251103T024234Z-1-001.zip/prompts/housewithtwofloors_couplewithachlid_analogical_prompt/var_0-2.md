var_2 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are an IoT choreographer crafting sensor symphonies that tell the story of daily family life.
Stage this smart home's performance with devices as instruments:
- Lights create visual crescendos
- Motion sensors mark character entrances
- Appliances provide bassline rhythms
Compose believable patterns as if directing a domestic opera with strict technical constraints.
Output only the final performance (raw data), no stage directions.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Score Sheet

Imagine this space as a three-act family play:

ACT I - Morning Overture (06:00-08:00):
- Synchronized chaos of preparations
- Counterpoint melodies in bathrooms/kitchen
- Rapid lighting sequences

ACT II - Daytime Intermezzo (08:00-17:00):
- Minimal ambient instrumentation
- Only automated thermostats playing

ACT III - Evening Finale (17:00-23:00):
- Gradual character returns
- Dramatic lighting shifts
- Appliance solos
- Final diminuendo to sleep

—

Stage Configuration:

Main Characters:
- Lead 1 (Professional)
- Lead 2 (Professional)
- Supporting 1 (Student)
- Supporting 2 (Student)

Stage Areas (Zones):

• MasterChamber:
  - spotlight_master
  - thermal_master
  - entertainment_master
  - presence_master

• JuniorNest1:
  - ambiance_junior1
  - climate_junior1
  - media_junior1

• JuniorNest2:
  - ambiance_junior2  
  - climate_junior2

• GrandStage (Living/Dining):
  - crowd_detector
  - environment_grand
  - illumination_grand
  - spectacle_grand
  - portal_security

• CulinaryPit (Kitchen):
  - climate_kitchen  
  - task_lighting
  - cold_storage_monitor

• ServiceWing:
  - utility_detector
  - backstage_climate

Technical Composition Rules:

- Thermal Fluctuations: 0.7°C/15min max
- Lighting Cues: 5-90% brightness
- Power Surges: 150-350W per activation
- Occupancy Cadence: 87-92% accuracy
- Humidity-Temp Correlation: -0.75±0.05
- Noise Floor: 
  - Temp error ±0.3°C
  - Power ±9%
  - False motion 0.2-0.4%

Silent Scenes:
09:00-17:00 (Main empty stage)
23:30-05:30 (Full blackout)

Performance Ledger Format:

Begin with header:
timestamp,zone,performance_id,event_class,sensor_actor,temp,humidity,motion,occupancy,light_state,power_draw,sound_level,air_score,entry_status,aperture_state

Then deliver the complete sensor symphony data.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])