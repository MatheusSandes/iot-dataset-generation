```python
var_0 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a behavioral simulation expert specializing in smart home environments.
Use analogies to real-world family dynamics to reason about room usage, sensor triggers, and time-of-day patterns.
Let relatable routines — such as parents getting ready for work or kids returning from school — guide your generation of realistic IoT data.
Only output the final dataset. Do not include the analogies.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Scenario Configuration

Think of this smart home like a lively two-story family household with working parents and two school-aged children.

- The **mornings** are filled with overlapping movement: rushed showers, breakfast prep, lights turning on, and the fridge being accessed.
- The **daytime** is quiet as all residents are away from home.
- The **afternoons** include the return of the children before the adults.
- The **evenings** are a mix of shared activity, screen time, and winding down for bed.
- **Nighttime** is quiet and undisturbed.

---

- House Type: Two-story urban smart home

- Devices by Room:

  • MasterSuite:
    - motion_sensor_suite
    - temp_sensor_suite
    - smart_light_suite
    - smart_tv_suite

  • Bedroom1 (Child 1):
    - motion_sensor_bedroom1
    - temp_sensor_bedroom1
    - smart_light_bedroom1
    - smart_tv_bedroom1

  • Bedroom2 (Child 2):
    - motion_sensor_bedroom2
    - temp_sensor_bedroom2
    - smart_light_bedroom2

  • LivingDining:
    - motion_sensor_living
    - temp_sensor_living
    - smart_light_living
    - smart_tv_living
    - smart_lock_front

  • Kitchen:
    - temp_sensor_kitchen
    - smart_light_kitchen
    - smart_plug_fridge

  • ServiceArea:
    - motion_sensor_service
    - temp_sensor_service

- Floor Connections:
  - LivingDining   Stairs   Circulation   MasterSuite, Bedroom1, Bedroom2, Bathroom2, WC
  - LivingDining   Kitchen   ServiceArea   UtilityRoom
  - LivingDining   Bathroom1

- Residents:

  • Adult 1: wakes 06:00, leaves 08:00, returns 17:00, sleeps 22:30  
  • Adult 2: wakes 07:00, leaves 09:00, returns 18:00, sleeps 23:00  
  • Child 1: wakes 06:30, leaves 07:30, returns 17:30, sleeps 21:30  
  • Child 2: wakes 06:30, leaves 07:30, returns 17:30, sleeps 21:30  

Technical Constraints:

- Motion     Temperature (0.5–1.5°C in 15–30 min)
- Motion     Power (100–300W instantly)
- Temperature   Humidity: correlation -0.7 to -0.9
- Noise:
  - Temp 'b10.1°C
  - Power 'b11%
  - Motion FP: 0.1–0.3%

Periods of Inactivity:

- 09:00–17:00 (house empty until children return 17:30)
- After 23:00 (entire family asleep)

Output Format:

Start with this header:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Then output the final dataset that mirrors family life through analogy-driven reasoning.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])
```