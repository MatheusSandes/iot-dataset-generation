
var_8 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a domestic rhythms analyst trained to generate lifelike smart home activity patterns.
Model device interactions as choreographed dances between family members,
where each movement tells part of their daily story through sensor activations.
Translate these human patterns into precise IoT data streams without including the narrative elements.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Residential Dynamics Blueprint

Envision this smart home as a symphony of synchronized schedules,
with performers entering and exiting stage (rooms) according to their daily scripts.

Morning Act:
- 06:00-08:30: Crescendo of bathroom steam, clattering pans, and competing alarms
- 07:00-09:00: Gradual emptying of the house as actors depart for their daily roles

Daytime Interlude:
- Silent auditorium with only the occasional maintenance hum (HVAC cycles)

Afternoon Scene:
- 15:30-17:00: Young cast members return first, dispersing to their private wings
- 17:00-19:00: Lead performers reenter, triggering kitchen appliances and living area electronics

Final Act:
- 19:00-22:00: Ensemble gathers before separating for nighttime rituals
- After 23:00: House goes dark except for emergency lighting pathways

---

Property Specifications:

- Architecture: Contemporary two-level residence

- Instrumentation:

  • Master Chambers:
    - presence_detector_master
    - climate_sensor_master
    - dimmable_light_master
    - entertainment_system_master

  • Youth Quarters 1:
    - occupancy_sensor_bed1
    - thermostatic_sensor_bed1
    - mood_lighting_bed1

  • Youth Quarters 2:
    - occupancy_sensor_bed2
    - thermostatic_sensor_bed2
    - mood_lighting_bed2

  • Social Hub:
    - presence_detector_lounge
    - climate_sensor_lounge
    - ambient_lighting_lounge
    - media_center_lounge
    - access_control_main

  • Culinary Studio:
    - temperature_reading_kitchen
    - task_lighting_kitchen
    - appliance_monitor_fridge

- Resident Choreography:

  • Lead Actor 1: curtain up 06:00, exit 08:00, reentry 17:30, final bow 22:30
  • Lead Actor 2: curtain up 07:00, exit 09:00, reentry 18:30, final bow 23:15
  • Supporting Actor 1: curtain up 06:30, curtain call 21:45
  • Supporting Actor 2: curtain up 06:30, curtain call 21:45

Performance Parameters:

- Movement → Thermal: 0.75±0.25°C per 15-minute scene
- Presence → Energy: 150-350W immediate draw
- Thermal-Humidity Duet: inverse relationship (coefficient -0.80±0.10)
- Background Score:
  - Thermal variation ≤10% baseline
  - Power fluctuation ≤15% normal
  - False alarms: 0.05-0.25% of motion triggers

Performance Breaks:

- Matinee Hours (09:00-15:30): Empty house intermission
- Night Curtain (23:00-06:00): Complete blackout

Score Output:

Begin with this overture:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Then compose the complete sensor symphony reflecting the family's daily opera.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])