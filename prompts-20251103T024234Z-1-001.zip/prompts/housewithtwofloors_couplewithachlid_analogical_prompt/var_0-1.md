var_1 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a residential behavior analyst creating synthetic smart home data.
Model device interactions as orchestrated family activities, where each resident's schedule creates predictable patterns.
Think of device triggers as choreographed routines - morning chaos, after-school energy, and evening cooldown.
Present only the output data, your behavioral analysis remains internal.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Residence Blueprint

Envision a modern smart home with four occupants: two professionals and their middle-school children.

Daily Rhythm:

- **Pre-Dawn (05:30-07:00):** Gradual awakening, staggered bathroom use
- **Morning Rush (07:00-09:00):** Breakfast scramble, final preparations
- **Daytime Absence (09:00-16:30):** Minimal activity except automated systems
- **Afternoon Return (16:30-18:30):** Snack time, homework, relaxed activities
- **Evening Routine (18:30-22:30):** Dinner, family time, personal relaxation
- **Night Silence (22:30-05:30):** Occasional bathroom visits, otherwise still

---

- Property Layout: Contemporary two-level home with open floor plan

- Equipped Zones:

  • PrimaryBedroom:
    - presence_primary
    - climate_primary
    - lighting_primary
    - entertainment_primary

  • JuniorBedroom1 (Teen 1):
    - presence_junior1
    - climate_junior1
    - lighting_junior1

  • JuniorBedroom2 (Teen 2):
    - presence_junior2
    - climate_junior2
    - lighting_junior2

  • GreatRoom:
    - presence_greatroom
    - climate_greatroom
    - lighting_greatroom
    - media_greatroom
    - entry_system

  • CulinaryZone:
    - climate_culinary
    - lighting_culinary
    - appliance_monitor

  • ServiceCorridor:
    - presence_service
    - climate_service

- Floor Plan:

  GreatRoom <-> Staircase <-> UpperHall <-> PrimaryBedroom, JuniorBedroom1, JuniorBedroom2, FullBath, HalfBath
  GreatRoom <-> CulinaryZone <-> ServiceCorridor <-> LaundrySpace
  GreatRoom <-> MorningBath

- Occupant Schedules:

  • Parent1: rises 05:45, departs 07:45, home 17:15, retires 22:15  
  • Parent2: rises 06:15, departs 08:30, home 18:45, retires 23:15  
  • Teen1: rises 06:00, departs 07:15, home 16:45, sleeps 22:00  
  • Teen2: rises 06:00, departs 07:15, home 16:45, sleeps 22:00  

Technical Parameters:

- Motion events trigger:
  - Temperature drift: ±0.75°C per 20 min
  - Power surge: 150-400W immediate
- Environmental linkage:
  - Temp-Humidity: inverse relationship (-0.65 to -0.85)
- Error margins:
  - Temp variance: ±0.3°C
  - Power flux: ±8%
  - False motions: 0.2–0.4% probability

Quiet Periods:

- 08:30–16:45 (residents absent except potential cleaners)
- 23:15–05:45 (family asleep with occasional night activity)

Required Output:

Begin with this exact header:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Generate the complete dataset representing this household's digital footprint across a typical day.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])