```python
var_0 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Use the resolved smart home scenario provided below as an analogy to guide the generation of a new IoT dataset.
Identify structural, environmental, and behavioral similarities between the two homes.
Transfer relevant patterns from the reference scenario to generate realistic events for the target home.
Ensure consistency with device locations, activity windows, event spacing, and sensor correlations.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Reference Scenario

- House Type: Compact smart apartment

- Devices by Room:
  • Bedroom (3m x 3m):
    - 1x Motion sensor (motion_sensor_bedroom)
    - 1x Temperature sensor (temp_sensor_bedroom)

  • Living Room (3m x 3m):
    - 1x Motion sensor (motion_sensor_living)
    - 1x Smart TV (smart_tv)
    - 1x Temperature sensor (temp_sensor_living)

- Room Connections:
  - Bedroom   Living Room

- User:
  - Single occupant
  - Active 06:00–08:00 and 17:00–22:30
  - Sleeps 22:30–06:00, away 08:00–17:00

- Environment:
  - Season: Winter (June), Brazil
  - Indoor temp: 21–26°C depending on activity
  - Humidity: 40–70%, inversely correlated

- Technical Specifications:
  - Motion   Temp   (0.5–1.5°C in 15–30min)
  - Motion   Power   (100–300W immediately)
  - Temp   Humidity: -0.7 to -0.9
  - Realistic noise and timestamp variability

Reference Output (excerpt):
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status
2025-06-01T06:00:22,evt_0001,Bedroom,temperature_reading,temp_sensor_bedroom,22.0,69,,1,low,110,35,good,closed,closed
2025-06-01T06:02:18,evt_0002,Bedroom,motion_detected,motion_sensor_bedroom,22.4,66,1,1,low,240,36,good,closed,closed
2025-06-01T06:06:41,evt_0003,Living Room,motion_detected,motion_sensor_living,23.0,63,1,1,medium,260,37,good,closed,closed
2025-06-01T06:07:05,evt_0004,Living Room,power_usage,smart_tv,,63,,1,medium,310,38,good,closed,closed
2025-06-01T06:11:15,evt_0005,Living Room,temperature_reading,temp_sensor_living,24.1,60,,1,medium,260,37,good,closed,closed

---

Target Scenario

- House Type: Small urban smart home

- Devices by Room:

  • Living Room (3m x 3m):
    - 1x Motion sensor (motion_sensor_living)
    - 1x Smart TV (smart_tv)
    - 1x Smart light bulb (smart_light_living)
    - 1x Temperature sensor (temp_sensor_living)
    - 1x Smart lock (smart_lock_front)

  • Bedroom (3m x 3m):
    - 1x Motion sensor (motion_sensor_bedroom)
    - 1x Smart light bulb (smart_light_bedroom)
    - 1x Temperature sensor (temp_sensor_bedroom)

  • Kitchen (1.8m x 1.2m):
    - 1x Temperature sensor (temp_sensor_kitchen)
    - 1x Smart light bulb (smart_light_kitchen)
    - 1x Smart plug (smart_plug_fridge)

  • Bathroom (2m x 1.2m): no sensors

- Room Connections:
  - Bedroom   Living Room
  - Living Room   Kitchen and Bathroom

- User:
  - Single adult occupant
  - Active 06:00–08:00 and 17:00–22:30
  - Away 08:00–17:00, sleeps 22:30–06:00

- Environment:
  - Winter in Brazil (June)
  - Indoor temperature: 21–26°C
  - Humidity: 40–70%, inversely correlated

- Technical Requirements:
  - Motion   Temp   (+0.5–1.5°C in 15–30min)
  - Motion   Power   (+100–300W immediately)
  - Temp   Humidity: -0.7 to -0.9
  - Noise: temp ('b10.1°C), power ('b11%), motion FP (0.1–0.3%)
  - Timestamp variability and natural human activity patterns
  - No events between 22:30–06:00 or 08:00–17:00

Output Format:

Start with:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Then provide only the CSV dataset.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])
```