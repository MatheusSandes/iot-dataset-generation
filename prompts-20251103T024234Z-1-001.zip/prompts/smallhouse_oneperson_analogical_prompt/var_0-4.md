
var_4 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Transform this residential IoT scenario into a comprehensive dataset by mapping behaviors and environmental patterns from the reference example. 
Focus on logical device interactions, realistic sensor correlations, and maintaining temporal consistency across all home automation events.

Key principles for dataset generation:
1. Maintain strict cause-effect relationships between sensors
2. Preserve operating hours and occupancy patterns
3. Enforce environmental physics (temperature/humidity dynamics)
4. Model realistic power consumption curves
5. Apply natural human movement sequences
"""),
    HumanMessagePromptTemplate.from_template(r"""
BASELINE SCENARIO (Reference)

Dwelling: Efficiency apartment (32m²)
Climate Zone: Temperate winter (Brazilian June)
Occupancy: Single adult (regular schedule)

Sensor Network:
◈ Bedroom (9m²):
  - PIR motion detector (bed_motion)
  - Environmental sensor (bed_temp)
◈ Living Area (9m²):
  - PIR motion detector (living_motion)
  - Smart entertainment (living_tv)
  - Environmental sensor (living_temp)

Connectivity:
Bedroom ↔ Living Room (direct access)

User Pattern:
⎔ Active periods: 06:00-08:00 | 17:00-22:30
⎔ Sleep/away: 22:30-06:00 | 08:00-17:00

Environmental Constraints:
⎔ Temp range: 21-26°C (activity-dependent)
⎔ Humidity: 40-70% (inverse temp relationship)
⎔ Appliance power: 100-300W step changes

Sample Data Pattern:
2025-06-01T06:00:22 | bed_temp | 22.0°C | 69% RH
2025-06-01T06:02:18 | bed_motion | triggered (temp ↑0.4°C)
2025-06-01T06:06:41 | living_motion | triggered
2025-06-01T06:07:05 | living_tv | activated (310W)
2025-06-01T06:11:15 | living_temp | 24.1°C | 60% RH

TARGET IMPLEMENTATION

Home Type: Modern smart studio (38m²)
Climate Zone: Same as reference
Occupancy: Same pattern

Enhanced IoT Deployment:
◈ Living Zone (9m²):
  - Motion (living_motion)
  - Smart TV (living_tv)
  - Dimmable LED (living_light)
  - Thermo-hygrometer (living_temp)
  - Entry lock (front_lock)
  
◈ Sleeping Zone (9m²):
  - Motion (bed_motion)
  - Smart lighting (bed_light)
  - Thermo-hygrometer (bed_temp)

◈ Kitchen Nook (2.2m²):
  - Thermo-hygrometer (kitchen_temp)
  - Task lighting (kitchen_light)
  - Appliance plug (fridge_plug)

Spatial Relationships:
Bedroom ⇄ Living ⇄ Kitchen (no bathroom sensors)

Technical Requirements:
✓ Environmental: Temp 21-26°C | Humidity 40-70%
✓ Device responses: 
  - Motion → +0.5-1.5°C temp within 15-30min
  - Activity → 100-300W power step
  - Temp-Humidity: r=-0.8±0.1
✓ Sensors:
  - Temp accuracy: ±0.3°C
  - Motion false positives: 0.2±0.1%
  - Timestamp jitter: <5sec

Output Specification:

CSV Header:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Generate 5+ time-stamped events following the reference behavior patterns but adapted for the target configuration.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])