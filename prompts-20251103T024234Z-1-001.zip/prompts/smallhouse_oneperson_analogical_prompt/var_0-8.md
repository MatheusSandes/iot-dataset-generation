
var_8 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Construct a synthetic IoT dataset by intelligently adapting the patterns from a given smart home scenario to a new environment.
Focus on transferring:
1. Temporal activity rhythms
2. Sensor-response relationships
3. Environmental fluctuations
4. Device interaction patterns
Maintain realistic human behavior probabilities and natural event sequences.
"""),
    HumanMessagePromptTemplate.from_template(r"""
SOURCE SCENARIO (Pattern Donor)

- Layout: Studio smart apartment (30m² total)
- Zones:
  • Sleep Zone:
    - Presence: motion_bed
    - Climate: temp_bed (±0.8°C during occupancy)
  
  • Living Zone:
    - Presence: motion_living
    - Media: smart_tv (180-320W spikes)
    - Climate: temp_living (Δ1.2°C max)

- Connectivity:
  Sleep ←door→ Living

- Occupant Pattern:
  - Active peaks: 06:15-08:45 | 18:00-23:15
  - Absent: 09:00-17:45
  - Asleep: 23:30-06:00

- Environmental Context:
  - Brazilian winter (June-July)
  - Base temp: 21.5-25.8°C
  - Humidity: 42-68% (inverse to temp)

- Sensor Dynamics:
  - Motion → Temp: +0.6-1.4°C (20-35min delay)
  - Media → Power: +150-290W (instant)
  - Temp-Humidity: r = -0.82 (±0.08)

PATTERN EXAMPLE (2 morning hours):
timestamp,device,location,event,value1,value2,occupancy
2025-06-15T06:18:22,temp_bed,Sleep Zone,temp,21.8,68,1
2025-06-15T06:20:41,motion_bed,Sleep Zone,motion,,,1
2025-06-15T06:32:07,motion_living,Living Zone,motion,,,1
2025-06-15T06:33:55,smart_tv,Living Zone,power,285,,1
2025-06-15T06:47:13,temp_living,Living Zone,temp,23.1,62,1

DESTINATION SCENARIO (Pattern Recipient)

- Layout: Smart micro-house (38m² total)
- Zones:
  • Rest Chamber:
    - Detection: motion_rest
    - Lighting: bulb_rest (15-900 lumens)
    - Climate: temp_rest
  
  • Social Hub:
    - Detection: motion_social
    - Media: tv_social
    - Lighting: bulb_social
    - Access: lock_main
    - Climate: temp_social

  • Prep Area:
    - Climate: temp_prep
    - Lighting: bulb_prep
    - Appliance: plug_fridge

  • Hygiene Space: Unsensed

- Connectors:
  Rest ←→ Social ←→ {Prep, Hygiene}

- Resident Profile:
  - Active: 06:30-09:00 | 17:30-23:00
  - Away: 09:15-17:15
  - Resting: 23:15-06:15

- Environmental Match:
  - Same season/location
  - Comparable temp/humidity ranges

- Technical Constraints:
  - All motion-temp-power correlations preserved
  - Timestamp jitter: ±45sec max
  - 98% event accuracy requirement
  - Zero activity during sleep/away windows

REQUIRED OUTPUT:

Begin with header:
timestamp,zone,activated_device,event_category,reading_1,reading_2,occupancy_status

Then generate ONLY the CSV data rows.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])