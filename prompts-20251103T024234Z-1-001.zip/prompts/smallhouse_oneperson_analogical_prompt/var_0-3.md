var_3 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Analyze the reference smart home configuration and generate synthetic IoT events for the target home while maintaining:
1. Temporal patterns reflecting occupant behaviors 
2. Sensor inter-dependencies and physical correlations
3. Environmental conditions regional to Brazil
4. Space constraints of small urban dwellings

Create events reflecting realistic spatial transitions between rooms with probabilistic sensor activation sequences.
"""),
    HumanMessagePromptTemplate.from_template(r"""
ARCHETYPE DATA

RESIDENCE:
| Type          | Compact Loft      |
|---------------|-------------------|
| Space Groups  | Living ▶ Bed   |
| Core Path     | Linear flow       |

EQUIPMENT MAPPING:
│ Bedroom:
│ ▸ motion_bed (245cm ceiling)
│ ▸ temp_bed ±0.3°C accuracy
│ Living: 
│ ▸ motion_living (5Hz sampling)
│ ▸ smart_entertain (350W peak)
│ ▸ ambi_sensor regional specs

LIFESTYLE PATTERNS:
🌅 06:00-08:00 (Morning routine)
☀️ No activity 08:00-17:00
🌇 17:00-22:30 (Active evening)
💤 23 lights off ±15 variance

ENVIRONMENTAL PROXY:
⎔ Winter parameters:
⎔ Temp 21→26 ramp/baseline
⎔ RH 60±10 variance collapse
⎔ Power draws:  300ecdf(max)

_______________

SYNTHESIS TARGET

STRUCTURE:
• Urban Efficient Dwelling
• Modular Zones:
  Living ▶ Bed+Kitch+WC
• Transition Probabilities:
   ▸ Sleeping ▶ Living 78%
   ▸ Living ▶ Kitchen 42%

EXPANDED SENSORS:
│ Living:
│ ▸ Presence Array (RF+IR)
│ ▸ Climate Node 
│ ▸ Lock/Enter
│ Bedroom: 
│ ▸ Multimodal Sentinel
│ Kitchen:
│ ▸ Fridge Current Monitor
│ ▸ Energy Island

BEHAVIORAL NORMS:
⎔ Same temporal windows
⎔ Added:
⎔ Smart lighting transitions
⎔ Security state changes
⎔ Small appliance usage

PHYSICS CONSTRAINTS:
⎔ IR/heat signatures 
⎔ Power→ Temp delta
⎔ Movement spatial cues
⎔ Brazil-specific profiles

________

EXPECTED OUTPUT:

Strict CSV format, sorted timeline:
-- TS, EVT_NO, ZONE, TRG_SRC
-- FILTER: No events in:
 ▸ Sleep phase or away time 
 ▸ Phantom activation 
 ▸ Logically redundant

TIMESTAMPS:
⎔ Jitter pattern:  20ecdf(max)
⎔ Event spreads: regional norms

FORMAT EXAMPLE:
2025-06-01T06:07:13,evt_L012,Living,pulse_x,pir_master...

Generate complete CSV dataset:
"""),
    AIMessagePromptTemplate.from_template("prompt")
])