
var_1 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Analyze the reference smart home data pattern to generate a new IoT dataset for the target home. 
Focus on matching these dimensions:
1. Spatial relationships between devices
2. Temporal patterns of occupancy
3. Environmental impact on sensor readings
4. Inter-device correlations and velocity
Preserve the natural rhythm of activities while adapting device responses to the expanded capabilities.
"""),
    HumanMessagePromptTemplate.from_template(r"""
## Base Scenario Blueprint

Dwelling Type: [35m² smart apartment]

Sensory Network:
≡ Bedroom (9m²):
  ⋄ Motion tracker (bed_motion)
  ⋄ Thermal probe (bed_temp)

≡ Lounge (9m²):
  ⋄ Motion tracker (lounge_motion)
  ⋄ Entertainment hub (lounge_tv)  
  ⋄ Thermal probe (lounge_temp)

Pathways:
- Sleeping area ←→ Living space

Occupant Profile:
∎ Solo dweller
∎ Awake: 0600-0800, 1700-2230
∎ Asleep: 2230-0600
∎ Absent: 0800-1700

Microclimate:
☀ Southern hemisphere winter
🌡 Thermal range: 21-26°C
💧 Humidity cycle: 40-70% RH (inverse temp relationship)

Device Physics:
⎍ ΔTemp/motion: +0.5-1.5°C per 15-30min
⎍ ΔPower/motion: 100-300W spike
⎍ Thermal-humidity R²: -0.7 to -0.9

Data Spectrogram Example:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status
2025-06-01T06:00:22,evt_0001,Bedroom,temperature_reading,bed_temp,22.0,69,,1,low,110,35,good,closed,closed
2025-06-01T06:02:18,evt_0002,Bedroom,motion_detected,bed_motion,22.4,66,1,1,low,240,36,good,closed,closed
2025-06-01T06:06:41,evt_0003,Lounge,motion_detected,lounge_motion,23.0,63,1,1,medium,260,37,good,closed,closed
2025-06-01T06:07:05,evt_0004,Lounge,streaming_event,lounge_tv,,63,,1,medium,310,38,good,closed,closed
2025-06-01T06:11:15,evt_0005,Lounge,temperature_reading,lounge_temp,24.1,60,,1,medium,260,37,good,closed,closed

---

## Target Deployment Scenario

Dwelling Type: [40m² connected home]

Enhanced Sensory Array:
≡ Lounge (9m²):
  ⋄ Motion tracker (main_motion)  
  ⋄ Entertainment hub (entertain_tv)
  ⋄ Photonic node (main_light)
  ⋄ Thermal probe (main_temp)
  ⋄ Access control (portal_lock)

≡ Sleeping area (9m²):
  ⋄ Motion tracker (sleep_motion)
  ⋄ Photonic node (sleep_light)
  ⋄ Thermal probe (sleep_temp)

≡ Food prep zone (2.16m²):
  ⋄ Thermal probe (diet_temp)
  ⋄ Photonic node (diet_light)
  ⋄ Power node (coolant_plug)

≡ Hygiene chamber (2.4m²): No sensors

Connectivity Map:
- Sleeping hub ←→ Main hub
- Main hub → Nutrition zone & Hygiene chamber

Dweller Parameters:
∎ Single professional
∎ Active phases: 0600-0800, 1700-2230
∎ Quiet phases: 2230-0600 (sleep), 0800-1700 (away)

Environmental Context:
☀ Brazilian winter conditions
🌡 Expected thermal range: 21-26°C
💧 Relative humidity: 40-70% (inverse T-coefficient)

Technical Constraints:
⎍ Thermal drift: 0.5-1.5°C per motion event
⎍ Energy impulses: 100-300W on activity
⎍ Humidity-temperature anticorrelation: -0.7 to -0.9
⎍ Noise thresholds: ±0.1°C (temp), ±1% (power)
⎍ Event spacing randomization: Gaussian ±7s
⎍ Activity blackout: 2230-0600, 0800-1700

Required Output Schema:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

[Generate only the CSV dataset matching all specifications]
"""),
    AIMessagePromptTemplate.from_template("prompt")
])