
var_6 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Analyze the provided smart home reference dataset to identify key patterns in device interactions, temporal behaviors, and environmental correlations.
Generate a new IoT dataset that preserves these logical relationships while adapting them to the target home's unique configuration.
Pay special attention to maintaining:
- Time-based activity patterns
- Sensor-to-sensor influence patterns
- Environmental condition progressions
- Physical layout constraints
- Device interaction sequences
"""),
    HumanMessagePromptTemplate.from_template(r"""
SOURCE SMART HOME PATTERNS

Residence Profile:
- Type: Efficient smart studio (38 sqm)
- Location: São Paulo (23°S)
- Climate: Winter conditions (June)
- Resident: Single professional (28-35 yrs)
- Key Behaviors: 
  - Morning routine (06:00-08:00)
  - Evening relaxation (17:00-22:30)
  - Sleep period (22:30-06:00)
  - Away hours (08:00-17:00)

Device Network:
│── Bedroom (9m²)
│   ├─ Occupancy tracker (motion_bed)
│   └─ Climate monitor (temp_bed)
└── Living Area (9m²)
    ├─ Presence detector (motion_living)
    ├─ Entertainment system (tv_ent)
    └─ Ambient sensor (temp_living)

Key Interactions:
1. Motion → Temperature (0.7±0.2°C rise in 12-25min)
2. Activity → Power (150W baseline + 50-200W spikes)
3. Temp ↔ Humidity (r≈-0.8)
4. Device activation sequencing (TV → lights → climate)

Sample Event Stream:
timestamp,location,sensor,event_type,temp,humid,motion,power
2025-06-02T06:05:11,Bedroom,temp_bed,reading,21.8,65,,0
2025-06-02T06:07:33,Bedroom,motion_bed,detection,,63,1,0
2025-06-02T06:25:47,Living,motion_living,detection,22.5,60,1,0
2025-06-02T06:27:12,Living,tv_ent,power_on,,59,,190
2025-06-02T06:32:55,Living,temp_living,reading,23.2,57,,185

TARGET SMART HOME CONFIGURATION

Residence Layout:
│── Sleeping Quarter (9m²)
│   ├─ Motion tracker
│   ├─ Smart lighting
│   └─ Climate sensor
├── Main Lounge (9m²)
│   ├─ Presence module
│   ├─ Entertainment hub
│   ├─ Ambient lights
│   ├─ Climate monitor
│   └─ Entry security
├── Food Prep Zone (2.16m²)
│   ├─ Cooling monitor
│   ├─ Task lighting
│   └─ Appliance plug
└── Hygiene Area (2.4m²) - No monitoring

Critical Constraints:
1. Temporal Boundaries:
   - Active periods: 06:00-08:00, 17:00-22:30
   - Quiet hours: 22:30-06:00 (sleep)
   - Empty home: 08:00-17:00

2. Environmental Ranges:
   - Temperature: 21-26°C (activity-dependent)
   - Humidity: 40-70% (inverse to temp)
   - Power variance: ±15% from reference values

3. Required Correlations:
   - Motion → Temp: +0.5-1.5°C
   - Presence → Power: 100-300W step change
   - Temp/Humidity: r≤-0.7

4. Data Anomalies:
   - Temp noise: ±0.1°C
   - Power variance: ±10%
   - Motion false positives: 0.1-0.3%

Output Specifications:
- Begin with CSV header line
- Include only data rows for active periods
- Maintain original timestamp format
- Preserve all reference relationships
- Add new device interactions logically

Required CSV Header:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status
"""),
    AIMessagePromptTemplate.from_template("prompt")
])