var_6 = ChatPromptTemplate.from_messages([
SystemMessagePromptTemplate.from_template(r"""
Create an IoT dataset that captures both technical sensor readings and human emotional states through carefully chosen descriptive tags. 
Use environmental metrics like `air_quality`, `noise_level`, or `light_level` to subtly convey moments of comfort, stress, or relaxation.
Examples: "chilly_dawn", "chaotic_cooking", "peaceful_reading", "stale_air", "warm_glow", "anxious_waiting".
Apply emotional tags sparingly - only when they genuinely enhance understanding of the human experience.
Maintain strict technical accuracy in all sensor readings.
"""),
HumanMessagePromptTemplate.from_template(r"""
Home Automation Scenario

- Property Type: Compact city apartment

- Connected Devices by Area:

  • Lounge (3m x 3.5m):

  - Motion detector (motion_lounge)
  - Streaming device (stream_box)
  - Adjustable LED (light_lounge)
  - Thermal sensor (temp_lounge)
  - Electronic deadbolt (lock_main)

  • Sleeping Quarters (3.2m x 2.8m):

  - Presence sensor (motion_bed)
  - Dimmable bulb (light_bed)
  - Climate sensor (temp_bed)

  • Cooking Area (2m x 1.5m):

  - Heat sensor (temp_kitchen)
  - Smart illumination (light_kitchen)
  - Energy monitor (plug_fridge)

  • Washroom (2.2m x 1.5m): no monitoring

- Spatial Connections:

  - Bedroom ↔ Living Space
  - Living Space ↔ Kitchen and Bathroom

- Occupants:

  • Primary Resident:
  - Rises 06:30, departs 08:30, back 17:30, retires 23:00

  • Secondary Resident:
  - Rises 07:30, departs 09:30, returns 18:30, sleeps 23:30

- Seasonal Context:
  - Winter season (Southern Hemisphere)
  - Interior climate range: 20–25°C
  - Moisture levels: 45–75%, inverse relationship

Emotional Cue Guidelines:

- Consider adding affective tags when:
  • Pre-dawn chill → "frosty_wakeup"
  • Morning rush → "hectic_prep"
  • Leisure time → "serene_hours"
  • Stagnant activity → "agitated_space"
- Embed these indicators in environmental metrics

Technical Specifications:

- Movement → Temperature rise (0.4–1.6°C over 20–35 min)
- Movement → Power surge (80–350W immediate)
- Temp ⇄ Humidity: -0.65 to -0.95 correlation
- Acoustic:
  - Temp variation ±0.2°C, Power flux ±2%, Motion error: 0.05–0.4%
- Time Notation:
  - Organic intervals only
- Restricted periods:
  - 23:30–06:30 (sleeping)
  - 09:30–17:30 (unoccupied)

Output Structure:

Header:
timestamp,event_id,zone,activity_type,sensor_origin,temp,humidity,movement,presence,illumination,energy_use,sound_level,air_status,entry_state,ventilation_state

Follow with data records containing occasional emotional markers where fitting.
"""),
AIMessagePromptTemplate.from_template("prompt")
])