var_8 = ChatPromptTemplate.from_messages([
SystemMessagePromptTemplate.from_template(r"""
Create an IoT dataset with emotionally descriptive annotations that capture the human experience within the smart home environment.
Inject nuanced affective states through sensor readings like `air_quality` or `light_level` when contextually relevant.
Suggested tags: "morning_chill", "kitchen_chaos", "evening_serenity", "air_stagnation", "comfort_glow", "activity_spike".
Maintain technical accuracy while using tags sparingly for maximum impact - focus on key emotional transition points.
"""),
HumanMessagePromptTemplate.from_template(r"""
Home Layout & Sensor Configuration

» Compact Smart Residence (Urban Setting)

¤ Living Space (3x3m):

‣ Presence detector (motion_living)
‣ Entertainment system (smart_tv)
‣ Adjustable luminaire (light_living)
‣ Thermal sensor (temp_living)
‣ Entry security (lock_front)

¤ Sleeping Quarters (3x3m):

‣ Presence detector (motion_bed)
‣ Dimmable luminaire (light_bed)
‣ Thermal sensor (temp_bed)

¤ Culinary Area (1.8x1.2m):

‣ Thermal sensor (temp_kitchen)
‣ Task lighting (light_kitchen)
‣ Appliance controller (plug_fridge)

¤ Sanitary Room: Unmonitored

Pathways:
- Bedroom ↔ Living ↔ Kitchen/Bathroom

Occupants:

• Person A:
- Awake: 06:00-22:30
- Away: 08:00-17:00

• Person B:
- Awake: 07:00-23:00
- Away: 09:00-18:00

Environmental Context:
- Southern winter (June)
- Indoor climate: 21-26°C
- Moisture range: 40-70% (inverse to temp)

Affective Labeling Guidelines:

‣ Apply emotion-rich descriptors when natural:
  - Pre-dawn cold → "morning_chill"
  - Cooking rush → "kitchen_chaos"
  - Post-work unwind → "evening_serenity"
  - Still air periods → "air_stagnation"

Technical Specifications:

∆ Motion → Thermal effect: +0.5-1.5°C per 15-30min
∆ Presence → Energy spike: +100-300W immediate
∆ Thermal-moisture relation: r=-0.7 to -0.9
∆ Acoustic interference:
  - Thermal noise: ±0.1°C
  - Power variance: ±1%
  - False motion: 0.1-0.3%

Temporal Constraints:
- Quiet hours: 23:00-06:00
- Vacancy period: 09:00-17:00

Data Structure:

Begin with header:
timestamp,event_id,zone,action_type,sensor_origin,temp,humidity,movement,presence,illumination,power,acoustics,air_quality,entry_state,fenestration

Follow with annotated dataset incorporating tasteful emotional markers.
"""),
AIMessagePromptTemplate.from_template("prompt")
])