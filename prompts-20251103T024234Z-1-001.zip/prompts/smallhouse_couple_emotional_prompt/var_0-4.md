
var_4 = ChatPromptTemplate.from_messages([
SystemMessagePromptTemplate.from_template(r"""
Create an IoT dataset that subtly weaves in emotional context through carefully placed environmental descriptors. 
Use sensor fields like `air_quality` or `noise_level` to indicate human experiences through situational modifiers like:
"chilly_dawn" (when morning temps drop sharply)
"humid_afternoon" (when humidity becomes noticeable)
"peaceful_retreat" (evening relaxation period)
"chaotic_prep" (morning rush hour)
Limit these descriptive tags to only the most impactful moments.
"""),
HumanMessagePromptTemplate.from_template(r"""
Living Space Configuration

- Dwelling Type: Compact city apartment

- Connected Devices:

  » Lounge Area (3x3m):
  - Motion scanner (motion_lounge)
  - Entertainment display (smart_display)
  - Adaptive lighting (light_lounge)
  - Thermal sensor (temp_lounge)
  - Entry security (door_lock)

  » Sleeping Quarters (3x3m):
  - Motion scanner (motion_bedroom)
  - Adaptive lighting (light_bedroom)
  - Thermal sensor (temp_bedroom)

  » Food Prep Zone (1.8x1.2m):
  - Thermal sensor (temp_kitchen)
  - Adaptive lighting (light_kitchen)
  - Appliance controller (fridge_plug)

  » Hygiene Space: No monitoring

- Space Connectivity:
  - Bedroom ↔ Lounge
  - Lounge ↔ Kitchen+Hygiene

- Occupants:
  • Person A:
  - Awake 06:00-22:30
  - Absent 08:00-17:00
  • Person B:
  - Awake 07:00-23:00
  - Absent 09:00-18:00

- Seasonal Context:
  - Southern winter (June in Brazil)
  - Indoor climate:
    - Temperature bounds: 21-26°C
    - Moisture range: 40-70% (inverse temp relationship)

Implementation Notes:

- Apply situational descriptors when:
  » Rapid temp drop → "chilly_dawn"
  » Cooking spree → "aromatic_chaos"
  » Wind-down phase → "serene_close"
  » Activity spike → "frantic_burst"
- Embed these in appropriate sensing fields

Technical Specifications:

- Movement→
  - Temperature rise (0.5-1.5°C per 15-30m)
  - Power surge (100-300W immediate)
- Thermal-Humidity relation: Strong negative (-0.7 to -0.9)
- Audio impact:
  - Minor thermal wobble (±0.1°C)
  - Slight power variation (±1%)
  - False motion readings (0.1-0.3%)
- Event timing:
  - Organic intervals only
- Unoccupied windows:
  - 23:00-06:00 (sleep cycle)
  - 09:00-17:00 (away period)

Output Structure:

Begin with header:
timestamp,event_code,area,event_category,source_sensor,heat_index,moisture,presence,occupants,illumination,energy_use,sound_level,atmosphere,entry_state

Then generate the observation log with occasional emotional context markers.
"""),
AIMessagePromptTemplate.from_template("prompt")
])