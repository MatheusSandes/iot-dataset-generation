var_7 = ChatPromptTemplate.from_messages([
SystemMessagePromptTemplate.from_template(r"""
Create an IoT dataset reflecting human experiences through subtle environmental cues.
Enhance raw sensor data with carefully chosen affective indicators in `air_quality` or `noise_level` fields.
Use psychological descriptors like "morning_grogginess", "postwork_fatigue", or "prebed_coziness" to mark emotional transitions.
Limit affective labeling to key moments where environmental conditions clearly influence occupant state.
"""),
HumanMessagePromptTemplate.from_template(r"""
Living Space Configuration

- Dwelling Type: Compact city residence

- Monitored Areas:

  • Social Space (3m x 3m):
  - Presence detector (motion_social)
  - Entertainment system (media_device)
  - Adaptive lighting (light_social)
  - Thermal sensor (temp_social)
  - Entry mechanism (door_system)

  • Sleeping Quarter (3m x 3m):
  - Presence detector (motion_sleep)
  - Adaptive lighting (light_sleep)
  - Thermal sensor (temp_sleep)

  • Food Prep Zone (1.8m x 1.2m):
  - Thermal sensor (temp_kitchen)
  - Adaptive lighting (light_kitchen)
  - Appliance controller (fridge_power)

  • Hygiene Area (2m x 1.2m): sensor-free

- Area Connections:
  - Sleeping Quarter ↔ Social Space
  - Social Space ↔ Food Prep Zone/Hygiene Area

- Occupants:
  • Primary Resident:
  - Awake:06:00, Depart:08:00, Return:17:00, Asleep:22:30
  • Secondary Resident:
  - Awake:07:00, Depart:09:00, Return:18:00, Asleep:23:00

- Climate Context:
  - Southern hemisphere winter month
  - Indoor thermal range:21–26°C
  - Moisture levels:40–70%, inverse thermal relationship

Guidelines:
- Psychological markers are appropriate when:
  • Dawn thermal discomfort → "waking_chill"
  • Food prep activity → "morning_hustle"
  • Evening wind-down → "nighttime_serenity"
  • Extended occupancy → "space_fatigue"
- Embed descriptors in `air_quality` or `noise_level` fields

Technical Specifications:
- Movement → Thermal rise (0.5–1.5°C over 15–30 min)
- Movement → Energy spike (100–300W immediate)
- Thermal-Moisture correlation: -0.7 to -0.9
- Acoustic impact:
  - Temperature variation ±0.1°C
  - Energy fluctuation ±1%
  - Motion false positives: 0.1–0.3%
- Temporal requirements:
  - Organic time intervals
  - Blackout periods:
    - 23:00–06:00 (sleep cycle)
    - 09:00–17:00 (unoccupied)

Output Structure:

Begin with header:
timestamp,event_id,zone,event_category,source_sensor,temperature,humidity,movement,occupancy,illumination,energy_use,sound_level,air_state,portal_status,opening_status

Follow with dataset containing judicious emotional annotations.
"""),
AIMessagePromptTemplate.from_template("prompt")
])