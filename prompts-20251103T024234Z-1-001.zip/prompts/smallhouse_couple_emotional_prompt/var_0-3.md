var_3 = ChatPromptTemplate.from_messages([
SystemMessagePromptTemplate.from_template(r"""
Create an IoT dataset that not only captures technical sensor readings but also moments of human emotional significance. 
Embed psychological comfort markers within the data using fields like `light_level_status`, `ambient_mood`, or `environmental_feel`.

Strategically place descriptors like "stifling_evening", "refreshing_morning", "tense_workspace", or "peaceful_reading" to capture human perception shifts.
Maintain strict adherence to physical constraints while allowing subtle annotations.
"""),
HumanMessagePromptTemplate.from_template(r"""
Residential Profile

- Property Type: Compact urban dwelling (45m² total)

a. Sensor Deployment:

*Central Living Area (9m²):
 - Movement tracker (living_radar)
 - Climate monitor (living_climate)
 - Illumination control (living_lux)
 - Media unit (living_entertainer)

*Sleeping Quarters (9m²):
 - Presence indicator (bedroom_pinger)
 - Weather station (bedroom_conditions)
 - Dimmable lamps (bedroom_glo)

*Food Preparation Zone (2.5m²):
 - Thermal gauge (kitchen_thermo)
 - LED fixtures (kitchen_lumina)
 - Appliance regulator (kitchen_provider)

*Water Room (2.5m²): Uninstrumented

b. Spatial Relationships:
 - Sleeping Chambers ↔ Living Core
 - Living Core ↔ Culinary Space/Hygiene Area

c. Inhabitants:

Primary Tenant:
- Rises: 06:15 | Departs: 08:15 | Re-enters: 17:15 | Rest: 22:45

Secondary Tenant:
- Rises: 07:15 | Departs: 09:15 | Re-enters: 18:15 | Rest: 23:15

d. Climate Context:
- Seasonal depression period (NH Northern)
- Interior thermal variance: 20–25°C
- Moisture content: 35–65% (dynamic opposition)

Emotional Anchoring Rules:

- Predawn temperature dips → "chilly_dawn"
- Morning cooking activities → "siege_kitchen" 
- Post-work winddown → "unwinding_space"
- Weather discomfort → "clammy_days"
a. Sensor Dynamics:

- Each presence → Thermal spike (+0.7-1.8°C within 12-28 mins)
- Activation energy → Immediate 80-350W boost
- Weather correlation coefficient: -0.65 to -0.85
- Acoustic parameters:
  - Temp modulation: ±0.15°C
  - Current oscillation: ±1.5%
  - False detection envelope: 0.15-0.35%
- Chronological flow:
  - Organic temporal distribution only
- Ghost hours:
  - 23:30-06:15 (all residents sleeping)
  - 09:15-17:15 (premises unoccupied")

Output Structure:

Header:
timestamp,event_id,zone,event_class,origin_sensor,temp,humidity,movement,presence_scale,luminance,wattage,sound_profile,atmospheric_state,entry_status,opening_status

Then provide enriched observations with contextual feeling states.
"""),
AIMessagePromptTemplate.from_template("prompt")
])