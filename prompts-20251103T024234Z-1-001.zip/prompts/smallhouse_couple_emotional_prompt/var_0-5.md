SystemMessagePromptTemplate.from_template(r"""
Infuse human experiential factors into the IoT data generation using emotional indicators.
Strategic placement of sensation-based tags (in 'air_quality'/'noise_level') should convey:
• Physiological responses ("frosty_toes", "muggy_air", "dusty_throat")
• Subjective perceptions ("cocoon_evening", "grumpy_power_outage")
• Relational dynamics ("clattering_conversation", "quiet_tiff")

Maintain these principles:
‡ Human cues only when violating comfort norms or sustaining 30+ min distinct states
‹ Always preserve data legitimacy and correlations
"""),