var_9 = ChatPromptTemplate.from_messages([
SystemMessagePromptTemplate.from_template(r"""
Create an IoT dataset for the given scenario, incorporating emotional context through carefully chosen descriptive tags.
Use environmental fields like 'comfort_index' or 'mood_rating' along with standard sensor readings to reflect resident experiences.
Example emotional markers: "chilly_wakeup", "stress_hours", "serene_space", "humidity_discomfort", "warm_welcome", "activity_spike".
Maintain strict technical accuracy while adding these human perspectives when most impactful.
"""),
HumanMessagePromptTemplate.from_template(r"""
### Living Space Configuration ###

- Property Type: Compact city residence  
 n-Room Layout (All rooms climate-linked):

 n1. Main Zone (3×3m):
   - Movement tracker (motion_detector_main)
   - Entertainment system (entertainment_unit)
   - Adjustable lighting (main_light)
   - Thermal sensor (temp_reader_main)
   - Security mechanism (entry_lock)

 n2. Rest Area (3×3m):
   - Motion tracker (motion_tracker_rest)
   - Ambient lighting (sleep_light)
   - Climate monitor (temp_reader_rest)

 n3. Cooking Space (1.8×1.2m):
   - Heat sensor (temp_reader_cook)
   - Task lighting (task_light)
   - Appliance controller (fridge_plug)

- Area Connectivity:
  - Rest Area ↔ Main Zone
  - Main Zone → Cooking Space + Hygiene Area

- Occupants:

 ⎟ Main Occupant ⎟
 - Activity Cycle: 
   06:00 Awake
   08:00 Depart
   17:00 Return
   22:30 Retire

 ⎟ Secondary Occupant ⎟
 - Activity Pattern:
   07:00 Rise
   09:00 Leave
   18:00 Home
   23:00 Sleep

- Climate Context:
 » Season: Southern Hemisphere Winter
 » Indoor Range: 21°–26°C (core areas)
 » Moisture: 40–70% (inverse thermal relationship)

### Emotional Context Guidelines ###

Apply feeling indicators during moments like:
 ☼ Dawn temperature drop → "chilly_wakeup"
 ☽ High-traffic kitchen → "stress_hours"
 ☾ Evening wind-down → "serene_space"
 ◑ Stagnant conditions → "humidity_discomfort"

Place contextual tags in fields:
 - comfort_index
 - mood_rating
 - environment_quality

### Technical Specifications ###

» Motion → Thermal Impact (0.5–1.5°C rise over 15–30 mins)
» Presence → Power Surge (100–300W immediate)
» Heat-Moisture Relation: (-0.7)–(-0.9) correlation
» Sound Parameters:
 ⎟ Temperature Effect: ±0.1°C
 ⎟ Power Variance: ±1%
 ⎟ False Detection Rate: 0.1–0.3%

» Time Constraints:
 - Quiet Hours: 23:00–06:00
 - Vacant Period: 09:00–17:00

### Data Format ###

Initial row (headers):
time_stamp,event_id,zone,category,initiator_sensor,thermal_reading,humidity,presence,occupants_count,illumination,energy_usage,acoustics,air_conditions,access_status,ventilation_status

Follow with dataset records including occasional emotional context marks.
"""),
AIMessagePromptTemplate.from_template("prompt")
])