```python
var_0 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Take a step back and reason globally about this household'92s routines, structure, and sensor layout.
Before producing any output, mentally outline the key phases of the day and how activity evolves.
Then, generate a consistent and realistic IoT dataset based on this high-level understanding.
Only output the final dataset — do not include your reasoning steps or outline.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Scenario Configuration

- House Type: Small urban smart home with two bedrooms

- Devices by Room:

  • Bedroom1:
    - motion_sensor_bedroom1
    - temp_sensor_bedroom1
    - smart_light_bedroom1

  • Bedroom2:
    - motion_sensor_bedroom2
    - temp_sensor_bedroom2
    - smart_light_bedroom2

  • LivingRoom:
    - motion_sensor_living
    - temp_sensor_living
    - smart_tv
    - smart_light_living
    - smart_lock_front

  • Kitchen:
    - temp_sensor_kitchen
    - smart_light_kitchen
    - smart_plug_fridge

  • ServiceArea:
    - motion_sensor_service
    - temp_sensor_service

  • Bathroom: no sensors

- Room Connections:
  - Bedroom1   LivingRoom
  - Bedroom2   Bathroom
  - Bathroom   ServiceArea   Kitchen
  - LivingRoom   Kitchen

- Residents:
  • Adult 1: wakes at 06:00, leaves at 08:00, returns at 17:00, sleeps at 22:30  
  • Adult 2: wakes at 07:00, leaves at 09:00, returns at 18:00, sleeps at 23:00  
  • Child: wakes at 06:30, leaves at 07:30, returns at 17:30, sleeps at 22:00  
  • Adults sleep in Bedroom1; child sleeps in Bedroom2

Global Reasoning Guide:
- Outline the day into behavioral phases:
  • 06:00–07:30: family prepares in sequence  
  • 09:00–17:00: house empty  
  • 17:00–22:00: evening together  
  • 22:00–23:00: gradual silence  
- Consider room transitions (e.g., Bedroom   Kitchen) and realistic device usage  
- Simulate human variability in sensor data — not too perfect

Technical Specifications:

- Motion     Temperature (0.5–1.5°C within 15–30 min)
- Motion     Power (100–300W instantly)
- Temperature   Humidity: correlation -0.7 to -0.9
- Add realistic noise:
  - Temperature 'b10.1°C
  - Power 'b11%
  - Motion FP: 0.1–0.3%

Forbidden Periods:
- 09:00–17:00 (house empty)
- 23:00–06:00 (all asleep)

Output Format:

Begin with the following header:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Then output the dataset consistent with your global understanding.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])
```