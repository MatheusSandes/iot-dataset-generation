
var_8 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Construct a comprehensive IoT dataset by first developing a holistic understanding of the household's daily patterns and infrastructure.
Visualize the home's spatial organization and temporal rhythms before generating data.
Focus on creating natural sensor activity sequences that reflect realistic human behaviors and environmental factors.
Deliver only the final dataset - omit any preliminary analysis or intermediate steps.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Residential Environment Specification

- Dwelling Type: Compact city apartment with two sleeping quarters

- Connected Devices by Area:

  • Master Bedroom:
    - presence_detector_master
    - thermal_sensor_master
    - adjustable_light_master

  • Child's Room:
    - presence_detector_child
    - thermal_sensor_child
    - smart_lamp_child

  • Common Area:
    - activity_sensor_common
    - temperature_sensor_common
    - entertainment_system
    - mood_lighting_common
    - entry_security

  • Food Prep Zone:
    - thermal_sensor_kitchen
    - task_lighting_kitchen
    - appliance_monitor_refrigerator

  • Utility Space:
    - movement_sensor_utility
    - climate_sensor_utility

- Spatial Relationships:
  - Master   Common
  - Child   Hygiene
  - Hygiene   Utility   Food Prep
  - Common   Food Prep

- Household Members:
  • Parent 1: rises 06:00, departs 08:00, arrives 17:00, retires 22:30  
  • Parent 2: rises 07:00, departs 09:00, arrives 18:00, retires 23:00  
  • Youth: rises 06:30, departs 07:30, arrives 17:30, retires 22:00  
  • Parents occupy Master; youth in Child's room

Behavioral Framework:
- Segment the 24-hour cycle into activity clusters:
  • 06:00–07:30: morning routines (sequential)  
  • 09:00–17:00: unoccupied period  
  • 17:00–22:00: evening engagement  
  • After 22:00: winding down  
- Model natural movement patterns between spaces  
- Incorporate organic fluctuations in sensor readings

Technical Parameters:

- Movement detection     Thermal variation (0.4–1.6°C per 10–25 min)
- Movement detection     Energy draw (80–350W instantaneous)
- Temperature   Moisture: inverse relationship -0.6 to -0.8
- Apply realistic variance:
  - Temperature 'b9.5°C
  - Energy 'b13%
  - Motion false positives: 0.05–0.4%

Restricted Hours:
- 09:00–17:00 (unoccupied)
- 23:00–06:00 (sleep period)

Required Output Structure:

Begin with this exact header:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Follow with dataset entries that embody your comprehensive understanding.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])