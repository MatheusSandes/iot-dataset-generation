
var_7 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Analyze this smart home ecosystem holistically, considering occupant interactions and device interdependencies.
First, mentally model the home's activity flow by mapping:
1. Occupant movement patterns
2. Device activation chains
3. Environmental condition dynamics
Then synthesize a temporally coherent dataset that reflects these interconnected systems.
Output only the final dataset — no intermediate reasoning or justifications.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Home Configuration Framework

- Structure: Compact urban dwelling with connected living spaces

- Sensor Network:

  ▶ Sleep Zones:
    • Master Bedroom:
      - presence_master
      - climate_master
      - lighting_master
    • Child's Room:
      - presence_child
      - climate_child
      - lighting_child

  ▶ Common Areas:
    • Social Space:
      - presence_living
      - climate_living
      - entertainment_system
      - ambient_lighting
      - entry_sensor
    • Food Prep:
      - climate_kitchen
      - task_lighting
      - appliance_monitor

  ▶ Utility Zone:
    - presence_utility
    - climate_utility

- Spatial Relationships:
  Master   Social   Food Prep
  Child   Hygiene   Utility   Food Prep

- Occupant Profiles:
  ▶ Primary Resident:
    Active 06:15-07:45 & 17:15-22:45 
    Asleep 23:00-06:00
  ▶ Secondary Resident:
    Active 07:00-08:30 & 18:00-23:30
    Asleep 00:00-07:00
  ▶ Youth Resident:
    Active 06:30-07:15 & 16:45-21:45
    Asleep 22:30-06:30

Activity Phasing Model:
- Morning Routine (06:00-08:30): Sequential space utilization
- Daytime Void (09:00-17:00): Minimal interaction window
- Evening Engagement (17:00-23:00): Gradual activity decay
- Night Phase (23:00-06:00): System silence

Data Integrity Rules:
▶ Motion triggers:
  - Lights activate at 80-150 lux
  - 0.2-0.5% false positives expected
▶ Environmental:
  - Temp fluctuation: ±0.8°C/30min
  - Humidity inverse correlation: 0.65-0.85
  - Noise component: 2-5% signal variation
▶ Power:
  - Base load: 50-120W
  - Active device: +150-400W instant
▶ Strict inactivity periods enforced:
  - 09:00-17:00 (unoccupied)
  - 23:30-06:00 (sleep cycle)

Output Structure:

Begin with precise header:
timestamp,event_id,zone,event_class,origin_sensor,temp_c,rel_humidity,motion_state,occupancy_status,illumination,power_draw,acoustic_level,air_index,entry_status,portal_status

Generate corresponding dataset entries.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])