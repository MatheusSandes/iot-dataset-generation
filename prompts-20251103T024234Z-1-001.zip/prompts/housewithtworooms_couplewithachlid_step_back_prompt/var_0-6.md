var_6 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Analyze this smart home scenario holistically, considering spatial relationships, resident routines, and typical device interactions.
First conceptualize the flow of daily activities before generating sensor data that reveals this behavioral pattern.
Focus on natural transitions between space usage and show device correlations.
Provide only the final simulated dataset - exclude all analytical commentary.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Blueprint

Dwelling Characteristics: Compact smart apartment with minimal partitions

Device Network:

1. Sleep Quarters A:
   - presence_detector_A (ultrasonic)
   - thermal_sensor_A
   - adaptive_lamp_A (RGBW)

2. Sleep Quarters B:
   - presence_detector_B
   - thermal_sensor_B
   - nightlight_B

3. Common Space:
   - mmWave_occupancy
   - climate_monitor
   - entertainment_unit
   - ambiance_lighting
   - entryway_security

4. Food Preparation Zone:
   - ambient_sensors
   - task_lighting
   - refrigerator_monitor

5. Utility Area:
   - doorway_sensor
   - environmental_sensor

Adjacency Matrix:
- A <-> Common  
- B <-> Sanitation  
- Sanitation <-> Utility <-> Food  
- Common <-> Food  

Dweller Patterns:
- ResidentA: rises 06:15, departs 08:20, home 17:45, retires 22:45
- ResidentB: rises 07:10, departs 09:15, home 18:30, retires 23:15  
- Youth: rises 06:45, departs 07:45, home 17:10, retires 22:15
- Sleeping arrangements: A=adults, B=youth

Activity Framework:
- Early Phase (06:00-08:00): Sequential morning routines  
斌 Midday Phase (09:30-17:00): Vacant dwelling  
- Evening Phase (17:30-22:00): Shared family time  
- Wind-down Phase (22:00-23:30): Activity attenuation  

Technical Parameters:

Device Interactions:
- Presence -> Climate adjustment (0.3-0.8肏 fluctuation)
- Activity -> Power spike (90-350W)
- Thermal-Hygrometric: inverse relationship (-0.65 to -0.85)
- Real-world variance:
  - Temperature 斌0.2肏
  - Energy 斌5%
  - False detection rate 0.15%-0.25%

Proscribed Intervals:
- 09:30-17:00 (unoccupied)
- 23:30-06:00 (sleep cycle)

Required Output Structure:

Initiate with exact header row:
timestamp,event_id,zone,event_class,origin_device,temp_c,rel_humidity,activity_flag,occupancy_count,illumination_pct,energy_w,acoustic_db,aqi,egress_state,aperture_status

Follow with synthetic data adhering to your spatial-temporal analysis.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])