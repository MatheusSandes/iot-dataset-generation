
var_5 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
First, mentally model the household's daily patterns considering all spatial relationships and resident behaviors. 
Visualize how people move through the spaces and interact with devices throughout the day.
After developing this comprehensive mental model, generate a realistic IoT dataset that accurately reflects these patterns.
Output only the final dataset - no reasoning or intermediate steps should be included.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Home Configuration Profile

- Dwelling Type: Compact city apartment with dual bedrooms

- Device Network by Space:

  • SleepZone1:
    - presence_sensor_sleep1
    - climate_sensor_sleep1
    - adaptive_lighting_sleep1

  • SleepZone2:
    - presence_sensor_sleep2
    - climate_sensor_sleep2
    - adaptive_lighting_sleep2

  • CommonArea:
    - movement_detector_common
    - environmental_sensor_common
    - entertainment_system
    - mood_lights_common
    - entry_security

  • FoodPrepZone:
    - environment_monitor_kitchen
    - task_lighting_kitchen
    - appliance_controller_fridge

  • UtilityZone:
    - activity_sensor_utility
    - conditions_sensor_utility

  • HygieneArea: no monitoring

- Spatial Connectivity:
  - SleepZone1 → CommonArea
  - SleepZone2 → HygieneArea
  - HygieneArea → UtilityZone → FoodPrepZone
  - CommonArea ↔ FoodPrepZone

- Household Members:
  • Parent1: rises at 6AM, departs 8AM, back by 5PM, retires 10:30PM
  • Parent2: rises at 7AM, departs 9AM, back by 6PM, retires 11PM
  • Youth: rises at 6:30AM, departs 7:30AM, back by 5:30PM, retires 10PM
  • Sleep arrangements: Parents in SleepZone1; Youth in SleepZone2

Behavioral Framework:
- Primary temporal segments:
  • Dawn Preparation (6:00-7:30): sequential morning routines
  • Daytime Absence (9:00-17:00): unoccupied dwelling
  • Evening Gathering (17:00-22:00): family activity period
  • Night Wind-down (22:00-23:00): decreasing activity
- Simulate natural movement patterns between connected spaces
- Incorporate behavioral variance to avoid mechanical patterns

Technical Implementation:

- Movement     Climate (0.5–1.5°C variance per 15–30 min)
- Movement     Energy (instant 100–300W demand shifts)
- Climate   Moisture: inverse relationship (-0.7 to -0.9)
- Natural data imperfections:
  - Thermal reading variation: ±0.1°C
  - Power measurement variance: ±1%
  - False positive motion: 0.1–0.3%

Inactive Periods:
- 9:00–17:00 (unoccupied)
- 23:00–6:00 (sleeping hours)

Data Structure:

Begin with this exact header row:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Then provide the complete simulated dataset.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])