var_3 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
First, analyze the given home automation scenario to fully grasp its core components and operating conditions. 
Clearly outline the spatial relationships between rooms, device configurations, user patterns, and environmental factors.
Then, generate a comprehensive IoT dataset that accurately reflects all these parameters.
Important: Only output the final dataset - suppress all intermediate analysis.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Configuration Blueprint

► Property Profile:
- Category: Urban compact living space
- Season: Mid-winter (Southern Hemisphere)
- Climate: Sub-tropical location (Brazil)

► Device Ecosystem by Zone:

# Main Area (3×3m):
¤ Presence: motion_sensor_main
¤ Entertainment: smart_tv_main
¤ Illumination: led_light_main
¤ Climate: temp_sensor_main
¤ Security: door_lock_main

# Sleep Quarters (3×3m):
¤ Presence: motion_sensor_sleep
¤ Illumination: led_light_sleep
¤ Climate: temp_sensor_sleep

# Food Prep (1.8×1.2m):
¤ Climate: temp_sensor_kitchen
¤ Illumination: led_light_kitchen
¤ Appliance: smart_plug_cooling

# Sanitation (2×1.2m): Passive zone

► Spatial Links:
- Sleep Quarters ↔ Main Area
- Main Area ↔ Food Prep & Sanitation

► Resident Pattern:
☼ Active: 06:00–08:00 | 17:00–22:30
☽ Resting: 22:30–06:00
☁ Absent: 08:00–17:00

► Ambient Conditions:
✦ Temperature range: 21–26°C
✦ Humidity: 40–70% (inverse thermal relationship)

Technical Parameters:

◆ Sensor Interactions:
- Motion → Thermal impact (Δ0.5–1.5°C per 15–30min)
- Motion → Energy surge (100–300W immediate)
- Thermal ⇄ Humidity: r=-0.8±0.1
◆ Error Margins:
- Temperature: ±0.15°C
- Power: ±0.15%
- False positives: 0.1–0.3%
◆ Chronicle Rules:
- No events during rest/absence periods
- Time entries must demonstrate natural variance

Implementation Protocol:

1. Verify comprehension by internally summarizing the scenario
2. Create dataset strictly adhering to all specifications
3. Omit any cognitive process from output

Output Convention:

Begin with precise header:
timestamp,node_id,zone,event_class,source_device,temperature,humidity,motion,presence,illumination,energy_use,sound_level,air_metric,entry_state,viewport_status

Then deliver only the dataset in comma-delimited format.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])