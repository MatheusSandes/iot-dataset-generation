var_7 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
First, internalize the scenario by reconstructing it conceptually - grasp the spatial layout, temporal patterns, and device interactions. 
Then, synthesize a plausible IoT dataset that strictly adheres to all physical constraints and behavioral patterns described.
Your output must be purely the generated dataset - any analysis or rephrasing must remain invisible in the final delivery.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Blueprint

[Architecture]
• Compact city dwelling with 4 zones:
  - Lounge (3x3m):
    * Presence: motion_sensor_lounge
    * Climate: temp_sensor_lounge
    * Appliances: smart_tv, smart_light_lounge
    * Security: smart_lock_main

  - Sleep Chamber (3x3m):
    * Presence: motion_sensor_chamber
    * Climate: temp_sensor_chamber
    * Lighting: smart_light_chamber

  - Food Prep (1.8x1.2m):
    * Climate: temp_sensor_kitchen
    * Lighting: smart_light_kitchen
    * Power: smart_plug_cooler

  - Hygiene Area (2x1.2m): No instrumentation

[Zone Connectivity]
• Bedroom ↔ Living Room
• Living Room ↔ Kitchen + Bathroom

[Resident Patterns]
• Active phases: 06:00–08:00 | 17:00–22:30
• Dormant period: 22:30–06:00
• Absent window: 08:00–17:00

[Environmental Context]
• Seasonal: Brazilian winter (June)
• Thermal range: 21–26°C internal
• Moisture: 40–70% RH (inverse thermal relation)

[Physical Laws]
• Movement impact:
  - Heat: +0.5–1.5°C over 15–30 min
  - Energy: +100–300W instant surge
• Thermal-humidity correlation: -0.7 to -0.9
• Measurement noise:
  - Temp: ±0.1°C
  - Power: ±1%
  - False motion: 0.1–0.3% rate
• Event chronology must show natural variance
• Silent periods: 22:30–06:00 & 08:00–17:00

[Execution Protocol]
1. Conduct cognitive mapping of scenario parameters
2. Manufacture dataset matching all specifications
3. Omit all intermediary processing steps

[Output Schema]
timestamp,event_id,zone,event_class,actuator,temp_C,humidity_pct,motion_flag,presence,illumination,power_W,signal_noise,air_index,entry_state,aperture_status
"""),
    AIMessagePromptTemplate.from_template("prompt")
])