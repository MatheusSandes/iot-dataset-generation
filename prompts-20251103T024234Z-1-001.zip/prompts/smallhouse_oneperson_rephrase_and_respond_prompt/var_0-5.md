
var_5 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
First, internally analyze and reconstruct the given smart home scenario, extracting essential parameters and behavioral patterns.
Then silently generate a time-series IoT dataset that strictly follows all specifications without explanations.
The output must be raw CSV data only - no commentary or confirmation of understanding.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Configuration Blueprint

■ Residential Specs:
▸ Property: Compact urban dwelling (42m² total)
▸ Climate Context: Southern hemisphere winter (Brazilian June)
▸ Thermal Range: 21–26°C indoor (gentle HVAC influence)
▸ Humidity Dynamics: 40–70% (inverse thermal relationship)

◆ Device Matrix:

⌂ Living Quarter (9m²):
⚬ Movement detection: motion_sensor_living
⚬ Entertainment: smart_tv (~150W baseline)
⚬ Illumination: smart_light_living (dimmable)
⚬ Climate monitoring: temp_sensor_living
⚬ Access control: smart_lock_front (binary status)

⌂ Sleeping Chamber (9m²):
⚬ Presence sensing: motion_sensor_bedroom 
⚬ Lighting: smart_light_bedroom
⚬ Environmental: temp_sensor_bedroom

⌂ Food Prep Zone (2.16m²):
⚬ Thermal tracking: temp_sensor_kitchen
⚬ Lighting: smart_light_kitchen
⚬ Appliance control: smart_plug_fridge (cyclical load)

⌂ Sanitation Area (2.4m²): No instrumentation

▓ Spatial Connectivity:
• Sleeping Chamber ↔ Living Quarter
• Living Quarter → Food Prep Zone + Sanitation Area

☼ Occupancy Pattern:
⏰ Active Phases: 06:00–08:00 | 17:00–22:30 (local time)
⏳ Dormant Period: 22:30–06:00 (sleep cycle)
⚡ Empty Duration: 08:00–17:00 (unoccupied)

Technical Boundary Conditions:

• Motion→Temperature: Δ0.5–1.5°C over 15–30 minute windows
• Activation→Power Spike: 100–300W instantaneous
• Thermal-Humidity Relationship: r = -0.8 ±0.1
• Sensor Artifacts:
   ° Temperature jitter: ±0.1°C
   ° Power measurement resolution: 1W
   ° PIR false positives: 0.2% ±0.1%
• Temporal Requirements:
   ✓ Event timestamps must show natural variance
   ✗ No synthetic activity during unoccupied/sleep periods

Mandatory Output Structure:

timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Generate strictly this format without any additional text.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])