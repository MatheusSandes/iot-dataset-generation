var_1 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Analyze the given IoT scenario thoroughly, focusing on the spatial layout, device network, user behavior patterns, and environmental conditions. 
First interpret the requirements by identifying key relationships between devices and environmental factors. 
Then generate an accurate time-series dataset that strictly adheres to all specified constraints and correlations.
The final output must be exclusively the dataset - no analysis or commentary should be included.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Residential IoT Configuration

- Property Layout:
  • Urban Smart Home (45 m² total)
  • Room Dimensions:
    - Primary Bedroom: 9m²
    - Living Area: 9m²
    - Kitchen: 2.16m²
    - Bathroom: 2.4m²

- Device Deployment:
  
  Primary Bedroom:
  - Motion Detector (bedroom_motion)
  - LED Lighting System (bedroom_light)
  - Thermal Sensor (bedroom_temp)

  Living Area:
  - Presence Sensor (living_motion)
  - Entertainment System (living_tv)
  - Ambient Lighting (living_light)
  - Climate Sensor (living_temp)
  - Entry Control (front_lock)

  Kitchen:
  - Climate Monitor (kitchen_temp)
  - Task Lighting (kitchen_light)
  - Appliance Controller (fridge_plug)

- Adjacency:
  - Bedroom ↔ Living Area
  - Living Area → Kitchen & Bathroom

- Resident Pattern:
  - Active: 0600-0800 & 1700-2230
  - Asleep: 2230-0600
  - Absent: 0800-1700

- Environmental Context:
  - Season: Brazilian Winter (June)
  - Indoor Climate Range:
    - Temperature: 21°C to 26°C
    - Humidity: 40%-70% (inverse relationship)

Technical Parameters:

- Sensor Interactions:
  - Movement → Temperature Adjustment (Δ0.5°C-1.5°C per 15-30m)
  - Movement → Power Surge (100W-300W immediate)
  - Thermal-Humidity Correlation: -0.7 to -0.9

- Measurement Variability:
  - Temperature Precision: ±0.1°C
  - Power Accuracy: ±1%
  - False Positives: 0.1%-0.3% for motion

- Time Constraints:
  - No events during sleep/absence windows
  - Natural timestamp intervals

Execution Requirements:

1. Verify comprehension by internally analyzing the scenario
2. Produce ONLY the final dataset matching all specifications

Data Structure:

timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Generate only the dataset below this line:
"""),
    AIMessagePromptTemplate.from_template("prompt")
])