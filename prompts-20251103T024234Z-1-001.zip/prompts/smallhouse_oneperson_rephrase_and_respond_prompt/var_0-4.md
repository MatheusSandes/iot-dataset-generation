var_4 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Analyze the provided smart home scenario thoroughly. Identify all key components including:
- Room specifications and device configurations
- User activity patterns
- Environmental conditions
- Technical constraints and correlations

After comprehensive analysis, generate an accurate IoT device dataset matching these specifications. Omit all analysis steps from the final output - only provide the dataset.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Configuration Details:

-- SPATIAL LAYOUT --
• Living Space (9m²):
  - Detection: motion_sensor_living
  - Entertainment: smart_tv
  - Lighting: smart_light_living
  - Climate: temp_sensor_living
  - Security: smart_lock_front

• Rest Area (9m²):
  - Detection: motion_sensor_bedroom
  - Lighting: smart_light_bedroom
  - Climate: temp_sensor_bedroom

• Meal Prep Zone (2.16m²):
  - Climate: temp_sensor_kitchen
  - Lighting: smart_light_kitchen
  - Appliance: smart_plug_fridge

• Hygiene Area (2.4m²): No monitoring

-- MOVEMENT PATHS --
Bedroom ↔ Living Room ↔ Kitchen/Bathroom

-- HUMAN OCCUPANCY PATTERN --
06:00-08:00: Morning routine
17:00-22:30: Evening activity
22:30-06:00: Sleep period
08:00-17:00: Away period

-- ENVIRONMENTAL PROFILE --
Season: Southern hemisphere winter
Indoor Temp Range: 21°C-26°C
Humidity: 40-70% (inverse relationship with temp)

-- SYSTEM CONSTRAINTS --
1. Activity Responses:
   - Motion → Temp change (0.5-1.5°C over 15-30min)
   - Motion → Power surge (100-300W immediate)
2. Environmental Links:
   - Temp/Humidity correlation: -0.7 to -0.9
3. Error Margins:
   - Temp reading ±0.1°C
   - Power reading ±1%
   - Motion false positives: 0.1-0.3%

-- GENERATION RULES --
• No simulated activity during sleep/away periods
• Event timestamps must show natural variance
• Maintain all specified relationships

Output Requirements:
Begin with this exact header:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Then generate ONLY the dataset below this header.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])