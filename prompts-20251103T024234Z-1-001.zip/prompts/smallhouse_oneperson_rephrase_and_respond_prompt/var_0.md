```python
var_0 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You must begin by rephrasing the scenario in your own words, identifying the main structure, constraints, and requirements of the problem.
After that, generate a realistic IoT dataset accordingly.
Only the final output (the dataset) should be visible — do not include your rephrasing in the output.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Scenario Configuration

- House Type: Small urban smart home

- Devices by Room:

  • Living Room (3m x 3m):
    - 1x Motion sensor (motion_sensor_living)
    - 1x Smart TV (smart_tv)
    - 1x Smart light bulb (smart_light_living)
    - 1x Temperature sensor (temp_sensor_living)
    - 1x Smart lock (smart_lock_front)

  • Bedroom (3m x 3m):
    - 1x Motion sensor (motion_sensor_bedroom)
    - 1x Smart light bulb (smart_light_bedroom)
    - 1x Temperature sensor (temp_sensor_bedroom)

  • Kitchen (1.8m x 1.2m):
    - 1x Temperature sensor (temp_sensor_kitchen)
    - 1x Smart light bulb (smart_light_kitchen)
    - 1x Smart plug (smart_plug_fridge)

  • Bathroom (2m x 1.2m): no sensors

- Room Connections:
  - Bedroom   Living Room
  - Living Room   Kitchen and Bathroom

- User:
  - Active from 06:00–08:00 and 17:00–22:30
  - Sleeps from 22:30 to 06:00
  - Away from 08:00 to 17:00

- Environment:
  - Winter in Brazil (June)
  - Indoor temperature: 21–26°C
  - Humidity: 40–70%, inversely correlated

Technical Constraints:

- Motion     Temperature (0.5–1.5°C in 15–30 min)
- Motion     Power (100–300W instantly)
- Temperature   Humidity: correlation -0.7 to -0.9
- Noise:
  - Temperature: 'b10.1°C
  - Power: 'b11%
  - Motion FP: 0.1–0.3%
- Timestamps must vary realistically
- Do not generate events between 22:30–06:00 or 08:00–17:00

Instructions:

- Step 1: Rephrase the task in your own words to confirm understanding.
- Step 2: Generate the final dataset based on that rephrased understanding.
- Do not include the rephrasing in the final output.

Output Format:

Start with this header:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Then output the final dataset only.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])
```