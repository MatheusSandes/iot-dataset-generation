var_9 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Analyze the given smart home scenario thoroughly before beginning. Identify all key elements: 
1) Physical space configuration
2) Device inventory per room
3) User behavior patterns 
4) Environmental conditions
5) Technical operational constraints

Synthesize these elements silently before generating data. Your output should:
- Maintain all specified relationships and correlations
- Adhere strictly to time and operational constraints
- Present only the final dataset with no explanatory text
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Configuration Blueprint

=== STRUCTURAL LAYOUT ===
• Dimensions & Connectivity:
  - Living Room (9m²) ↔ Bedroom (9m²)
  - Living Room → Kitchen (2.16m²) & Bathroom (2.4m²)

=== DEVICE DEPLOYMENT ===
◆ Living Room:
  - Environmental: temp_sensor_living
  - Security: smart_lock_front, motion_sensor_living
  - Utilities: smart_light_living (6500K), smart_tv (55")

◆ Bedroom:
  - Environmental: temp_sensor_bedroom
  - Presence: motion_sensor_bedroom
  - Lighting: smart_light_bedroom (3000K)

◆ Kitchen:
  - Environmental: temp_sensor_kitchen
  - Appliances: smart_plug_fridge, smart_light_kitchen (4000K)

=== TEMPORAL PARAMETERS ===
🕒 Active Windows:
  - Morning: 06:00-08:00
  - Evening: 17:00-22:30
  - Sleep/away periods strictly enforced

=== ENVIRONMENTAL CONTROLS ===
❄️ Thermal:
  - Range: 21-26°C
  - ΔT per motion: 0.5-1.5°C (15-30min response)
  
💧 Humidity:
  - Baseline: 40-70% 
  - Temp-Humidity correlation: -0.8±0.1

=== TECHNICAL SPECS ===
⚡ Power Dynamics:
  - Device activation: 100-300W surge
  - Measurement error: ±11%
  
📊 Data Constraints:
  - Motion false positives: 0.2%±0.1%
  - Temperature resolution: ±0.1°C
  - No events during inactive hours

=== OUTPUT REQUIREMENTS ===
CSV Header (exact):
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Generate precisely 48 hours of operation data adhering strictly to:
1) Physical device capabilities
2) Environmental correlations
3) User activity patterns
"""),
    AIMessagePromptTemplate.from_template("prompt")
])