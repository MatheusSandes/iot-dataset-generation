"""),
    HumanMessagePromptTemplate.from_template(r"""
# Paradigm Comparison Study

## Functional Example (Valid Patterns)
