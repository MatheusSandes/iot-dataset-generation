var_4 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are analyzing household activity patterns through sensor data examples. 
Review one properly structured example and one flawed example to understand key differences in temporal logic and sensor correlations.
Then create a realistic dataset matching the specified family schedule and home layout.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Reference Examples Analysis:

▶ Valid Example (Proper Event Sequencing)
Morning Phase (06:00-08:00):
- Sequential bedroom activations aligned with wake times
- Logical kitchen appliance usage before departure
- Correct motion-power correlations (90-250W range)
- Natural temperature fluctuation patterns

Critical Characteristics:
✓ Events follow occupancy timeline
✓ Sensor readings maintain physical relationships
↓ Example Peak Load: 07:15 - All residents active

▶ Invalid Example (Common Mistakes)
Flaws Identified:
× Motion events during empty-house period (10:00)
× Impossible power draw (700W smart plug)
× Reversed temperature/motion correlation
× Missing child's morning routine

---

New Scenario Parameters:
🖥️ Smart Home Blueprint:
│ Bedroom1 ── LivingRoom ── Kitchen
│      │                   ║
│ Bedroom2 ── Bathroom ────╝

👨‍👩‍👦 Resident Patterns:
│ 06:00   Adult1 active
│ 06:30   Child wakes (Bedroom2)
│ 07:00   Adult2 joins
│ 07:30   Child departs
│ 09:00   Empty house begins
│ 17:00   Evening cycle starts

⚙️ Technical Constraints:
- Motion→Power: immediate 80-280W change
- Occupancy→Temp: +0.7°C per active person
- Humidity inverse to temperature
- Max 0.2% random false positives

📊 Required Output Format:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Generate data reflecting:
1. Morning rush hour (06:00-08:00)
2. Evening family time (17:00-22:00)
3. Proper night inactivity (23:00-06:00)
4. Correlated sensor behaviors
"""),
    AIMessagePromptTemplate.from_template("prompt")
])