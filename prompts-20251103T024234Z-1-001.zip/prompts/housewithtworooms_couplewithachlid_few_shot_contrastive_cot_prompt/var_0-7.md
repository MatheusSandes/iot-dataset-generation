
var_7 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You're analyzing a smart home behavior dataset generation task for a 2-adult, 1-child household.
You'll receive:
1. A positive example showing proper sensor event patterns
2. A negative example demonstrating common generation mistakes
Your task is to synthesize a realistic new dataset following the given home scenario.
"""),
    HumanMessagePromptTemplate.from_template(r"""
POSITIVE EXAMPLE (Well-Structured)

Household Dynamics:
- Resident 1: Active 06:00-22:30 (Main bedroom)
- Resident 2: Active 07:00-23:00 (Main bedroom)
- Child: Active 06:30-22:00 (Children's room)
- All leave by 09:00, return after 17:00

Proper Event Characteristics:
✅ Gradual temperature changes with movement
✅ Appropriate power spikes when devices activate
✅ No events during empty periods (09-17, 23-06)
✅ Natural timing between events (not mechanical intervals)
✅ Correct sensor combinations

CSV Header:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Sample Valid Events:
2025-06-01T06:12:34,evt_0001,MainBedroom,motion_detected,motion_main_bed,22.1,65,1,1,low,120,32,good,closed,closed
2025-06-01T06:43:21,evt_0002,ChildrensRoom,sensor_activity,motion_child_room,22.4,64,1,1,low,105,31,good,closed,closed
2025-06-01T07:15:09,evt_0003,Kitchen,appliance_usage,smart_fridge,,62,,1,medium,205,34,good,closed,closed

NEGATIVE EXAMPLE (Common Errors)

Identified Flaws:
❌ Sensors triggering during unoccupied hours
❌ Jumping temperature readings (no gradual change)
❌ Unrealistic power consumption values
❌ Mechanical event timing (every X minutes)
❌ Missing expected child activity
❌ Contradictory sensor states

Invalid Events Warning:
2025-06-01T11:30:00,evt_0007,LivingRoom,sensor_activation,motion_living,18.9,70,1,1,high,420,33,good,closed,closed
2025-06-01T03:45:00,evt_0010,Kitchen,temp_change,temp_kitchen,25.6,48,,1,off,180,28,good,closed,closed

GENERATION TASK

Smart Home Layout:
- Bedroom1 (Main): 9m² with motion, temp, smart light
- Bedroom2 (Child): 9m² with motion, temp, smart light
- Living Room: 9m² with TV, lights, lock, motion
- Kitchen: 2.16m² with fridge plug, lights
- Service Area: Motion and temp sensors
- Bathroom: No monitoring

Resident Patterns:
- Adult1: Awake 06:00-22:30
- Adult2: Awake 07:00-23:00
- Child: Awake 06:30-22:00
- All out 09:00-17:00

Critical Constraints:
- Motion must affect temperature (gradual 0.5-1.5°C rise)
- Device activation causes power spikes (100-300W)
- Inverse temp-humidity relationship (-0.7 to -0.9)
- Natural randomness:
  - ±0.1°C temp fluctuations
  - ±1% power variance
  - 0.1-0.3% false motion positives
- Silent periods: 09:00-17:00 and 23:00-06:00

Required Output Header:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Generate realistic sensor events for a full day that respect all constraints.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])