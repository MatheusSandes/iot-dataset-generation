
var_2 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You'll analyze two contrasting smart home behavior patterns for a family with two adults and one child. 
First identify the valid vs. invalid reasoning patterns, then synthesize authentic sensor data for a similar household configuration.
"""),
    HumanMessagePromptTemplate.from_template(r"""
# Demonstration of Correct vs Incorrect Patterns

## Positive Example (Valid Logic)

Household Routine:
- Adult1: Active 06:00-08:00 & 17:00-22:30
- Adult2: Active 07:00-09:00 & 18:00-23:00
- Child: Active 06:30-07:30 & 17:30-22:00
- Sleeping arrangements: Adults(Bedroom1), Child(Bedroom2)

Proper Event Chain:
1. Temperature rises gradually with morning activity
2. Power usage correlates with movement patterns
3. Timestamps have natural variability
4. No phantom events during empty periods

Sample Event Stream:
timestamp,event_id,...[full header]...
2025-06-01T06:08:15,evt_0102,Bedroom1,motion_detected,motion_sensor_bedroom1,22.1,68,1,1,low,120,32,good,closed,closed
2025-06-01T06:31:22,evt_0103,Kitchen,power_usage,smart_plug_toaster,23.5,65,0,1,medium,850,34,good,closed,closed
2025-06-01T18:07:51,evt_0104,LivingRoom,motion_detected,motion_sensor_living,23.8,62,1,1,high,210,38,good,closed,closed

## Negative Example (Flawed Logic)

Same household setup but with errors:
- Mechanical 5-minute intervals between events
- Impossible power draw values
- Contradictory sensor readings
- Activity during empty periods

Faulty Event Stream:
timestamp,event_id,...[full header]...
2025-06-01T11:30:00,evt_0201,Bedroom2,motion_detected,motion_sensor_bedroom2,18.7,72,1,0,low,0,25,good,closed,closed
2025-06-01T11:35:00,evt_0202,Kitchen,power_usage,smart_plug_fridge,19.2,70,0,0,off,1200,26,good,closed,closed
2025-06-01T11:40:00,evt_0203,LivingRoom,temperature_reading,temp_sensor_living,17.8,75,1,0,medium,0,27,good,closed,closed

# New Scenario Configuration

## Home Layout
- Bedroom1: 3×3m (motion/temp/light)
- Bedroom2: 3×3m (motion/temp/light)
- LivingRoom: 3×3m (motion/temp/TV/light/lock)
- Kitchen: 1.8×1.2m (temp/light/fridge)
- ServiceArea: Motion+Temp
- Bathroom: No sensors

## Daily Rhythm
06:00 ▶ Adult1 active
06:30 ▶ Child joins
07:00 ▶ Adult2 joins
07:30 ▶ Child departs
08:00 ▶ Adult1 departs
09:00 ▶ Adult2 departs
17:00 ▶ Adult1 returns
17:30 ▶ Child returns
18:00 ▶ Adult2 returns
22:00 ▶ Child asleep
22:30 ▶ Adult1 asleep
23:00 ▶ Adult2 asleep

## Technical Specifications
- Motion must affect temperature (0.5-1.5°C) within 30 minutes
- Power spikes (100-300W) immediate on device use
- Humidity inversely correlates with temperature
- Implement realistic noise:
  - Temperature: ±0.1°C
  - Power: ±10%
  - Occasional false motion (0.1-0.3%)

## Required Output Format
First line: Complete CSV header
Subsequent lines: Realistic event data respecting:
- Physical correlations
- Occupancy patterns
- Natural timing variations
- Device capabilities
"""),
    AIMessagePromptTemplate.from_template("prompt")
])