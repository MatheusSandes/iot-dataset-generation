
var_3 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a residential pattern analyzer creating IoT datasets for a two-adult, one-child household.
Examine one proper and one flawed reasoning chain about smart home events, then generate accurate sensor data reflecting real-world patterns.
"""),
    HumanMessagePromptTemplate.from_template(r"""
## Learning From Examples

*Valid Example Analysis*
- Timeline Accuracy: Events precisely match wake/leave/return/sleep schedules
- Sensor Coherence: Motion activates logical power/temperature changes
- Physical Constraints: No impossible sensor combinations
- Natural Variation: Randomized event timing within plausible bounds
- Example Valid Entry:
2025-06-01T06:30:15,Bedroom2,motion_sensor_bedroom2,1,22.1°C,65%RH

*Invalid Example Warnings*
- ⚠️ Temporal Paradox: Events during known unoccupied periods
- ⚠️ Energy Violation: Impossible power draws (350W from TV alone)
- ⚠️ Sensor Discord: Motion detection but decreasing temperature
- ⚠️ Child Activity Gap: Misses 06:30 wake-up routine

## Generation Task: Functional Family Dataset

### Home Blueprint (Small Urban Residence)
||Rooms||         ||Sensors||                   ||Connections||
|Bedroom1  |motion/temp/light           |↔ LivingRoom
|Bedroom2  |motion/temp/light           |→ Bathroom → ServiceArea → Kitchen
|LivingRoom|motion/temp/TV/light/lock   |↔ Kitchen

### Resident Chronobiology
┌───────────────┬─────────────┬───────────────┐
│ Period        │ Occupants   │ Key Areas     │
├───────────────┼─────────────┼───────────────┤
│ 06:00-06:30   │ Adult1      │ Bed1→Kitchen  │
│ 06:30-07:00   │ Adult1+Child│ Bed2→Kitchen  │
│ 07:00-07:30   │ FullHouse   │ LivingArea    │
│ 09:00-17:00   │ Empty       │ -             │
│ 18:00-22:00   │ FamilyTime  │ Living→Kitchen│
└───────────────┴─────────────┴───────────────┘

### Physical Constraints
① Motion→Temp: +0.8±0.3°C per activation
② Power Surge: 120-280W immediate draw
③ Envelope Integrity: Doors/windows closed 95% of night

Generate realistic CSV data with:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Include:
- Natural time jitter (±2min)
- Environmental drift
- Sensor error margin
- Validate against:
  ▶ No 09:00-17:00 events
  ▶ Bedroom dark 22:00-06:00
  ▶ Logical power sequences
"""),
    AIMessagePromptTemplate.from_template("prompt")
])