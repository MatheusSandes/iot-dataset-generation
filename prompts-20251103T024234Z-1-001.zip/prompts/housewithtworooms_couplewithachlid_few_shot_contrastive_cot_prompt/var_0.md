```python
var_0 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are given two reasoning examples for a smart home scenario with two adults and one child: one correct and one incorrect.
Analyze both to learn what to do and what to avoid.
Then, generate a valid dataset for the final scenario based on similar household conditions.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Example 1 (Correct Chain-of-Thought)

Scenario:
- Adult 1: wakes 06:00, leaves 08:00, returns 17:00, sleeps 22:30  
- Adult 2: wakes 07:00, leaves 09:00, returns 18:00, sleeps 23:00  
- Child: wakes 06:30, leaves for school at 07:30, returns at 17:30, sleeps at 22:00  
- Adults sleep in Bedroom1, child in Bedroom2
- Morning overlap: 06:30–07:30; Evening: 18:00–22:00
- No occupancy between 09:00–17:00, and after 23:00

Reasoning:
Events begin with Adult 1 moving around Bedroom1 and Kitchen.
Child becomes active in Bedroom2 around 06:30, with kitchen use before 07:30.
Adult 2 joins at 07:00.
No events occur during school/work hours.
After 17:00, adults and child trigger motion and power events in the living room and kitchen.
Timestamps vary naturally; sensor logic and correlations are respected.

Output:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status  
2025-06-01T06:00:12,evt_0001,Bedroom1,motion_detected,motion_sensor_bedroom1,21.9,67,1,1,low,110,33,good,closed,closed  
2025-06-01T06:32:44,evt_0002,Bedroom2,motion_detected,motion_sensor_bedroom2,22.2,66,1,1,low,100,34,good,closed,closed  
2025-06-01T06:54:10,evt_0003,Kitchen,power_usage,smart_plug_fridge,,64,,1,medium,230,35,good,closed,closed  
2025-06-01T07:05:23,evt_0004,LivingRoom,power_usage,smart_tv,,63,,1,medium,270,36,good,closed,closed  
2025-06-01T07:28:01,evt_0005,LivingRoom,motion_detected,motion_sensor_living,22.7,62,1,1,medium,0,34,good,closed,closed ← false positive

---

Example 2 (Incorrect Chain-of-Thought)

Scenario:
Same home and family.

Faulty Reasoning:
Events are rigidly spaced (every 2 minutes). Motion detected during school/work hours.
Power usage too high. Temperature drops during motion.
No child activity prior to 07:30.
False sensor combinations.

Mistakes:
- Ignored child wake-up at 06:30
- Inverted correlations (e.g., motion     temperature)
- Unrealistically high power for smart plug
- Events continue during 10:00, despite no occupancy

Output:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status  
2025-06-01T10:00:00,evt_0007,LivingRoom,motion_detected,motion_sensor_living,24.5,55,1,1,high,360,33,good,closed,closed  
2025-06-01T10:02:00,evt_0008,Kitchen,temperature_reading,temp_sensor_kitchen,23.6,58,,1,medium,200,33,good,closed,closed  
2025-06-01T10:04:00,evt_0009,LivingRoom,power_usage,smart_tv,,59,,1,high,350,33,good,closed,closed  

---

Now generate a correct dataset for the following scenario:

Scenario Configuration

- House Type: Small urban smart home with two bedrooms

- Devices by Room:

  • Bedroom1 (3m x 3m):
    - motion_sensor_bedroom1
    - temp_sensor_bedroom1
    - smart_light_bedroom1

  • Bedroom2 (3m x 3m):
    - motion_sensor_bedroom2
    - temp_sensor_bedroom2
    - smart_light_bedroom2

  • LivingRoom (3m x 3m):
    - motion_sensor_living
    - temp_sensor_living
    - smart_tv
    - smart_light_living
    - smart_lock_front

  • Kitchen (1.8m x 1.2m):
    - temp_sensor_kitchen
    - smart_light_kitchen
    - smart_plug_fridge

  • ServiceArea:
    - motion_sensor_service
    - temp_sensor_service

  • Bathroom (2m x 1.2m): no sensors

- Room Connections:
  - Bedroom1   LivingRoom
  - Bedroom2   Bathroom
  - Bathroom   ServiceArea   Kitchen
  - LivingRoom   Kitchen

- Residents:
  • Adult 1: wakes 06:00, leaves 08:00, returns 17:00, sleeps 22:30  
  • Adult 2: wakes 07:00, leaves 09:00, returns 18:00, sleeps 23:00  
  • Child: wakes 06:30, leaves 07:30, returns 17:30, sleeps 22:00  
  • Adults sleep in Bedroom1, child in Bedroom2

Behavioral Timeline:
- 06:00–06:30   Adult 1 only  
- 06:30–07:00   Adult 1 + Child  
- 07:00–07:30   All 3 active  
- 07:30–08:00   Adults 1 and 2  
- 08:00–09:00   Adult 2 only  
- 09:00–17:00   house empty  
- 17:00–17:30   Adult 1 only  
- 17:30–18:00   Adult 1 + Child  
- 18:00–22:00   all three  
- 22:00–22:30   Adults only  
- 22:30–23:00   Adult 2 only  
- 23:00–06:00   all asleep

Technical Requirements:

- Motion     Temperature (0.5–1.5°C in 15–30 min)  
- Motion     Power (100–300W instantly)  
- Temperature   Humidity: correlation -0.7 to -0.9  
- Add noise:
  - Temperature 'b10.1°C
  - Power 'b11%
  - Motion FP: 0.1–0.3%
- Avoid any activity during:
  • 09:00–17:00 (no one home)  
  • 23:00–06:00 (everyone asleep)

Output Format:

Start with this header:  
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Then generate a full CSV dataset for this family'92s daily routine.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])
```