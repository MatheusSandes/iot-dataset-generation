var_9 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You're analyzing home automation data patterns for a family residence.
Study these contrasting examples of home activity logging - one properly structured and one flawed.
Then create an accurate event dataset matching the given family's schedule and smart home configuration.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Model Example Analysis

Good Execution:
- Resident movements match wake/sleep schedules precisely
- Sensor events correlate properly (motion → temp/power changes)
- Realistic timestamps with natural variance
- Correct handling of empty home periods
- Appropriate environmental parameter correlations

Poor Execution:
- Events during unoccupied times
- Unrealistic perfect time intervals
- Sensor readings contradict physical reality
- Missing expected child activity patterns
- Illogical energy consumption spikes

Current Scenario Parameters:

Resident Schedule:
• Parent A: 06:00-08:00 | 17:00-22:30
• Parent B: 07:00-09:00 | 18:00-23:00
• Child: 06:30-07:30 | 17:30-22:00
Empty House: 09:00-17:00
Sleep Time: 23:00-06:00

Smart Home Layout:
[Bedroom1]--[Living]--[Kitchen]--[Service]
      |               |
   [Bedroom2]--[Bathroom]

Device Mapping:
• Motion: All rooms except bath
• Temp: All except bath
• Smart Plugs: fridge/TV
• Lights: All living spaces

Physical Rules:
1. Motion → +0.8±0.3°C over 20±5min
2. Active devices → 120-280W instant draw
3. Temp-Humidity: 65% @22°C → 60% @23°C
4. Allowable noise:
   - Temp: ±0.1°C
   - Power: ±12W
   - Motion: 0.2% false positives

Generation Requirements:
- Timeline must respect resident presence
- Maintain all physical correlations
- Include realistic timing variations
- Header format below must be used

CSV Header:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Produce a complete day's dataset following all guidelines.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])