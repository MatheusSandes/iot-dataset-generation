var_1 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
As an AI Specialist with deep understanding of IoT ecosystems and human behavioral patterns, create a dynamic smart home dataset that reflects the complex interactions between devices, residents, and environmental factors.
Generate authentic synthetic data that maintains physical/logical consistency while incorporating realistic variations in timing, sensor noise, and device interdependencies.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Simulation Parameters

▪ Property Configuration:
  - Dwelling Type: Compact urban apartment
  - Climate Zone: Subtropical winter (Brazilian June conditions)
  - Thermal Profile: 21–26°C dynamic range

▪ Device Deployment Matrix:

  • Lounge Area [3×3m]:
    - Presence detection: motion_sensor_living
    - Entertainment: smart_tv
    - Illumination: smart_light_living
    - Climate monitoring: temp_sensor_living
    - Access control: smart_lock_front

  • Sleeping Quarters [3×3m]:
    - Occupancy sensor: motion_sensor_bedroom
    - Lighting: smart_light_bedroom
    - Thermal sensor: temp_sensor_bedroom

  • Food Preparation Zone [1.8×1.2m]:
    - Appliance: smart_plug_fridge
    - Lighting: smart_light_kitchen
    - Temperature: temp_sensor_kitchen

▪ Spatial Relationships:
  Bedroom ⇄ Living Room ⇄ (Kitchen + Bathroom)

▪ Occupant Profiles (Divergent Rhythms):

  ☑ Primary Resident:
    - Awake: 06:00–22:30
    - Absence Window: 08:00–17:00

  ☑ Secondary Resident:
    - Awake: 07:00–23:00
    - Absence Window: 09:00–18:00

Physical Constraints & Correlations:

① Sensor Interdependencies:
   - Motion → Thermal: 0.5–1.5°C delta (15–30min lag)
   - Activity → Power Draw: 100–300W instantaneous
   - Thermal-Hygrometric: -0.7 to -0.9 coeff.

② Real-World Variability:
   - Sensor error margins:
     • Temperature: ±0.1°C
     • Power: ±1%
   - Ghost detections: 0.1–0.3% probability

③ Temporal Bounds:
   - Sleep Phase: 23:00–06:00 (zero activity)
   - Vacant Period: 09:00–17:00 (baseline state)
   - Event timing must show natural jitter

Required Output Schema:

timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Generate the complete IoT event stream adhering to these specifications.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])