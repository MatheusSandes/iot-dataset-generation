var_8 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
As an expert in synthetic IoT data generation with specialization in residential behavior patterns, you're tasked with creating a hyper-realistic dataset that faithfully represents the daily activities of two residents in a smart home environment. Your creation must incorporate nuanced device interactions, subtle temporal variations, and realistic sensor correlations while strictly adhering to the physical constraints of the space.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Simulation Blueprint

✧ Property Specifications:
- Dwelling: Compact urban apartment (42m² total)
- Time Period: Mid-winter (Southern Hemisphere)
- Climate Controls: 21-26°C indoor range, 40-70% humidity

✧ Sensor Network Deployment:
  
  ≡ Living Area (9m²) ≡
  • Motion detection (PIR_L1)
  • Entertainment system (TV_L1)
  • Ambient lighting (LED_L1)
  • Environmental monitoring (TEMP_L1)
  • Entry security (LOCK_MAIN)

  ≡ Sleeping Quarters (9m²) ≡
  • Presence detection (PIR_B1)
  • Mood lighting (LED_B1)
  • Climate sensor (TEMP_B1)

  ≡ Food Preparation Area (2.16m²) ≡
  • Temperature probe (TEMP_K1)
  • Task lighting (LED_K1)
  • Appliance control (PLC_FRIDGE)

✷ Resident Behavior Profiles

Resident Alpha:
☀️ 06:00 - Awakening
🚪 08:00 - Departure
🏠 17:00 - Return
😴 22:30 - Retiring

Resident Beta:
☀️ 07:00 - Awakening
🚪 09:00 - Departure
🏠 18:00 - Return
😴 23:00 - Retiring

Technical Requirements Matrix

▣ Device Interactions:
- Motion → Temperature (+0.5-1.5°C with 15-30min lag)
- Activity → Power draw (100-300W spike)
- Temp/Humidity: R² ≈ -0.8

▣ Environmental Variables:
- Thermal noise: ±0.1°C
- Power variance: ±1% baseline
- False motion: 0.1-0.3% of events

▣ Temporal Constraints:
■ 23:00-06:00: Dormant period
■ 09:00-17:00: Unoccupied state (except anomalies)
■ Event timing: Poisson-distributed intervals

Data Output Specification

Required header (exact):
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Generate the synthetic dataset demonstrating realistic home automation patterns.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])