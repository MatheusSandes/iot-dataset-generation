var_6 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
As a Principal IoT Data Scientist specializing in digital twin simulations, you're tasked with creating a highly realistic synthetic dataset for a smart home environment.
Leverage your deep knowledge of behavioral patterns, device interoperability, and environmental physics to generate data that mimics real-world dynamics with precision.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Simulation Blueprint

### Architectural Layout
- Property Classification: Compact city apartment (45m² total)
- Floor Plan:
  • Main Suite (3.5m x 3m)
    - Primary motion detector (motion_main)
    - Ambient lighting (light_main)
    - Climate monitor (temp_main)
    - Security deadbolt (lock_primary)
  
  • Leisure Zone (3.2m x 2.8m)
    - Entertainment system (tv_entertainment)
    - Presence detector (motion_leisure)
    - Illumination control (light_leisure)
    - Thermal sensor (temp_leisure)

  • Culinary Area (2m x 1.5m)
    - Appliance monitor (plug_refrigerator)
    - Task lighting (light_kitchen)
    - Heat gauge (temp_kitchen)

- Spatial Relationships:
  Main Suite ↔ Leisure Zone ↔ Culinary Area

### Occupant Profiles
Two working professionals with distinct circadian rhythms:

• Early Riser (ER)
  - 05:45: Awakening sequence begins
  - 07:30: Departure
  - 16:45: Evening return
  - 22:00: Sleep preparation

• Night Owl (NO)
  - 07:15: Morning routine
  - 09:00: Leaves premises
  - 18:30: Homecoming
  - 23:30: Sleep initiation

### Environmental Context
- Geographical Setting: Southern Hemisphere winter
- Thermal Dynamics:
  - Base temp: 20°C (unoccupied)
  - Active temp delta: +2–5°C
  - Humidity compensation: 1.8% decrease per °C rise
- Power Characteristics:
  - Idle consumption: 50–80W
  - Active spikes: 150–400W
  - TV power curve: 120W (idle), 250W (active)

### Physical Constraints
- Event Probabilities:
  - False motion triggers: ≤0.25% likelihood
  - Device error margin: ±1.2%
- Temporal Rules:
  - Absolute quiet hours: 23:45–05:30
  - Minimum motion interval: 38±12s
  - Maximum continuous activity: 93±25min

Required Output Format

Begin with this precise header (include all fields exactly as shown):
timestamp,event_id,zone,event_class,sensor_origin,temp_c,humidity_pct,motion_state,occupancy_count,illumination_status,energy_usage_db,acoustic_level,air_index,entry_status,portal_condition

Generate the comprehensive dataset adhering to these specifications.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])