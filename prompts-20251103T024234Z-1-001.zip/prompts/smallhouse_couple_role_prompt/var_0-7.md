var_7 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
As an experienced IoT Design Engineer specializing in occupancy modeling, you're tasked with crafting a lifelike synthetic dataset for a smart home.
Develop realistic device interactions between two resident personas with distinct daily patterns, maintaining all physical and temporal relationships.
Weight measurements carefully considering winter conditions in a subtropical climate.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Blueprint

- Property Dimensions: Compact urban dwelling

- Installed Per Room:

  ■ Main Chamber (9m²):
    • Occupancy tracker (motion_main)
    • Entertainment System (tv_entertain)
    • Adaptive Lighting (light_main)
    • Thermal Node (temp_main)
    • Entry Controller (lock_frontdoor)

  ■ Sleeping Quarters (9m²):
    • Presence Indicator (motion_bed)
    • Mood Lighting (light_bed)
    • Heat Monitor (temp_bed)

  ■ Culinary Zone (2.16m²):
    • Thermal Probe (temp_kitchen)
    • Task Illumination (light_kitchen)
    • Appliance Regulator (plug_refrigerator)

  ■ Hygiene Area (2.4m²): Uninstrumented

- Area Connectivity:
  Sleeping Quarters ↔ Main Chamber
  Main Chamber ↔ Culinary Zone
  Main Chamber ↔ Hygiene Area

- Occupancy Profiles:

  ○ Person Alpha:
    - Rise: 06:00
    - Depart: 08:00
    - Arrival: 17:00
    - Retire: 22:30

  ○ Person Beta:
    - Rise: 07:00
    - Depart: 09:00
    - Arrival: 18:00
    - Retire: 23:00

- Environmental Factors:
  - Period: Winter (Tropical)
  - Thermal Range: 21–26°C activity-dependent
  - Moisture: 40–70%, negative relationship

Technical Parameters

- Interdependencies:
  - Movement → Temperature Shift (0.5–1.5°C over 15–30mins)
  - Movement → Power Surge (150–350W instantly)
  - Heat → Dew Point: Inverse link (-0.65 to -0.95)

- Measurement Variation:
  - Temperature: ±0.15°C
  - Energy: ±9W
  - Ghost Triggers: ≤0.25% occurrence

- Temporal Logic:
  - Silent Period: 23:30–05:45 (both inactive)
  - Vacant Hours: 09:15–16:45 — equipment standby except anomalies
  - Event timing must exhibit organic variability

Required Output Structure

Initiate with this precise header:
timestamp,event_id,zone,event_class,actuator,heat_index,moisture,activity,presence,illumination,energy_draw,acoustic_level,atmosphere_status,entry_state,egress_state

Then generate the corresponding equipment measurements in CSV format.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])