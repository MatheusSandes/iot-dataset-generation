```python
var_0 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a Senior IoT Data Engineer with expertise in behavioral modeling and smart home simulation.
Your task is to generate a synthetic but realistic IoT dataset based on the configuration of the house below, simulating two residents with different routines.
Follow the technical constraints and ensure natural behavior patterns, correct device usage, realistic event timing, and correlation between sensors.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Scenario Configuration

- House Type: Small urban smart home

- Devices by Room:

  • Living Room (3m x 3m):
    - 1x Motion sensor (motion_sensor_living)
    - 1x Smart TV (smart_tv)
    - 1x Smart light bulb (smart_light_living)
    - 1x Temperature sensor (temp_sensor_living)
    - 1x Smart lock (smart_lock_front)

  • Bedroom (3m x 3m):
    - 1x Motion sensor (motion_sensor_bedroom)
    - 1x Smart light bulb (smart_light_bedroom)
    - 1x Temperature sensor (temp_sensor_bedroom)

  • Kitchen (1.8m x 1.2m):
    - 1x Temperature sensor (temp_sensor_kitchen)
    - 1x Smart light bulb (smart_light_kitchen)
    - 1x Smart plug (smart_plug_fridge)

  • Bathroom (2m x 1.2m): no sensors

- Room Connections:
  - Bedroom   Living Room
  - Living Room   Kitchen and Bathroom

- Residents: Two adults with different routines

  • Resident 1:
    - Wakes up at 06:00
    - Leaves home at 08:00
    - Returns at 17:00
    - Goes to sleep at 22:30

  • Resident 2:
    - Wakes up at 07:00
    - Leaves home at 09:00
    - Returns at 18:00
    - Goes to sleep at 23:00

- Environment:
  - Season: Winter (Brazil, June)
  - Indoor temperature range: 21–26°C depending on activity
  - Humidity: 40–70%, inversely correlated

Technical Specifications

- Correlations:
  - Motion     Temperature (0.5–1.5°C within 15–30min)
  - Motion     Power (100–300W immediately)
  - Temperature   Humidity: correlation -0.7 to -0.9

- Realistic noise:
  - Temperature: 'b10.1°C
  - Power: 'b11%
  - Motion false positives: 0.1–0.3%

- Time-based constraints:
  - No events between 23:00 and 06:00 (both asleep)
  - From 09:00 to 17:00 the house is empty — no motion or activity, except rare false positives
  - Timestamps should vary naturally (not fixed intervals)

Output Format

Start your response with this exact header:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Then provide the generated CSV dataset based on the scenario above.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])
```