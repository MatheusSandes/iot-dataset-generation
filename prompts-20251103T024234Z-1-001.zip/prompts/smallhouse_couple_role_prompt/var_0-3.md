var_3 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
As an expert IoT data simulator specializing in residential behavioral patterns, you'll create a highly realistic smart home dataset with precise device interactions and occupant behaviors.
Model all sensor readings with appropriate physical relationships while maintaining natural variance in event timing and intensity.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Simulation Parameters

Dwelling Specifications:
- Architecture: Compact urban apartment (65m² total)
- Thermal Profile: Winter conditions in São Paulo (June)

Device Network:

⌖ Living Space (9m²):
  • Occupancy: motion_sensor_living
  • Entertainment: smart_tv (200-400W)
  • Illumination: smart_light_living (0-100%)
  • Climate: temp_sensor_living + hum_sensor_living
  • Security: smart_lock_front

⌖ Sleeping Quarters (9m²):
  • Occupancy: motion_sensor_bedroom
  • Lighting: smart_light_bedroom
  • Environment: temp_sensor_bedroom

⌖ Food Prep Zone (2.16m²):
  • Appliance: smart_plug_fridge (150W base + spikes)
  • Ambient: temp_sensor_kitchen
  • Lighting: smart_light_kitchen

Resident Behavioral Models:

👤 Primary Occupant (Early Riser):
- Active phases: 06:00-08:00 | 17:00-22:30
- Behavior profile: Morning exercise, evening TV

👤 Secondary Occupant (Night Owl):
- Active phases: 07:00-09:00 | 18:00-23:00
- Behavior profile: Morning coffee ritual, late reading

Environmental Dynamics:
- Temperature modulation: 
  • Base: 21°C (sleeping)
  • Active: +1°C per occupant
  • Appliance heat: +0.5-2°C local
- Humidity: 50% baseline with inverse thermal response
- Motion artifacts: 0.2% random activation probability

Physical Relationships:
1. Motion → Power (300ms delay, 150-500W draw)
2. Occupancy → Temperature (τ=20min, ΔT≈1.2°C)
3. Device usage → Local heat (Q=0.8×Pwr)

Data Generation Requirements:
- Minimum sampling: 30s during active periods
- Quiescent periods: 5min sampling
- Natural jitter: ±90s in event timing
- Sensor noise: Gaussian (σ=0.25 for analog)

Output Specification

Required CSV header (exact copy):
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Generate continuous 24-hour dataset beginning at 00:00:00.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])