var_4 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
As a Principal IoT Data Architect specializing in habitation analytics, you're tasked with crafting a sophisticated synthetic dataset that mirrors real-world smart home dynamics.
Generate sensor readings and device interactions for two occupants with divergent schedules in a compact urban dwelling, ensuring:
- Biometric plausibility in movement patterns
- Thermo-regulatory co-dependencies
- Power consumption profiles matching regional standards
- Chronobiological consistency in daily rhythms
"""),
    HumanMessagePromptTemplate.from_template(r"""
Dwelling Blueprint & Operational Parameters

|| Residential Specifications ||
▪︎ Property Class: Compact smart-enabled urban unit (27m² total)
▪︎ Geographic Context: Southern hemisphere winter conditions

|| Spatial Configuration ||
» Primary Chamber (3×3m):
  ✓ PIR-10 motion array (zone_alpha_motion)
  ✓ LUX-200 ambient controller (zone_alpha_light)
  ✓ TMP-H7 thermal node (zone_alpha_temp)
  ✓ SEC-001 entry terminal (main_access_point)
  ✓ ENT-5D media unit

» Resting Quarter (3×3m):
  ✓ PIR-10 motion array (zone_beta_motion)
  ✓ LUX-200 ambient controller (zone_beta_light)
  ✓ TMP-H7 thermal node (zone_beta_temp)

» Culinary Sector (1.8×1.2m):
  ✓ TMP-H7 thermal node (zone_gamma_temp)
  ✓ LUX-200 ambient controller (zone_gamma_light)
  ✓ PWR-40 appliance module (cold_storage_unit)

» Hygiene Facility: Uninstrumented (2×1.2m)

|| Occupancy Patterns ||
Primary Tenant (P1):
☀ Dawn phase: 05:45–06:15
🚪 Egress: 07:45–08:15
🌙 Dormancy onset: 22:15–22:45

Secondary Tenant (P2):
☀ Dawn phase: 06:45–07:15
🚪 Egress: 08:45–09:15
🌙 Dormancy onset: 22:45–23:15

|| Environmental Constraints ||
▷ Thermal envelope: 20.8–26.2°C (Δ±0.3°C)
▷ Hydration baseline: 38–72% RH (inverse thermal coupling)
▷ Seasonality: Austral winter emulation
▷ Power variance thresholds:
   • Illumination: 8–12W (LED)
   • Media: 80–120W (active state)
   • Climate: 600–900W (peaks)

|| Data Integrity Requirements ||
◈ Chronological dispersion: ±4–9min variability
◈ Sensor error margins:
   - Thermal: σ≤0.12°C
   - Presence: ≤0.25% false triggers
   - Power: ±1.25% metering error
◈ Cross-modal dependencies:
   - Motion→Thermal (0.4–1.6°C Δ in 12–33min)
   - Luminary activation→Power (85–315W instant)
   - Thermal-Hygrometric: r = -0.68 to -0.92

Data Schema Specification

Initiate transmission with this precise header sequence:
timestamp,event_id,zone_id,event_class,actuator_node,temperature,humidity,motion_state,occupancy_count,illuminance,power_draw,acoustic_index,particulate_level,portal_status,aperture_state

Generate the corresponding multivariate time-series dataset.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])