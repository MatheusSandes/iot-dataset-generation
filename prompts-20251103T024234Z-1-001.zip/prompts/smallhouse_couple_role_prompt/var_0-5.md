var_5 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a Senior IoT Data Scientist specializing in generating hyper-realistic smart home behavioral datasets.
Your mission is to create synthetic IoT data that mimics actual device interactions between two residents with distinct daily patterns.
Incorporate subtle device correlations, environmental impacts, and realistic anomalies to create a dataset for ML model training.
"""),
    HumanMessagePromptTemplate.from_template(r"""
DATASET GENERATION REQUIREMENTS

SMART HOME SCHEMA:

- PROPERTY: Compact urban apartment (42m² total)
- CLIMATE ZONE: Tropical winter conditions (Brazil, June)

DEVICE MAPPING:

+ LIVING AREA (3×3m):
  ✓ Presence detector (living_motion)
  ✓ Entertainment system (tv_power)
  ✓ RGB Smart bulb (living_light)
  ✓ Climate sensor (living_thermo) = Temp+Humidity
  ✓ Digital entrance lock (main_door)

+ SLEEPING QUARTER (3×3m):
  ✓ Sleep tracker (bed_motion)
  ✓ Dimmable lamp (bed_light)
  ✓ Microclimate sensor (bed_thermo)

+ KITCHENETTE (1.8×1.2m):
  ✓ Refrigerator monitor (fridge_plug)
  ✓ Task lighting (kitchen_light)
  ✓ Ambient sensor (kitchen_thermo)

INTERCONNECTION TOPOLOGY:
Bedroom ←→ Living Area ←→ (Kitchen + Bathroom)

RESIDENT PROFILES:

▷ PersonA (Early Riser):
- 05:50-07:30 Morning routine
- 07:30-17:00 Away period
- 22:15 Sleep transition

▷ PersonB (Night Owl):
- 06:45-07:40 Prep time
- 07:40-18:15 Absent hours
- 22:45-23:15 Wind down

COUPLED PHENOMENA:

→ Human presence causes:
   ■ Thermal drift: +0.7-2.0°C per active hour
   ■ Humidity drop: 5-15% per occupancy period
   ■ Power surge patterns

→ Environmental baselines:
   ■ Winter temp bands: 20.5-25.9°C
   ■ Humidity inversion: -45 to -75 correlation
   ■ Appliance power signatures

DATA FIDELITY CONSTRAINTS:

◉ Sampling realism:
   - ±250ms timestamp jitter
   - 0.2% sensor misreads
   - 150-600W appliance modulation

◉ Temporal patterns:
   - 30-45min activity clusters
   - Midnight-05:50 quiescent period
   - 08:00-16:30 minimal triggers

REQUIRED OUTPUT STRUCTURE:

'''CSV
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status
'''

Generate continuous 24-hour IoT telemetry that strictly follows the above specification.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])