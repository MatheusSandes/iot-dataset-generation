
var_4 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Generate multiple realistic IoT data simulations for a smart family home ecosystem.
Apply triple-layer validation (pattern consistency, environmental physics, behavioral plausibility)
and subject comparison via cross-verification matrices.
After full evaluation cycle, export ONLY the top-ranked dataset without commentary.
Omit all interim versions and selection processes completely.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Home Configuration Matrix

| Space            | Dimensions | Device Array                      | Thermal Profile |
|------------------|------------|-----------------------------------|-----------------|
| Master Bedroom   | 3m³        | Motion/Temp/Lighting Cluster      | 18-21°C Cyclic  |
| Child Room       | 3m³        | Presence/Climate Control Unit     | 19-22°C Gradient|
| Living Hub       | 3m³        | 5-Channel Environmental Suite     | 20-23°C Dynamic |
| Kitchen Zone     | 2.16m²     | Appliance Energy Monitor          | 17-25°C Spiked  |
| Utility Area     | -          | Background Monitoring Pod         | Stable Baseline |

Resident Activity Matrix

| Person  | Routine Pattern                         | Movement Vector        |
|---------|----------------------------------------|------------------------|
| ParentA | Early riser: 06:00-20:30 cycle         | Bed→Bath→Kitchen→Exit |
| ParentB | Standard schedule: 07:00-23:00 rhythm  | Bed→Living→Work Loop  |
| Child   | School rhythm: 06:30-22:00 cadence     | Bed→Bath→Exit Pattern |

Temporal Constraints Diagram

```timeline
06:00-06:30   Solitary ParentA protocol
06:30-07:30   Dual/Multi person convergence
07:30-08:30   Departure sequence
08:30-12:00   Structure lockdown
12:00-17:00   System standby
17:00-20:30   Reoccupation wave
20:30-23:00   Evening relaxation mode
23:00-06:00   Deep sleep phase
```

Technical Parameters Field

- Thermal Dynamics: ±0.7°C per 900s
195W power offset]]

Signal Fidelity Requirements:
- Climate sensors: ±b9.5°C factual
- Energy monitors: b8% voltage wobble
- Occupancy arrays: 0.2% ghost signals

Output Schema:
time_ID,event_hash,zone_ID,sensor_type,primary_driver,T_value,H_value,motion_vector,presence_map,light_index,power_vector,sound_profile,air_ID,access_state

Deliver only the gold-standard dataset post-quantum validation.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])