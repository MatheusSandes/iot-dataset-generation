
var_1 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Simulate and evaluate multiple potential IoT data streams reflecting a typical day in the specified smart home environment. 
Generate at least three distinct datasets, critically assess them for:
- Temporal coherence
- Device interaction plausibility
- Behavioral pattern alignment
After thorough evaluation, return only the single most convincing dataset without commentary.
"""),

    HumanMessagePromptTemplate.from_template(r"""
Dwelling Configuration

- Residence Type: Compact city apartment (smart-enabled)

- Device Deployment:

  • Master Bedroom (3×3m):
    * occupancy_detector_main
    * thermal_sensor_main
    * adaptive_lighting_main

  • Child's Room (3×3m):
    * occupancy_detector_child
    * thermal_sensor_child
    * adaptive_lighting_child

  • Common Area (3×3m):
    * presence_detector_living
    * climate_sensor_living
    * entertainment_system
    * ambient_lighting
    * entry_lock

  • Food Prep Zone (1.8×1.2m):
    * climate_sensor_kitchen
    * task_lighting
    * appliance_monitor_fridge

  • Utility Space:
    * motion_detector_utility
    * thermal_sensor_utility

  • Hygiene Room (2×1.2m): unsensored

- Spatial Connectivity:
  Master Bedroom ↔ Common Area
  Child's Room ↔ Hygiene Room
  Hygiene Room ↔ Utility Space ↔ Food Prep Zone
  Common Area ↔ Food Prep Zone

- Occupants:
  • Parent A: awake 06:00–22:30, away 08:00–17:00
  • Parent B: awake 07:00–23:00, away 09:00–18:00
  • Youth: awake 06:30–22:00, away 07:30–17:30
  • Sleeping arrangements: Parents in Master Bedroom, child in Child's Room

Daily Routine Mapping:
06:00–06:30   Solo Parent A activity
06:30–07:00   Parent A + child morning routine
07:00–07:30   Full family preparation
07:30–08:00   Parent pair coordination
08:00–09:00   Remaining parent departure
09:00–17:00   Unoccupied dwelling
17:00–17:30   First parent return
17:30–18:00   Child return + parent supervision
18:00–22:00   Family evening activities
22:00–22:30   Child bedtime transition
22:30–23:00   Final parent retires
23:00–06:00   Sleep period

Technical Parameters:

- Motion → Thermal dynamics: 0.5–1.5°C fluctuation every 15–30 min
- Presence → Energy spike: 100–300W instantaneous
- Thermal-Humidity relationship: inverse correlation (-0.7 to -0.9)
- Realistic noise integration:
  * Temperature: ±0.1°C variation
  * Power: ±11% fluctuation
  * False motion positives: 0.1–0.3% rate

Inactive Periods (must show no activity):
09:00–17:00 (weekday absence)
23:00–06:00 (sleep cycle)

Required Output Structure:

Begin with this exact header row:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Then provide only your single highest-quality dataset selection.
"""),

    AIMessagePromptTemplate.from_template("prompt")
])