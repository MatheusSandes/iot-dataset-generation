
var_3 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Synthesize multiple plausible IoT sensor datasets reflecting daily patterns in a compact smart home environment.
Execute an internal evaluation process focusing on:
1. Temporal consistency across all sensor types
2. Realistic device interaction patterns
3. Natural behavioral variance within established routines
After thorough analysis, output exclusively the top-ranked dataset that best simulates authentic household activity.
Omit all evaluation metrics and alternative versions.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Residential Simulation Parameters

Dwelling Profile:
- Urban apartment (65m² total) with open-plan layout
- Occupants: 2 working adults + 1 school-aged child

Device Network Specification:

• Master Bedroom (3.2m x 3.2m):
  - presence_detector_master
  - climate_monitor_master (temp/humidity)
  - dimmable_luminaires_master

• Child's Room (3m x 2.8m):
  - occupancy_scanner_child
  - thermal_sensor_child
  - smart_illumination_child

• Common Areas:
  - Living Space (4m x 3.5m):
    * activity_tracker_living
    * environmental_sensor_living
    * entertainment_system
    * adaptive_lighting_living
    * entryway_security

  - Kitchen Zone (2m x 1.5m):
    * heat_mapper_kitchen
    * task_lighting_kitchen
    * appliance_energy_monitor

  - Utility Area:
    * motion_analyzer_service
    * conditions_monitor_service

Resident Patterns:

Primary Occupants:
- Adult A: Rise 05:45 | Depart 07:30 | Return 16:45 | Retire 22:15
- Adult B: Rise 06:30 | Depart 08:15 | Return 17:30 | Retire 22:45
- Juvenile: Rise 06:00 | Depart 07:15 | Return 15:45 | Retire 21:30

Activity Phases:
05:45-06:00   Solo Adult A
06:00-06:30   Adult A + Child
06:30-07:15   Full household
07:15-07:30   Adult pairing
07:30-08:15   Solo Adult B
08:15-15:45   Unoccupied
15:45-17:30   Partial occupancy
17:30-21:30   Full household
21:30-22:15   Adult pairing
22:15-22:45   Solo Adult B
22:45-05:45   Sleep period

Technical Specifications:

Sensor Correlations:
- Movement → Power draw (instant 100-400W)
- Temperature → Humidity (inverse relationship)
- Environmental noise:
  ±1.2°C thermal fluctuation
  5-15% sensor reading variation
  0.05-0.25% false positive motion

Restricted Timeframes:
- 08:15-15:45 (unoccupied)
- 22:45-05:45 (sleep cycle)

Required Output Structure:

Begin with this exact header row:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Follow with the single most coherent dataset without commentary.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])