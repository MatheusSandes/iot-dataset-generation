
var_6 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Develop three distinct simulated IoT datasets representing a typical week in an urban family home with two working parents and a school-age child.
Apply stringent quality checks for realism, temporal consistency, and device interaction patterns.
After rigorous internal evaluation, present only the optimal dataset that best matches natural human behavior patterns.
Omit all development traces and selection rationale in the final output.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Residence Configuration

- Property: Compact smart apartment (65 sqm total)
- Floor Plan:

  • Master Bedroom (3.2m x 2.8m):
    - occupancy_sensor_parents
    - climate_node_parents (temp/humidity)
    - dimmable_light_nightstand
    - smart_blinds

  • Child's Room (2.9m x 2.6m):
    - motion_detector_kid
    - wall_thermostat_child
    - rgb_light_ceiling

  • Common Areas:
    -- Living Space (4m x 3.5m):
       - presence_sensor_central
       - entertainment_system_controller
       - ambient_light_sensor
       - door_contact_front
       - air_quality_monitor
    
    -- Kitchen Nook (2.4m x 2m):
       - appliance_energy_monitor
       - undercabinet_lighting
       - refrigerator_thermostat

    -- Utility Zone:
       - washing_machine_sensor
       - water_heater_node

- Connectivity Map:
  Master → Living ↔ Kitchen ↔ Utility
  Child's → Bathroom → Living

- Household Members:
  • Parent1: Rise 05:45 | Depart 07:15 | Return 18:30 | Retire 22:45
  • Parent2: Rise 06:15 | Depart 08:00 | Return 19:15 | Retire 23:15
  • Schoolchild: Rise 06:30 | Depart 07:45 | Return 16:45 | Bedtime 21:30

Daily Patterns:
05:45-06:15   Parent1 solo
06:15-06:30   Parents only
06:30-07:15   Parents+Child
07:15-07:45   Parent2+Child
07:45-08:00   Parent2 only
08:00-16:45   Unoccupied
16:45-18:30   Child only
18:30-19:15   Child+Parent1
19:15-21:30   Full household
21:30-22:45   Parents only
22:45-23:15   Parent2 only
23:15-05:45   Sleep period

Technical Parameters:

- Sensor Thresholds:
  Motion → Power: 120-350W spike on activation
  Climate: 
    Temp Δ 0.3-0.8°C per 10-20min 
    RH correlation coefficient -0.68 to -0.92
  Error Margin:
    Temp ±0.2°C
    Power ±1.3%
    False positives: motion 0.15-0.25%

Quiet Hours:
08:00-16:45 (weekdays, school/work)
23:15-05:45 (sleeping, all)

Required Output Structure:

Begin with precisely this CSV header:
timestamp,event_id,zone,event_category,source_node,temp_C,humidity_pct,motion_state,occupant_count,illumination,power_W,sound_db,aqi,entry_status,window_position

Include only the perfected dataset after quality vetting.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])