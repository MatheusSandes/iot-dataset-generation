var_8 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Synthesize multiple sets of realistic IoT data sequences simulating daily family life in a smart home environment.
Apply rigor in filtering to select only the most plausible version that demonstrates:
1) Natural human movement patterns
2) Physically consistent sensor readings 
3) Logical sequencing of device activations
Eliminate drafts and comparative analysis - provide only the single most coherent dataset.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Home Configuration Blueprint

Residence Profile:
- Compact two-bedroom urban dwelling with smart automation
- Square footage distribution:
  * Master Bedroom: 9m²
  * Child's Room: 9m²  
  * Living Area: 12m²
  * Cooking Zone: 2.16m²
  * Utility Space: installed sensors only

Sensor Network Layout:

▶ Sleep Chambers:
  - Master (Infrared)
    » Presence_MS
    » Climate_MS (temp/humidity)
    » Lighting_MS
  - Child's (Passive)
    » Motion_CR
    » Thermo_CR

▶ Common Areas:
  - Lounge (Multi-sensor)
    » Activity_LA
    » Climate_LA  
    » Visual_LA  
    » Security_LA
    » Entertainment_LA
  - Meal Prep (Hydrometer)
    » Heat_MP
    » Lumens_MP
    » Appliance_MP

Passage Sequence:
Master ↔ Lounge
Child's ↔ Lavatory ↔ Utility
Lounge ↔ Food Prep

Resident Chronobiology:

▨ Morning Phase
26:00|10 Early Riser: Master wakes
26:30|10 Student awakens  
27:00|10 Second adult rises
27:30|10 Youngster departs  
28:00|10 First commuter leaves
29:00|10 Final exit

▨ Evening Phase
35:00|10 First return  
35:30|10 Child re-enters
36:00|10 Last homecoming
38:00|10 Youth retires
38:30|10 First to sleep
39:00|10 Household quiet

Simulation Imperatives:

■ Physics Boundary Conditions:
→ Thermal response: 0.8°C/30±7 min
→ Load impact: 250±75W instantaneous
→ Environmental correlation: RH drops 15-20% per °C rise
→ Calibration variance:
  Temp ±0.3°C                    
  Consumption ±8% 

■ Statistical Artifacts:
⇝ Ghost triggers: £340%
⇝ Thermal jitter: £340.5°C

Output Specification:

Initiate with metadata:
timestamp,event_tag,zone,action_class,theostat_X,temp_C,rel_humidity%,activity_bit,resident_count,lux_reading,wattage,db_level,ppm_reading,entry_state,aperture_state

Conclude with perfect simulation candidate only.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])