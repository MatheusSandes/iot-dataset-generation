var_9 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Create multiple plausible IoT data simulations representing daily patterns in a two-adult, one-child smart household.
Rigorously evaluate each for realism in device interactions and occupant behavior timing.
Choose the single most authentic dataset meeting all specified conditions, and present it exclusively.
Omit all intermediate versions, selection rationale, and commentary - deliver only the perfected output.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Blueprint

▶ Dweller Configuration

⌂ Structural Dimensions:
  • Master_Bedroom: 3.2x3.2m (WxL)
  • Childs_Room: 2.8x3m  
  • SharedSpace: 4x3.5m  
  • Cooking_Zone: 1.8x1.3m
  • Utility_Node: 1.5x1m
  • Hygiene_Compartment: 2.1x1.3m (unmonitored)

⚙ Embedded Devices:

★ Master_Bedroom Cluster:
   - proximity_MAIN
   - climate_MAIN
   - illumination_MAIN

★ Child's Domain:
   - proximity_CHILD
   - climate_CHILD
   - illumination_CHILD

★ Common Area Array:
   - proximity_COMMON
   - climate_COMMON
   - entertainment_SYS
   - illumination_COMMON
   - access_CONTROL

★ Nutritional Sector:
   - climate_KITCHEN
   - illumination_KITCHEN
   - appliance_MONITOR (refrigeration)

★ Utility Monitoring:
   - proximity_UTILITY
   - climate_UTILITY

Linkage Topology:
  Master_Bedroom ←→ Common ←→ Cooking_Zone
  Child's_Domain ←→ Hygiene ←→ Utility_Node ←→ Cooking_Zone

⌚ Chronological Patterns:

△ First Parent:
  05:50 arousal | 07:50 departure | 17:15 return | 22:20 repose

△ Second Parent:
  06:45 arousal | 08:45 departure | 18:15 return | 23:10 repose

△ Juvenile:
  06:20 arousal | 07:40 school departure | 16:50 return | 21:45 repose

△ Sleep Allocation:
  Parents → Master_Bedroom
  Child → Child's_Domain

⏳ Activity Phasing:

05:50-06:20  ▷ Sole parent 1  
06:20-06:45  ▷ Parent 1 + offspring  
06:45-07:40  ▷ Full household  
07:40-08:45  ▷ Parental units  
08:45-16:50  ▷ Vacancy period  
16:50-17:15  ▷ Parent 1 solo  
17:15-18:15  ▷ Parent 1 + child  
18:15-21:45  ▷ Complete occupancy  
21:45-22:20  ▷ Adult-only  
22:20-23:10  ▷ Parent 2 solo  
23:10-05:50  ▷ Sleep cycle  

Technical Parameters:

△ Environmental Tracking:
  Thermal Δ: ±0.4–1.3°C per 12–25min  
  Hydration ↔ Thermal correlation: -0.68 to -0.92  
  Energy spikes: 90–350W on activation  

△ Stochastic Elements:
  Thermal sensor jitter: ±0.12°C  
  Power fluctuation: ±9.5%  
  False positive motion: 0.08–0.25%  

△ Restricted Intervals:
  08:45–16:50 (unoccupied)  
  23:10–05:50 (quiescent state)  

【Output Schema】

Initiate with precisely this column arrangement:
timestamp,event_id,zone,event_class,actuator,thermal_read,humidity_read,movement,resident_count,brightness,energy_usage,acoustic_level,atmosphere_score,portal_state,aperture_status

Then display only the optimal dataset selected through competitive analysis.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])