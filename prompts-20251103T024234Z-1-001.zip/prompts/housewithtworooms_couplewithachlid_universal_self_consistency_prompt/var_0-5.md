var_5 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Develop multiple IoT data sequences representing a typical day in a smart home with two parents and one school-aged child.
Evaluate each for logical patterns, realistic device interactions, and temporal consistency.
Choose the single most plausible dataset that best matches human behavior patterns and home automation usage.
Output only the finalized version without commentary or discarded options.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Residence Configuration

- Dwelling: Compact urban smart apartment with two sleeping quarters

- Device Mapping:

  • Master Bedroom (3m x 3m):
    - bedroom1_motion_detector
    - bedroom1_thermostat
    - bedroom1_dimmable_led

  • Child's Room (3m x 3m):
    - bedroom2_presence_sensor
    - bedroom2_temp_probe
    - bedroom2_smart_bulb

  • Common Area (3m x 3m):
    - living_room_motion
    - living_climate_sensor
    - entertainment_system
    - ambient_lighting
    - entry_lock_system

  • Cooking Space (1.8m x 1.2m):
    - kitchen_temp_monitor
    - under_cabinet_lights
    - refrigerator_smart_meter

  • Utility Zone:
    - laundry_area_sensor
    - storage_temp_gauge

  • Washroom (2m x 1.2m): unsensored

- Spatial Connectivity:
  - Master   Common
  - Child's   Washroom
  - Washroom   Utility   Cooking
  - Common   Cooking

- Occupants:
  • Parent 1: rises 05:50, departs 07:45, returns 17:15, retires 22:45  
  • Parent 2: rises 07:10, departs 09:15, returns 18:30, retires 23:15  
  • Student: rises 06:45, leaves 07:20, returns 17:40, bedtime 21:30  
  • Parents occupy Master, child in Child's Room

Activity Timeline:
- 05:50–06:45   Parent 1 active  
- 06:45–07:10   Parent 1 + Child  
- 07:10–07:20   all residents  
- 07:20–07:45   Parent 1 + Parent 2  
- 07:45–09:15   Parent 2 solo  
- 09:15–17:15   vacant  
- 17:15–17:40   Parent 1 present  
- 17:40–18:30   Parent 1 + Child  
- 18:30–21:30   full household  
- 21:30–22:45   parents only  
- 22:45–23:15   Parent 2 alone  
- 23:15–05:50   sleep cycle

Technical Parameters:

- Motion detection triggers:
  - Temp fluctuation: 0.7 ±0.25°C per 20min
  - Power surge: 150W±50W immediate
  - Thermal-Humidity slope: -0.8±0.1
- Real-world variance:
  - Temperature ±0.3°C
  - Power ±9%
  - Motion false positives: 0.2±0.1%

Quiet Periods:
- 09:15–17:15 (unoccupied)
- 23:15–05:50 (sleeping hours)

Data Structure:

Begin with header row:
timestamp,event_id,zone,event_category,activated_sensor,temp_read,humidity_pct,motion_flag,occupancy_count,illumination,wattage_db,acoustic_reading,aqi_value,door_state,window_cond

Follow with singular optimal dataset.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])