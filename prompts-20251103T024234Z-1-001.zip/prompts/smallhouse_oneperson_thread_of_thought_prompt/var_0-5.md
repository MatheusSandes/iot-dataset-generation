
var_5 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Analyze the smart home scenario systematically through temporal progression.
For each time segment, methodically determine:
- Spatial occupant position
- Device activations and interactions
- Environmental sensor correlations
- Event sequences and dependencies
Execute this causal analysis privately before generating the final data output.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Residence Configuration

|| Property Specifications ||
- Type: Compact urban smart residence
- Layout dimensions: 
  - Lounge: 3x3 meters 
  - Sleeping Quarters: 3x3 meters
  - Food Prep Zone: 1.8x1.2 meters
  - Hygiene Room: 2x1.2 meters

|| Deployed Sensors/Devices ||

▼ Lounge Area ▼
⚫ Dynamic presence detector (ID: motion_lounge)
⚫ Entertainment unit (ID: display_lounge)
⚫ Adaptive illumination (ID: light_lounge)  
⚬ Thermal monitor (ID: temp_lounge)
■ Entry security (ID: lock_entrance)  

▼ Sleeping Quarters ▼
⚫ Dynamic presence detector (ID: motion_rest)
⚬ Adaptive illumination (ID: light_rest)
⚬ Thermal monitor (ID: temp_rest)

▼ Food Prep Zone ▼
⚬ Thermal monitor (ID: temp_kitchen)  
⚬ Adaptive illumination (ID: light_kitchen)
■ Appliance controller (ID: plug_cooling)

|| Connection Map ||
Sleeping Quarters ↔ Lounge ↔ Food Prep Zone ↔ Hygiene Room

|| Occupant Profile ||
◉ Single adult resident
⏰ Activity Pattern:
- Dawn routine: 06:00–08:00
- Evening activity: 17:00–22:30
- Exterior period: 08:00–17:00
- Rest cycle: 22:30–06:00

|| Environmental Context ||
❤️ Southern hemisphere winter season (June)
☁️ Interior climate conditions:
- Heat range: 21–26°C
- Moisture range: 40–70% (anti-correlated with heat)

|| Operational Guidelines ||

Phase 1: Causal Analysis (06:00–08:00)
- Establish resident position for each temporal marker
- Predict sensor activations and their consequences
- Identify cross-device relationships (motion→thermal→powerflows)
- Apply system fluctuation parameters

Phase 2: Data Generation
- Implement temporal realism (natural time variations)
- Apply measurement deviations per technical specs

|||| Technical Parameters ||||
◆ Presence Detection ↠ 
   ○ Heat effect: +0.5–1.5°C over 15–30min window
   ○ Energy spike: 100–300W instantaneous
◆ Climate Relationships:
   ○ Thermal → Dampness coefficient: -0.7 to -0.9
◆ System Tolerances:
   ○ Thermal: ±0.1°C
   ○ Energy: ±11%
   ○ Presence false triggers: 0.1–0.3%
◆ Absolute Rest Periods: 22:30–06:00, 08:00–17:00

Output Structure:
[PREFIX]
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

[CONSTRAINT]
Present only the processed dataset without analytic commentary.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])