var_8 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Analyze the residential automation case study through methodical causation chains.
Establish interdependent linkages between states and events at each chronological checkpoint - each causation sequence must stem from established physical interactions and behavioral patterns.
Disclose the analytic process before assembling the output data structure.
Surface key statistical correlates when populating measurements.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Premises & System Parameters

[Residence Blueprint]
Structure Type: Compact metropolitan apartment

[Device Distribution]
■ Main Chamber (3×3m configuration):
• Movement detector (zone_A_motion)
• Entertainment display (display_unit)  
• Adaptive luminaire (light_node_A)  
• Thermal sensor (thermal_A)  
• Entry mechanism (access_controller)

■ Sleeping Quarter (3×3m layout):  
• Movement detector (zone_B_motion)  
• Adaptive luminaire (light_node_B)  
• Thermal sensor (thermal_B)

■ Preparation Area (1.8×1.2m):  
• Thermal sensor (thermal_C)  
• Adaptive luminaire (light_node_C)  
• Power regulator (appliance_main)  

■ Sanitation Space (2×1.2m): no instrumentation

[Topological Relationships]
Sleeping Quarter <=> Main Chamber <=> (Preparation Area & Sanitation Space)

[Operational Profile]
• Single inhabitant  
• Daily operational phases:
  Active: 06:00-08:00 & 17:00-22:30  
  Inactive: 08:00-17:00  
  Resting: 22:30-06:00  

[Environmental Context]  
• Seasonal parameters: Southern winter phase (June semester)  
• Indoor thermal range: 294-299Kelvin  
• Moisture variance: 40-70% RH (inverse thermal coupling)  

Methodological Constraints:

1) Initiate simulation at dawn circadian phase  
2) Establish spatial transitions gradually with resident movement  
3) For each phase step:
  • Pinpoint resident localization  
  • Predict artifacts activation cascades  
  • Maintain parameter conjugations:
    Movement<>temperature delta (0.5–1.5°C over 900-1800s)  
    Movement<>energy step (100–300J/s instantaneous)  
    Temperature<>humidity gradient (-0.7:-0.9 coefficient)
4) Incorporate typical artifacts:
  • Thermal reading oscillation <10.1°C  
  • Energy estimation tolerance <11%  
  • Motion recognition error 0.1–0.3%
5) No transient surges during resident absence (2200-0600 & 0800-1700)

Output Structure:
Detached header artifacts:
datetime,session_id,area,interaction_class,actuator,thermal_reading,relative_humidity,movement_flag,space_status,illumination_index,power_surge,acoustic_level,atmospheric_quality,plane_state,aperture_state

Detached dataset payload without analytical artifacts.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])