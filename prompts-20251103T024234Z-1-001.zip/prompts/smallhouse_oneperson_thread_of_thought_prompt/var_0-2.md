
var_2 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Analyze the smart home scenario methodically by progressing through each minute from 06:00 to 08:00.
Construct a precise chronological sequence of events by evaluating user behavior patterns and device interactions.
Maintain strict logical consistency between each time increment and device responses.
After completing this comprehensive analysis, produce the final dataset without including the analytical process.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Configuration Profile

Residence Characteristics:
- Type: Compact urban dwelling (72 sqm total)
- Climate: Brazilian winter season
- Operational hours: See occupant schedule

Device Inventory:

[Living Area] (9 sqm)
- Environmental: temp_sensor_living, motion_sensor_living
- Utilities: smart_light_living (60W), smart_lock_front
- Entertainment: smart_tv (120W standby, 300W active)

[Sleeping Quarters] (9 sqm)
- Environmental: temp_sensor_bedroom, motion_sensor_bedroom
- Lighting: smart_light_bedroom (40W)

[Food Preparation Zone] (2.16 sqm)
- Environmental: temp_sensor_kitchen
- Appliances: smart_plug_fridge (200W cyclic)
- Lighting: smart_light_kitchen (75W)

Room Connectivity Map:
Bedroom ↔ Living Area ↔ {Kitchen + Hygiene Chamber}

Occupant Profile:
- Single professional resident
- Daily rhythm:
  - Active periods: 06:00–08:00 | 17:00–22:30
  - Away interval: 08:00–17:00
  - Rest cycle: 22:30–06:00

Environmental Parameters:
- Thermal range: 21–26°C
- Moisture range: 40–70% RH (inverse temp relationship)
- Winter season conditions

Analysis Protocol:

1. Initiate temporal simulation at 06:00
2. For each minute segment:
   - Track occupant location movement
   - Predict device activations
   - Calculate environmental changes
   - Apply sensor interaction rules
3. Incorporate system variances:
   - Temperature deviation: ±0.5°C
   - Power fluctuation: ±15W
   - False motion triggers: ≤0.3% probability
4. Maintain natural timestamp intervals
5. Conclude at 08:00 and output dataset

Device Interaction Matrix:
- Motion → Thermal impact (+0.7–1.2°C/20min)
- Activity → Power surge (150–350W immediate)
- Temp/RH correlation: -0.8 coefficient
- All devices inactive during off-hours

Output Specifications:

CSV header row (exactly as shown):
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Provide only the generated dataset (no explanations).
"""),
    AIMessagePromptTemplate.from_template("prompt")
])