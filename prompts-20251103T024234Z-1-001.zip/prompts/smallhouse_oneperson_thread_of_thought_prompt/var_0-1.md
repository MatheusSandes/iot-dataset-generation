var_1 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Analyze the following smart home scenario methodically, evaluating each potential interaction through multiple validation passes.
For each time segment:
1) Track human presence movement patterns
2) Calculate expected device triggers accounting for environment and behavior
3) Apply noise models to simulate real conditions
4) Verify cross-sensor correlations
Only after finalizing all calculations, produce the dataset silently - never show intermediate deductions.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Scenario Parameters

▶ Living System (18m² total)
○ Living Zone (9m²):
  • MotionDetector-L1
  • EntertainmentSystem-TV5
  • Illumination-LED3
  • ClimateSensor-TMP2
  • AccessControl-LockA

○ Rest Zone (9m²):
  • MotionDetector-R1  
  • Illumination-LED2
  • ClimateSensor-TMP3

○ Nutrition Zone (2.16m²):
  • ClimateSensor-TMP4
  • Illumination-LED1
  • PowerOutlet-FRIDGE

▶ Temporal Patterns
◉ Active Phases:
  - Dawn Routine: 06:00–08:00
  - Evening Engagement: 17:00–22:30
◉ Inactive Periods:
  - Solar Cycle: 08:00–17:00
  - Regeneration Cycle: 22:30–06:00

▶ Physical Laws
▣ Motion Dynamics:
  - Temperature Delta: +[0.4,1.6]°C per [12,36]min
  - Power Surge: 80–350W immediate
▣ Environmental Links:
  - Thermo-Hygro Ratio: -0.65 to -0.95
▣ System Variance:
  - Sensor Tolerance:
    • Temperature: ±1.2°C
    • Power: ±9%
    • False Positives: 0.08–0.35%

▶ Production Protocol
1) Simulate dawn cycle starting 06:00:00
2) For each registered event:
  - Tag occupant position
  - Apply primary/secondary triggers
  - Inject appropriate noise
  - Validate interdependencies
3) Conclude at approximate daybreak transition (~08:00)

Output Matrix Requirements:

Required Fields (CSV):
timestamp,event_code,zone_id,signal_origin,temp_reading,humidity_value,movement_status,presence_flag,lux_measurement,wattage_fluctuation,sound_db,aqi_index,entry_state,aperture_status
"""),
    AIMessagePromptTemplate.from_template("prompt")
])