
var_4 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Analyze the smart home scenario rigorously by constructing a sequential chain of cause-and-effect relationships.
Progress methodically through each temporal stage, considering physical interactions and device relationships.
Develop complete reasoning while maintaining internal numeric consistency.
Present ONLY the structured final output - excise all intermediate logical steps from the results.
"""),
    HumanMessagePromptTemplate.from_template(r"""
## Residential Environment Profile

### Spatial Configuration  
- Dwelling Type: Compact urban smart residence  

### Intelligent Systems Deployment:  

▼ Utility Areas ▼  

◈ Primary Chamber (3x3m):  
  • Environmental Scanner #1 (env_scan_main)  
  • Entertainment Media Unit (media_unit)  
  • Illumination Node A (light_node_A)  
  • Thermal Reader A (thermal_A)  
  • Access Control A (door_ctl_entry)  

◈ Resting Area (3x3m):  
  • Environmental Scanner #2 (env_scan_rest)  
  • Illumination Node B (light_node_B)  
  • Thermal Reader B (thermal_B)  

◈ Food Preparation Zone (1.8x1.2m):  
  • Thermal Reader C (thermal_C)  
  • Illumination Node C (light_node_C)  
  • Power Node: Refrigeration Unit (power_node_chill)  

◈ Sanitation Area (2x1.2m): No automation  

### Spatial Adjacency:  
Rest Area ↔ Main Chamber ↔ (Prep Zone ↔ Hygiene Zone)  

### Resident Behavior Pattern:  
- Active phase 1: 06:00–08:00  
- Absence period: 08:00–17:00  
- Active phase 2: 17:00–22:30  
- Dormancy phase: 22:30–06:00  

### Climatological Parameters:  
- Season: Austral winter (June)  
- Indoor temp range: 21–26°C  
- RH Range: 40–70% (inverse temp dependence)  

## Analytical Directives:  

1. Commence chronological simulation at 06:00  
2. For each time quantum evaluate:  
  a) Spatial presence probabilities  
  b) Device activation sequences  
  c) System interactions (motion > thermal effects > power draws)  
  d) Real-world timestamp variability  
3. Extend analysis through morning active period (until ~08:00)  

## Enhancement Factors:  

■ Environmental Interactions  
- Movement → +ΔT (0.5–1.5°C per 15–30min observational window)  
 Yu|| Enhancement Factors:  

 Yu performance|| Enhancement Factors:  

 Yu|| Enhancement interrupted due to content constraints  

■ Energy Signatures:  
- Activity → Immediate power demand (100–300W)  

■ Thermal-Hydration:  
- Temp coefficient: -0.7 to -0.9 (rH response)  

■ Signal Infidelity:  
- Thermometer: ±0.1°C variability  
- Power metering: ±1% error  
- Motion artifacts: (0.1–0.3% false triggers)  

Collect ONLY completed datapoints between 06:00–08:00 in MATRIX format:  

timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status  
"""),
    AIMessagePromptTemplate.from_template("prompt")
])