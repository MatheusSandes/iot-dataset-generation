var_6 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Analyze the following smart home scenario methodically. 
Process information in discrete chronological stages, where each decision point flows naturally from the prior state.
Maintain logical continuity between each stage while carefully considering device interactions and environmental factors.
Complete the entire analytical process before producing the final output dataset - never include intermediate reasoning.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Residential Smart Environment Configuration

- Dwelling Characteristics: Compact metropolitan residence with IoT integration

- Device Inventory by Zone:

  ▸ Primary Social Space (9m²):
    [M] Occupancy detector (motion_primary)
    [E] Entertainment display (smart_display)
    [L] Adjustable illumination (light_primary)
    [T] Thermal monitor (temp_primary)
    [S] Secure entry mechanism (lock_main)

  ▸ Rest Chamber (9m²):
    [M] Presence indicator (motion_rest)
    [L] Dimmable lighting (light_rest)
    [T] Heat gauge (temp_rest)

  ▸ Food Preparation Area (2.16m²):
    [T] Temperature sensor (temp_kitchen)
    [L] Task lighting (light_kitchen)
    [P] Appliance controller (plug_appliance)

  ▸ Hygiene Facility (2.4m²): Unmonitored

- Spatial Relationships:
  • Rest Chamber ↔ Primary Social Space
  • Primary Social Space ↔ Food Prep Area & Hygiene Facility

- Resident Profile:
  - Single professional
  - Active phases: 06:00-08:00 and 17:00-22:30
  - Absence window: 08:00-17:00
  - Rest period: 22:30-06:00

- Environmental Conditions:
  - Southern hemisphere winter season
  - Interior thermal range: 21-26°C
  - Moisture content: 40-70%, inversely related to temperature

Operational Parameters:

- Commence temporal analysis at 06:00 based on resident behavior
- For each time segment, determine:
  - Current resident location
  - Probable device activations
  - Inter-sensor relationships (e.g., presence → thermal changes)
  - Application of temporal variance and sensor error margins
- Continue sequential evaluation until approximately 08:00
- Upon completion, render the final data compilation

Technical Specifications:

- Motion → Temperature (+0.5-1.5°C over 15-30 minute window)
- Motion → Power draw (100-300W immediate effect)
- Temperature → Humidity coefficient: -0.7 to -0.9
- Measurement tolerances:
  - Thermal ±0.1°C
  - Energy ±11%
  - False positive motion detection rate: 0.1-0.3%
- Quiescent periods: 22:30-06:00 and 08:00-17:00
- Timestamps must reflect natural variation (avoid regular periodicity)

Deliverable Structure:

Initiate with the prescribed header:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Provide ONLY the processed dataset, excluding all analytical scaffolding.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])