```python
var_0 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Reason through the smart home scenario below in a linear, step-by-step fashion.
Each step should build upon the previous one in a coherent sequence — like a logical thread of thought — to determine which events occur, in which order, and why.
Only after completing this internal reasoning, generate the final dataset.
Do not include the reasoning in the output.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Scenario Configuration

- House Type: Small urban smart home

- Devices by Room:

  • Living Room (3m x 3m):
    - 1x Motion sensor (motion_sensor_living)
    - 1x Smart TV (smart_tv)
    - 1x Smart light bulb (smart_light_living)
    - 1x Temperature sensor (temp_sensor_living)
    - 1x Smart lock (smart_lock_front)

  • Bedroom (3m x 3m):
    - 1x Motion sensor (motion_sensor_bedroom)
    - 1x Smart light bulb (smart_light_bedroom)
    - 1x Temperature sensor (temp_sensor_bedroom)

  • Kitchen (1.8m x 1.2m):
    - 1x Temperature sensor (temp_sensor_kitchen)
    - 1x Smart light bulb (smart_light_kitchen)
    - 1x Smart plug (smart_plug_fridge)

  • Bathroom (2m x 1.2m): no sensors

- Room Connections:
  - Bedroom   Living Room
  - Living Room   Kitchen and Bathroom

- User:
  - Single adult occupant
  - Active from 06:00 to 08:00 and from 17:00 to 22:30
  - Away from 08:00 to 17:00
  - Sleeps from 22:30 to 06:00

- Environment:
  - Winter in Brazil (June)
  - Indoor temperature: 21–26°C
  - Humidity: 40–70%, inversely correlated with temperature

Instructions:

- Start reasoning from 06:00 based on user activity.
- At each time step, decide:
  - Which room the user is in
  - Which device or sensor is likely to be triggered
  - What sensor correlations apply (e.g. motion   temp, power)
  - How timestamp variation and noise apply
- Continue the reasoning until ~08:00
- After the reasoning is complete, generate the final dataset

Technical Rules:

- Motion     Temperature (+0.5–1.5°C in 15–30min)
- Motion     Power (100–300W instantly)
- Temperature   Humidity: -0.7 to -0.9
- Noise:
  - Temp 'b10.1°C
  - Power 'b11%
  - Motion FP: 0.1–0.3%
- No events between 22:30–06:00 or 08:00–17:00
- Timestamps should be realistic (no fixed intervals)

Output Format:

Start with the following header:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Then output only the final dataset (do not include the reasoning).
"""),
    AIMessagePromptTemplate.from_template("prompt")
])
```