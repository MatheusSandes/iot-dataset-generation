var_7 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Analyze the smart home scenario methodically, constructing a causal chain of events.
For each time segment, deduce probable interactions between user behavior, environmental conditions, and device activations.
Maintain strict chronological progression while accounting for physical constraints and statistical probabilities.
After complete analysis, produce only the final event dataset without explanation.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Operational Context

== Architectural Profile ==
• Compact Smart Residence (Urban Setting)
• Spatial Layout:
  - Living Area: 9m² [Motion/TV/Lights/Climate/Lock]
  - Sleeping Quarters: 9m² [Motion/Lights/Climate]
  - Food Preparation Zone: 2.16m² [Climate/Lights/Appliance]
  - Hygiene Area: 2.4m² [No instrumentation]

== Connectivity Matrix ==
Bedroom <-> Living Room <-> {Kitchen + Bathroom}

== Resident Pattern ==
• Chronological Cycle:
  │ Wake Phase: 06:00–08:00
  │ Away Period: 08:00–17:00
  │ Return Phase: 17:00–22:30
  │ Rest Interval: 22:30–06:00

== Climate Context ==
• Seasonal: Southern Hemisphere Winter
• Thermal Band: 21–26°C (indoor)
• Moisture Relationship: Inverse temperature correlation (40–70% RH)

Analysis Protocol:

1. Initialize simulation at 06:00 with wake event
2. For each temporal increment (msec precision recommended):
   a. Determine spatial positioning via motion propagation
   b. Calculate cascade effects:
      • Thermal changes (Δt = +0.5–1.5°C per 15–30min activation)
      • Energy consumption spikes (100–300W instant draw)
      • Relative humidity adjustment (ΔRH = -0.7 to -0.9 per +1°C)
   c. Apply stochastic variations:
      • Thermal noise: ±0.1°C
      • Power fluctuation: ±11%
      • False motion triggers (0.1–0.3% probability)
3. Conclude morning cycle at 08:00 transition
4. Generate dataset excluding analytical steps

Technical Constraints:
• Null activity during sleep/absence
• Non-periodic timestamp generation
• Physical adjacency governs event sequencing

Data Schema:
timestamp|event_uuid|zone|event_class|sensor_origin|thermal_state|humidity_index|motion_state|presence_flag|illumination_value|wattage|acoustic_level|particulate_count|entryway_state|fenestration_status
"""),
    AIMessagePromptTemplate.from_template("prompt")
])