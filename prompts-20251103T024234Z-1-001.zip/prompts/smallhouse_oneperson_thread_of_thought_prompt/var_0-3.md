var_1 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Analyze the smart home system below through methodical temporal progression.
Execute a deterministic timeline analysis where each event causes subsequent reactions.
Maintain rigorous cause-effect linkages while considering environmental variables.
After full causal modeling is complete, output only the resultant data table.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Home Automation System Profile

Dwelling Characteristics:
- Urban efficiency apartment layout
- Floorplan Geometry:
  * Lounge Zone (3×3m)
  * Rest Chamber (3×3m)
  * Food Preparation Cell (1.8×1.2m)
  * Hygiene Cubicle (2×1.2m)

Device Matrix:

# Central Living Space
- Presence detector: presence_center
- Entertainment display: media_screen
- Illumination node: light_node_main
- Thermal gauge: thermal_main
- Entry control: portal_1

# Sleeping Quarters
- Occupancy scanner: presence_sleep
- Lighting element: light_node_sleep
- Climate probe: thermal_sleep

# Food Handling Area
- Heat sensor: thermal_food
- Lighting unit: light_node_food
- Appliance regulator: power_node_fridge

# Wash Area: No monitoring

Spatial Links:
- Sleeping Chamber ↔ Living Core
- Living Core ↔ Kitchen Nook & Bathing Space

Resident Profile:
- Solitary professional
- Operational windows:
  - Dawn cycle: 06:00–08:00
  - Evening cycle: 17:00–22:30
  - Absence period: 08:00–17:00
  - Regeneration phase: 22:30–06:00

Environmental Context:
- Southern hemisphere winter month
 młThe Interior Climate Envelope
  - Heat range: 21–26°C 
  - Moisture range: 40–70% (inverse thermal relationship)

Analysis Protocol:

1. Initialize temporal simulation at 06:00
2. For each moment determine:
   - Spatial occupation vector
   - Device activation probability
   - Environmental parameter shifts
   - Correlation chains between systems
3. Integrate these effects:
   - Heat displacement (Δt=+0.5–1.5°C: 15–30min delay)
   - Energy demand surge (ΔW=100–300 immediate)
   - Hygrothermal coupling (coefficient -0.7 to -0.9)
4. Apply system tolerances:
   - Thermal fluctuation: 'b10.1°C
   - Power variance: 'b11%
   - False positive detection: 0.1–0.3%
5. Maintain realistic temporal distribution
6. Terminate at 08:00

Data Structure:

required_csv_header:
timecode,device_identifier,zone,interaction_class,sensor_origin,heat_value,moisture_value,movement_state,human_presence,illumination_status,energy_draw,acoustic_measure,atmosphere_quality,ingress_state,egress_state

Extract only the processed observation records.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])