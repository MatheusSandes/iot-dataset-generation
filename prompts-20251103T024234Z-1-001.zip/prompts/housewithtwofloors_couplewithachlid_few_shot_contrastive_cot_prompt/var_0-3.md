
var_3 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a smart home behavior analyst tasked with evaluating and generating realistic activity datasets. 
Given contrasting examples of correct and incorrect home automation event patterns for a family of four, analyze them thoroughly.
Then create a new dataset that accurately reflects the daily rhythm of a similar household with precise sensor correlations.
"""),
    HumanMessagePromptTemplate.from_template(r"""
=== ANALYSIS PHASE ===

Positive Example (Correct Patterns):

Family Dynamics:
- 2 working adults (staggered schedules)
- 2 school children (synchronized routines)
- Consistent appliance usage patterns

Key Validations:
1. Activity peaks correspond to known routines
2. Sensor events show proper causation chains
3. Environmental values stay within biological limits
4. No violations of inactivity periods

Sample Correct Data:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status  
2025-06-01T06:10:11,evt_0001,Kitchen,motion_detected,motion_sensor_service,22.1,66,1,1,medium,150,34,good,closed,closed  
2025-06-01T06:48:03,evt_0003,Bedroom1,light_on,smart_light_bedroom1,22.8,63,1,1,medium,120,34,good,closed,closed  

Negative Example (Faulty Patterns):

Common Errors:
1. Phantom events during known away periods
2. Broken sensor correlations (motion without temperature rise)
3. Unrealistically stable environmental readings
4. Improper timestamp sequencing

Sample Invalid Data:
2025-06-01T13:00:00,evt_0006,Kitchen,motion_detected,motion_sensor_service,25.5,55,1,1,medium,380,34,good,closed,closed  

=== GENERATION TASK ===

Produce a correct dataset for:

Household Profile:
- Adult A: 06:00-08:00 | 17:00-22:30
- Adult B: 07:00-09:00 | 18:00-23:00
- Children: 06:30-07:30 | 17:30-21:30

Sensor Network:
- MasterSuite/Bedrooms: Motion, Temp, Lights, TV
- Living Areas: Multi-sensor arrays
- Kitchen: Appliance monitors
- ServiceArea: Basic sensors

Physical Constraints:
1. Temperature must rise 0.5-1.5°C with activity
2. Power spikes must follow motion (100-300W)
3. RH/Temp correlation: -0.7 to -0.9
4. Realistic noise:
   - Temp: ±0.1°C
   - Power: ±11%
   - Motion: 0.1-0.3% false positives

Quiet Periods (NO EVENTS):
- Weekdays 09:00-17:00
- Nights after 23:00

Output Requirements:
Begin with this header exactly:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Generate 8-12 realistic events spanning a typical day.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])