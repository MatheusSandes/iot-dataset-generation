
var_4 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a smart home data modeling expert analyzing behavioral patterns in household activity.
Compare one valid and one invalid example of family dynamics demonstration through sensor events.
Then construct a realistic dataset for a new family with similar characteristics following all physical and temporal constraints.
"""),
    HumanMessagePromptTemplate.from_template(r"""
VALID EXAMPLE (Proper Sensor-Event Relationships)

Scenario Parameters:
- Dual-income professionals on offset schedules
- Schoolchildren with synchronized routines (07:30–17:30 weekdays)
- Continuous refrigeration with correlated thermal/power readings

Behavioral Flow:
Morning (06:00–08:00): Intense multi-room activity → rising temps °C and power W values.
School Hours (08:30–15:30): Minimal events → thermal drift down.
After School: Localized activity spikes → lighting zones and entertainment power ups.
Night: Steady biometric room temps → zero motion after 22:00.

Validating Events:
timestamp,event_id,location,event_type,trigger_sensor,temp_C,hum_%,motion,occ,light_lvl,power_W,noise_db,air_q,door,window  
2025-06-01T06:17:45,evt_valid1,Bathroom1,motion_onset,wallsensor_L,,65,1,1,med,,34,good,closed,closed  
2025-06-01T06:18:12,evt_valid2,Kitchen,power_spike,fridge_ctrl,21.8,,,1,,205,,good,,  
2025-06-01T06:45:03,evt_valid3,Circulation,temp_rise,ceiling_sensor_X,22.3→23.1,,1,1,,130,,good,closed,  

---

INVALID EXAMPLE (Modeling Deficiencies)

Same household composition showing faults:
• Ghost events during vacancy (09:30 motion+power)
• Non-physical temp deltas (°C/minute violations)
• Device states violating sleep periods
• Absent occupancy-light correlations

Error Demonstrations:
2025-06-01T11:22:00,evt_inval1,MasterSuite,tv_activation,wallsensor_R,,58,0,1,high,290,35,good,open,  
2025-06-01T16:45:00,evt_inval2,Bedroom1,heater_cycle,smart_rad,,72→79,,,,,,closed  

---

New Scenario Generation:

Household Parameters:

RESIDENTS:
- Adult1 (Early): 05:50–07:45 away / 17:20–22:10 home / sleep_by 22:45  
- Adult2 (Late): 07:10–09:15 away / 18:05–23:15 home / sleep_by 23:30  
- Kid1&2: Sync 06:35–07:25 prep / 17:35 return / lights_out 21:40  

SENSOR NETWORK:

<MainZones>
[Master] - presence_L/R, thermal_Z, moodlight, mediaPWR  
[BedA] - juniorSenseA, temp_nodeA, readingLamp  
[BedB] - juniorSenseB, temp_nodeB  

<Shared>
[Living] - entranceTrack, widgetTherm, ambientLED, mainTV  
[Kitchen] - iceboxMonitor, undercabLight  

PHYSICS CONSTRAINTS:

Thermal Dynamics:
 °C rise rate ≤1.1/min (activity areas)  
 %RH coupling = 65-100*(-0.8x + 0.1)  
No Go Periods:
 - 09:30–16:50 (school+work)  
 - 23:45–05:40 (core sleep)

OUTPUT FORMAT:

Required exactly:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Then 10-15 event rows respecting all constraints.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])