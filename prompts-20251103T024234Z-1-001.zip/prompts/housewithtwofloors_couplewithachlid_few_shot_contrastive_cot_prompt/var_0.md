```python
var_0 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are given two reasoning examples for a smart home scenario with four residents: two working adults and two school-age children.
Analyze both carefully to understand the difference between valid and invalid behavior modeling.
Then, generate a correct dataset for a new family scenario with similar household dynamics.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Example 1 (Correct Chain-of-Thought)

Scenario:
- Two adults with offset work schedules
- Two children with identical school routines (07:30–17:30)
- Fridge runs continuously, motion aligns with lights and power, and no events during inactive periods

Reasoning:
Between 06:00 and 08:00, the house is bustling — the adults and children move about different rooms. Temperature and power rise after motion. After 09:00, house quiets down until the children return at 17:30. Lights and TV resume. Everyone settles down by 22:00.

Output:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status  
2025-06-01T06:10:11,evt_0001,Kitchen,motion_detected,motion_sensor_service,22.1,66,1,1,medium,150,34,good,closed,closed  
2025-06-01T06:13:25,evt_0002,Kitchen,power_usage,smart_plug_fridge,,,1,1,medium,200,34,good,closed,closed  
2025-06-01T06:48:03,evt_0003,Bedroom1,light_on,smart_light_bedroom1,22.8,63,1,1,medium,120,34,good,closed,closed  
2025-06-01T17:33:58,evt_0004,Bedroom2,motion_detected,motion_sensor_bedroom2,23.0,62,1,1,medium,110,34,good,closed,closed  
2025-06-01T19:42:01,evt_0005,LivingDining,power_usage,smart_tv_living,,,1,1,high,280,35,good,closed,closed  

---

Example 2 (Incorrect Chain-of-Thought)

Scenario:
Same house and residents

Faulty Reasoning:
Multiple events appear during the day when all residents are away. Motion doesn't trigger any follow-up changes. Power and temp values are outside expected ranges.

Mistakes:
- Inactivity windows are violated
- Sensor values lack correlation
- Unrealistically spaced timestamps

Output:
2025-06-01T13:00:00,evt_0006,Kitchen,motion_detected,motion_sensor_service,25.5,55,1,1,medium,380,34,good,closed,closed  
2025-06-01T13:02:00,evt_0007,Bedroom1,power_usage,smart_tv_bedroom1,,,1,1,high,350,35,good,closed,closed  

---

Now generate a correct dataset for the following smart home:

Family Composition:

- Two adults:
  • Adult 1: wakes 06:00, leaves 08:00, returns 17:00, sleeps 22:30  
  • Adult 2: wakes 07:00, leaves 09:00, returns 18:00, sleeps 23:00

- Two children:
  • Child 1 & Child 2: wake 06:30, leave 07:30, return 17:30, sleep 21:30

Devices and Sensors:

- MasterSuite:
  - motion_sensor_suite, temp_sensor_suite, smart_light_suite, smart_tv_suite

- Bedroom1:
  - motion_sensor_bedroom1, temp_sensor_bedroom1, smart_light_bedroom1, smart_tv_bedroom1

- Bedroom2:
  - motion_sensor_bedroom2, temp_sensor_bedroom2, smart_light_bedroom2

- LivingDining:
  - motion_sensor_living, temp_sensor_living, smart_light_living, smart_tv_living, smart_lock_front

- Kitchen:
  - temp_sensor_kitchen, smart_light_kitchen, smart_plug_fridge

- ServiceArea:
  - motion_sensor_service, temp_sensor_service


 - Room Connections:
  - LivingDining   Kitchen   ServiceArea   UtilityRoom
  - LivingDining   Bathroom1
  - LivingDining   Stairs   Circulation
  - Circulation   Bedroom1, Bedroom2, MasterSuite, Bathroom2, WC 

 
Generation Constraints:

- Motion 
  
  
  
  Temp (0.5–1.5°C in 15–30 min)
- Motion 
  
  
  
  Power (100–300W immediately)
- Temp 
  
  Humidity: correlation -0.7 to -0.9
- Add noise:
  - Temp 'b10.1°C
  - Power 'b11%
  - Motion FP: 0.1–0.3%

Forbidden Periods:

- 09:00–17:00 (except 17:00–17:30, when children return)
- After 23:00 (everyone asleep)

Output Format:

Start with this exact header:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Then output the dataset.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])
```