"""),
    HumanMessagePromptTemplate.from_template(r"""
# COMPARISON OF PROFILES

## QUALITY DAILY PATTERN ANALYSIS
