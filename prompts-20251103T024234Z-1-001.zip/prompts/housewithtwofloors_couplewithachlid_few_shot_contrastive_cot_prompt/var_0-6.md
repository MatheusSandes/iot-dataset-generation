var_6 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You're analyzing two contrastive examples of household behavior modeling for a smart home with four occupants.
First, deeply evaluate both the valid and flawed reasoning patterns shown.
Then construct a realistic dataset for a new family scenario while strictly adhering to behavioral physics and sensor correlations.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Comparative Analysis Samples:

[VALID MODELING] - Coherent Patterns

Scenario Parameters:
- Dual-income parents with staggered schedules (06:30-08:30 departures)
- School-age children synchronized routine (07:15-17:15 absence)
- Devices show activity bursts during active hours only

Causal Relationships:
06:00-07:30: Morning routine cascade (bathroom → kitchen → bedrooms)
→ Motion triggers lighting (medium brightness) and moderate power draw
→ Gradual temperature rise from body heat and appliances
17:30-19:00: Evening activity wave (entry → snacks → relaxation)
→ SmartTV power spike coinciding with living area motion
22:00: System-wide activity drop below baseline

Data Sample:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status  
2025-06-02T06:15:22,evt_0008,Bathroom1,motion_detected,motion_sensor_bathroom1,23.3,71,1,1,medium,180,42,fair,closed,closed  
2025-06-02T06:22:47,evt_0009,Kitchen,power_usage,smart_plug_coffee,22.7,68,1,1,medium,210,37,good,closed,closed  
2025-06-02T17:42:31,evt_0010,LivingDining,device_on,smart_tv_living,24.1,65,1,1,high,320,48,good,closed,closed  

[FLAWED MODELING] - Disconnected Events

Same household parameters but with:
- Phantom motion during school hours
- Non-physical temperature fluctuations
- Missing occupancy-light-power chains

Critical Errors:
→ 10:00 activity without residents
→ TV usage without corresponding presence
→ Sudden 3°C drops inconsistent with HVAC

Erroneous Output:
2025-06-02T11:23:00,evt_0011,Bedroom2,motion_detected,motion_sensor_bedroom2,19.8,75,1,1,medium,295,29,good,closed,closed  
2025-06-02T14:17:00,evt_0012,MasterSuite,device_on,smart_tv_suite,18.2,82,,,high,310,,fair,closed,closed  

------

Create physically consistent data for:

Resident Profiles:

- Caregivers:
  • ParentA: Active 05:45-07:45 & 16:45-22:15
  • ParentB: Active 06:30-08:30 & 17:30-23:00

- Dependents:
  • Teen1 & Teen2: Active 06:15-07:15 & 16:15-21:00

Sensor Network:

- Private Zones:
  ▲ MasterBedroom: multi-sensor_ms, climate_ctrl_ms, lighting_ms
  ▲ TeenRoom1: presence_tr1, thermal_tr1, illuminance_tr1
  ▲ TeenRoom2: presence_tr2, thermal_tr2

- Shared Zones:
  ▼ GreatRoom: omni_sensor_gr, entertainment_unit
  ▼ NutritionCenter: food_storage_monitor, prep_surface_array
  ▼ HygieneHub: steam_detector_sh, water_flow_sh

Spatial Relationships:

GreatRoom ←(connects)→ [NutritionCenter • HygieneHub • StairNode]
StairNode → [MasterBedroom • TeenRoom1 • TeenRoom2 • SanitationPod]

Physical Constraints:

■ Motion → Light (0-300 lux) within 2-5s
■ Occupancy → Power (50-400W) within 10-30s
■ Body heat → 0.8-2.0°C rise per active person
■ Humidity inversely tracks temperature (α=-0.8)

Noise Parameters:

±0.2°C thermal sensor error
±12% power measurement variance
1.5-4.0% false positive motion rate

Quiet Hours Enforcement:

█ No resident-generated events 08:30-16:00
█ Complete quiescence after 23:30

Required Output Format:

Begin with this precise header line:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Follow with your generated dataset.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])