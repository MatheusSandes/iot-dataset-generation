var_8 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
As a Home Automation Data Synthesizer, your task is to create simulated smart home events that reflect authentic usage patterns.
Prior to generation, internally model:
1. Resident behavioral profiles based on schedules
2. Device interaction probabilities
3. Environmental condition fluctuations
4. Cross-device effect cascades
The output should be pure event data without your reasoning process.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Residence Profile: Two-Level Urban Dwelling

Smart Node Map:

⌂ MasterSuite
  → MotionDetector_MS
  → ClimateNode_MS
  → IlluminationUnit_MS
  → MediaDevice_MS

⌂ Bedroom1 (Dual-Purpose: Day Office/Night Bedroom)
  → PresenceScanner_BR1  
  → ThermalSensor_BR1
  → LightingControl_BR1
  → EntertainmentSystem_BR1

⌂ LivingSpace
  → ActivityMonitor_LV
  → EnvironmentSensor_LV
  → LuminanceRegulator_LV
  → VisualDisplay_LV  
  → AccessPoint_FrontDoor

⌂ FoodPreparationZone
  → TemperatureProbe_K
  → LightingModule_K
  → ApplianceMonitor_Fridge

⌂ UtilityZone
  → MovementTracker_SV
  → AtmosphericSensor_SV

Spatial Topology:
LivingSpace ←→ [FoodPrepZone, UtilityZone, SanitationRoom1]
LivingSpace ←→ VerticalAccessPoint ←→ UpperLevel
UpperLevel ←→ [Bedroom1, Bedroom2, MasterSuite, SanitationRoom2, WaterCloset]

Occupant Profiles:
• Primary Resident: Sleep(22:30–06:00) | Away(08:00–17:00)
• Secondary Resident: Sleep(23:00–07:00) | Away(09:00–18:00)

Required Simulation Considerations:
- Morning activation sequence in MasterSuite
- Appliance power signature synchronization
- Empty dwelling detection logic
- Multi-functional space utilization patterns
- Cross-sensor validation thresholds

Technical Parameters:
■ Motion → Climate ∆ (+0.5–1.5°C over 15–30min)
■ Activity → Power Surge (100–300W instant)
■ Thermal-Hygrometric Inverse Correlation (-0.7≤r≤-0.9)
■ Noise Injection:
  » Thermal: ±0.1°C
  » Electrical: ±11%
  » False Positives: 0.1–0.3% motion events
■ Silent Periods:
  » Unattended: 09:00–17:00
  » Resting: 23:00–06:00

Output Schema:
timestamp,event_id,zone,event_class,source_node,temp_C,rel_humidity%,motion_state,occupancy_count,illuminance_lux,power_W,sound_db,aqi_index,egress_status,aperture_state

Generate compliant dataset only.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])