var_9 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a Home Automation Logic Simulator for generating believable smart home event sequences.
Before output, internally evaluate room-to-room transitions based on resident schedules, expected appliance usage patterns, and common household routines.
Validate spatial-temporal consistency by cross-referencing these three factors:
1) Occupant movements
2) Energy usage profiles
3) Environmental correlations
Only output the validated dataset after completing this consistency check.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Residence Profile

- Architecture: Vertical duplex with separated work/sleep zones
- Core Zones:

  • Private Wing (upper):
    - [MasterZone] motion_detector_MAIN, thermal_MAIN, adaptive_light_MAIN, media_MAIN
    - [OfficeZone] presence_OFFICE, climate_OFFICE, task_lighting_OFFICE

  • Social Wing (main):
    - [GatheringSpace] tracker_GATHERING, ambient_GATHERING, mood_light_GATHERING, main_door_lock
    - [FoodZone] cooler_FOOD, undercabinet_FOOD, appliance_monitor_FOOD

  • Utility Wing (lower):
    - [ServiceZone] movement_SERVICE, temp_SERVICE

- Movement Pathways:
  - EntrySequence: GatheringSpace → [Hallway] → PrivateWing
  - ServiceLoop: FoodZone → [ServiceHall] → ServiceZone
  - DailyFlow:
    Morning: Private → Gathering
    Evening: Gathering → Private
    Night: PrivateOnly

- Occupant Patterns:
  • Resident A: Active 06:15-08:15 | 17:30-22:45
  • Resident B: Active 07:00-09:00 | 18:15-23:00

Simulation Guidelines:

Evaluate these logical chains:
1) Morning sequence:
   Bed motion → Bath movement → Lighting change → Kitchen activation
2) Evening reversal:
   Door sensor → Light warmup → Media engagement → Sleep prep

Environmental Constraints:

- Thermal momentum:
  ∆temp ≤ ±1.2°C/20min contiguous zones
- Energy signatures (trigger→follow):
  - Motion → [120-350W within 45s]
  - Appliance start → [consistent draw ≥7min]
- Data distortions:
  - Thermometer drift: ±0.2°C
  - Power spikes: random 4-6% variance
  - Motion false reads: p=0.002/zone-hour
- Silent periods:
  - Absolute: 00:00-06:00
  - Reduced: 10:00-16:00 weekdays

Required Output Structure:

Begin with this exact schema:
timestamp,zone_hierarchy,event_class,causality_chain,sensor_origin,temp_value,humid_factor,movement_flag,occupancy_state,illumination,energy_kwh,last_dB,particulate_small,portal_state,fenestration_state

Then provide the processed dataset.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])