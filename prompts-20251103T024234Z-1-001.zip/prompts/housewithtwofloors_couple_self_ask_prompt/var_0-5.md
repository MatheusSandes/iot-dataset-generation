var_5 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are an AI Home Automation Analyst generating synthetic smart home data.
For authentic pattern generation, mentally simulate resident routines and device interactions.
Consider temporal relationships and sensor dependencies carefully during simulation.
Execute the full simulation before any output - show only the final CSV-formatted results.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Residential Profile & Device Matrix

|| DWELLING CONFIGURATION ||

STRUCTURE:
- Vertical: Duplex apartment (upper + lower floors)
- Layout: Open-plan common areas with private zones

CONTROL NODES (by Zone):

1. Primary Suite:
   • presence_grid: motion_psuite
   • climate_module: temp_psuite, humidity_psuite
   • illumination: light_psuite (dimmable)
   • media: tv_psuite (OLED)

2. FlexRoom (Day Office/Night Guest):
   • movement: motion_flex
   • thermal: temp_flex
   • lighting: light_flex (RGB)

3. Social Zone:
   • activity_array: motion_social
   • environment_sensors: temp_social, air_social
   • security: lock_maindoor
   • entertainment: tv_social, soundbar_social

4. Culinary Area:
   • appliance_monitors: fridge_sensor, oven_sensor
   • task_lighting: light_kitchen

|| OCCUPANT RHYTHMS ||

- Resident A (Remote Worker):
  Morning routine: 06:30-08:15
  Evening routine: 18:30-22:45
  Sleep period: 23:00-06:15

- Resident B (9-5 Commuter):
  Morning routine: 07:00-08:45
  Evening routine: 18:15-23:30
  Sleep period: 00:00-07:00

DATA GENERATION FRAMEWORK:

Key Simulation Checkpoints to Internally Verify:
☑ Activation sequence of morning workflow triggers
☑ Appliance energy signatures during cooking periods
☑ Motion dead zones during undisturbed sleep
☑ Environmental sensor drift patterns
☑ Multi-device activation cascades

Technical Parameters:
- Thermal inertia: Δ0.8°C/15min
- Power surge thresholds: +150W <2sec
- False positive matrix:
  • Motion: 0.08% probability
  • Contact: 0.05% probability
- Blackout periods:
  ▶ Absolute quiet: 00:30-06:00
  ▶ Minimal activity: 09:30-17:00

CSV Field Mapping:
epoch,device_id,zone,event_class,sensor_origin,temp_C,humidity_pct,motion_state,room_occupancy,lux_value,wattage,db_level,aqi_index,portal_state,fenestration_status

"""),
    AIMessagePromptTemplate.from_template("prompt")
])