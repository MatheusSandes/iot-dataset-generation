
var_7 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
As a Home Automation Data Synthesizer, your task is to create lifelike sensor data for smart homes.
Internally reason through residence patterns and device interactions before generating any output.
The magic happens in your hidden reasoning process - only show the final generated dataset.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Residence Specification:

▣ PROPERTY DETAILS:
- Architecture: Two-level urban dwelling

▣ SMART DEVICE DISTRIBUTION:

⟡ Primary Bedroom:
→ Motion_Tracker_1
→ Climate_Sensor_1
→ Illumination_Control_1
→ Entertainment_System_1

⟡ Study/Bedroom (dual-purpose):
→ Occupancy_Sensor_2
→ Thermal_Sensor_2
→ Lighting_Node_2
→ Display_Unit_2

⟡ Shared Spaces:
↠ Central Hall Motion Array
↠ Ambient Climate Monitor
↠ Ceiling Luminaires
↠ Entertainment Hub
↠ Entry Security Module

⟡ Food Preparation Zone:
▼ Thermal Sensor Network
▼ Task Lighting
▼ Appliance Power Meter

⟡ Utility Section:
⚫ Motion Detection
⚫ Temperature Logger

▣ SPATIAL LAYOUT:
Main Area ↔ Meal Preparation Area ↔ Laundry Zone ↔ Technical Space
Main Area ↔ Sanitation Module #1
Primary Circulation ↔ Sleep/Study Rooms ↔ Hygiene Module #2 ↔ Powder Room

▣ OCCUPANT RHYTHMS:
✓ Person A: 06:00 wake | 08:00 depart | 17:00 arrive | 22:30 retire
✓ Person B: 07:00 rise | 09:00 exit | 18:00 re-enter | 23:00 sleep

Internal Consideration Guide (not for output):
• Initial morning activation pattern?
• Major appliance usage times?
• When does absolute vacancy occur?
• Secondary room utilization schedule?
• Do all sensor relationships maintain consistency?

Generate data observing these physics:
- Motion → Temperature (Δ0.5–1.5°C/15–30 min)
- Motion → Energy (100–300W instant)
- Thermal & Moisture inverse relationship (-0.7 to -0.9)
- Real-world imperfections to add:
  Temperature ±0.1°C
  Electricity ±1%
  False Detections: 0.1–0.3%
- Sensor silence during:
  ▸ Work Hours (09:00–17:00)
  ▸ Sleep Window (23:00–06:00)

Required Data Format:

Begin with this exact header row:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Then provide the synthesized observations.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])