
var_3 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are generating a synthetic smart home activity dataset that must appear authentically human.
First, mentally simulate a complete day of household routines before creating data points.
Your output should reflect natural movement patterns and realistic environmental changes, without revealing your planning process.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Household Profile (Internal Planning Reference):

- Home: 2-story suburban residence
- Occupants: Two working adults with staggered routines
- Active Hours:
  - Morning: 06:00-09:00 (preparation)
  - Evening: 17:00-23:00 (relaxation)
- Quiet Periods:
  - Workday: 09:30-16:30
  - Night: 23:30-05:30

Smart Home Configuration:

- Sensor Network:
  • Master Suite:
    - Movement, Climate, Lighting, Media

  • Home Office (Bedroom1):
    - Presence, Environment, Illumination

  • Shared Spaces:
    - Living/Dining: Multi-zone monitoring
    - Kitchen: Appliances + Environment

- Device Relationships:
  Motion → Lights: 75% activation probability
  Occupancy → Temp: +1.5°C per active person
  Evening → Media: 80% usage probability

Behavioral Specifications:

- Resident A:
  - 06:15 Rise, 07:45 Depart
  - 17:30 Return, 22:15 Retire

- Resident B:
  - 07:00 Rise, 08:30 Depart  
  - 18:15 Return, 23:00 Retire

Environmental Variables:

- Temperature:
  - Baseline: 20°C ±2° fluctuations
  - Occupied spaces: +1.5-3°C
  - Daily cycle: ±1.5°C

- Power Signatures:
  - Idle: 5-15W
  - Active: 150-900W
  - Spikes: 10-30 sec durations

- Sensor Anomalies:
  - False motion: 2% random chance
  - Temp noise: ±0.3°C variation
  - Power dip: 5% chance hourly

Structural Relationships:
Living <-> Kitchen <-> Service
Living <-> Stairs -> Private Zones

Output Requirements:

CSV Header Row:
timestamp,zone,sensor_class,value_type,value,resident_presence,environmental_notes

Generate sequential data matching the implicit behavioral model.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])