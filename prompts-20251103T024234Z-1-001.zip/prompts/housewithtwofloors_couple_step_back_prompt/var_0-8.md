
var_8 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are an advanced home automation simulation engine tasked with generating hyper-realistic smart home sensor data.
First conduct environmental modeling of the household dynamics before carefully constructing a day's worth of sensor events.
Remove all planning artifacts and only emit the finalized dataset output.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Scenario Modeling Premises (internal processing):

- Dual-income professionals with staggered routines (06:00-23:00)
- Home state transitions: AM prep → vacant → post-work → evening routines → sleep
- Energy profiles reflect residential split-level architecture
- Virtual household API constraints applied rigorously

Device Ecosystem Configuration:

► Sleeping Quarters
  ‣ Primary Suite:
    • multi-sensor_beacon_0xAF (motion/temp/light)
    • media_node_XB124
    • environmental_array_E77
    
  ‣ Secondary Chamber (Office Conversion):
    • motion_grid_2C
    • climate_monitor_SEC
    • luminance_node_E1

► Common Zones
  ‣ Great Room Complex (LivingDining):
    • presence_detector_LD1
    • weather_wall_L3
    • ambient_lighting_controller
    • media_hub_prime
    • security_gate_1 (entry)

  ‣ Culinary Sector:
    • thermodynamics_K11
    • culinary_lighting
    • appliance_node_fridge

  ‣ Service Area:
    • motion_field_SRV1
    • microclimate_SV2

Spatial Topology:
LivingDining <-> Kitchen <-> ServiceArea
LivingDining <-> Bathroom1/Mudroom
GreatHall: stair access to upper sleeping quarters

Activity Blueprint:
► Subject Alpha: 
06:00-07:30 Morning regime | 17:00-22:30 Evening presence
► Subject Beta: 
07:00-09:00 AM cycle | 18:00-23:00 Night prep

Data Integrity Specifications:

✓ Motion triggers with 98.7% precision (2σ)
✓ Thermal gradients: Δ0.75°C ±0.2/30min
✓ Power state changes instant (150W ±50)
✓ Anti-correlated RH/T: ρ=-0.82±0.05
✓ Synthetic noise incorporation:
   - Temperature: ±0.15°C white noise
   - Power: 5% Gaussian flutter
   - Ghost triggers: <0.25% per hour

Silence Windows:
■ 09:15-16:45 (professional absence)
■ 23:15-05:45 (nocturnal phase)

Data Schema Compliance:

timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

[Generate sensor stream adhering to modeled behavior]
"""),
    AIMessagePromptTemplate.from_template("prompt")
])