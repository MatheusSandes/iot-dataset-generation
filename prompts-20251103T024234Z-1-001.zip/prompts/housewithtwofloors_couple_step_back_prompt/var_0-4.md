
var_4 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are an intelligent home automation data generator.
First, analyze the household dynamics and patterns to create a coherent behavioral model.
Use this understanding to produce a natural sequence of smart home events.
Output only the final dataset - omit all reasoning and planning steps.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Strategic Context (internal use only):

- Dual-income couple in a two-level connected home
- Staggered routines: Partner A departs first, Partner B follows later
- House unoccupied between 09:30-17:30 daily
- Shared relaxation time in shared living spaces evenings
- Sleep period strictly observed from 23:30-06:30

Device Configuration

- Room Sensors:

  • PrimaryBedroom:
    - presence_detector_master
    - climate_sensor_master
    - adjustable_light_master
    - entertainment_system_master

  • HomeOffice:
    - motion_tracker_office
    - thermal_sensor_office
    - dimmable_light_office
    - display_panel_office

  • CommonArea:
    - movement_sensor_common
    - ambient_sensor_common
    - lighting_control_common
    - media_device_common
    - entry_lock_main

  • FoodPrepZone:
    - heat_sensor_kitchen
    - task_lighting_kitchen
    - appliance_monitor_fridge

  • UtilityZone:
    - occupancy_detector_utility
    - environment_sensor_utility

- Spatial Relationships:
  • CommonArea connects to:
    - FoodPrepZone
    - UtilityZone
    - SanitationRoom1
  • CentralHallway links:
    - HomeOffice
    - GuestRoom
    - PrimaryBedroom
    - SanitationRoom2
    - WaterCloset

- Resident Patterns:
  • Resident Alpha: 
    - Rise 06:30
    - Depart 08:15
    - Return 17:20
    - Retire 22:45
  • Resident Beta:
    - Rise 07:15
    - Depart 09:15
    - Return 18:30
    - Retire 23:15

Technical Parameters:

- Movement ↔ Temperature fluctuations (0.4-1.6°C per 15-30 mins)
- Occupancy ↔ Power draw spikes (90-310W instantaneous)
- Thermal ↔ Moisture inverse relationship (-0.65 to -0.95)
- Noise injection:
  - Thermal readings ±0.2°C
  - Energy use ±12%
  - Phantom motion events: 0.15-0.35%

Quiet Hours:
- 09:30-17:30 (unoccupied dwelling)
- 23:30-06:30 (sleep cycle)

Data Format:

Required header row:
timestamp,event_id,zone,event_category,source_sensor,thermo_reading,humidity_level,movement_detected,person_count,illumination_status,energy_usage,acoustic_level,atmos_quality,entryway_state,fenestration_status

Follow with the generated event stream.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])