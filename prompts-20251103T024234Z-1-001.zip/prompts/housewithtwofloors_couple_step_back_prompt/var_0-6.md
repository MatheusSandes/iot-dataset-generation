
var_6 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are an observant smart home chronicler. Your task is to craft a detailed, minute-by-minute account of device interactions that realistically reflects household patterns.

First, mentally map out the daily rhythms before translating them into sensor data points. Maintain strict consistency in: 
- Occupancy patterns 
- Environmental changes 
- Device state dependencies 
- Time-based routines

Output only the clean dataset - all planning should remain internal.
"""),
    HumanMessagePromptTemplate.from_template(r"""
[Implicit Scenario Blueprint]

Structure Profile:
┌───────────────┬─────────────────────┐
│ Dwelling Type │ Two-story residence │
│ Resident Count│ 2 working adults    │
│ Active Periods│ 06:00-22:30 weekday │
└───────────────┴─────────────────────┘

Resident Synchronization:
• Adult 1 │ ∎06:00 ▼08:00 ▲17:00 ∎22:30
• Adult 2 │ ∎07:00 ▼09:00 ▲18:00 ∎23:00

Device Ecosystem:
≡ MasterSuite:
   ☀ motion_detector_MAIN
   🌡️ thermostat_MAIN
   💡 lighting_MAIN
   📺 entertainment_MAIN
   🚪 door_sensor_MAIN

≡ OfficeSuite:
   ☀ presence_detector_OFFICE
   🌡️ climate_sensor_OFFICE
   💡 task_lighting_OFFICE
   🔌 appliance_monitor_OFFICE

≡ LivingZone:
   ☀ area_scanner_LIVING
   🌡️ region_thermeter_LIVING
   💡 ambient_lights_LIVING
   🔒 security_lock_ENTRY
   
Device Constraints Matrix:
• Motion → Lighting: 15 second delay before activation
• Temperature region variance: ±0.8°C/hour  
• Nighttime energy baselines: 85-120 watts 
• Data anomalies:  0.25% error injection rate

Activity Prohibitions:
× 09:00-16:59 │ Sole thermostat adjustments
× 23:01-05:59 │ No motion-triggered events

Output Schema:
timestamp,unique_event_id,zone,event_class,initiating_device,celsius,relative_humidity,movement,person_count,luminance,power_draw,acoustic_db,c02_level,entry_state,portal_status
"""),
    AIMessagePromptTemplate.from_template("prompt")
])