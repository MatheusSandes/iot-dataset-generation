
var_7 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a smart home behavioral sequence designer. 
First create a mental blueprint of resident habits and device interactions throughout a full day cycle.
Craft this timeline carefully before generating any data to ensure temporal logic and spatial consistency.
The output should only contain the final dataset - all planning remains internal.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Behavioral Framework (hidden context):

- Dweller Patterns:
  • Professional Couple
  • Asymmetric Work Schedules
  • Prime Usage Windows:
    - 06:00-09:00 Morning Preparation
    - 17:00-23:00 Evening Engagement
  • Downtime Blocks:
    - 09:30 See contracted_clock_off
    - 23:30 See nighttime economy

Architecture Configuration:

- Connected Spaces:
  ¤ Private Zone: MasterSuite | BedOffice01 
  ¤ Social Hub: LivingSpace | KitchenCorner
  ¤ Utility Cluster: ServiceBay | Thermoduct

- Node Inventory:

  >> Rest Domain:
    Ω movement_profile01
    Ω climate_profile01  
    Ω illumination_profile01
    Ω display_profile01

  >> Work Domain:  
    Ω presence_sensor01
    Ω thermal_sensor01
    Ω luminance_control01

  >> Leisure Grid:
    Ω spatial_awareness01
    Ω thermography01
    Ω comfort_radiance01
    Ω wall_display01
    Ω perimeter_security01

- Thermodynamic Constraints:
  ¦ΔT¦ ≤ 1.2°C/22min
  Humidity ∂ ≈ -0.8ΔT
  ¤ Device latency:
    Motion→Power τ < 120s
    Temperature Noise ∂ ∼β(10,.1)

Chronological Anchors:

» Morning Exodus:
  ☼ Adult Prime → contracted_clock_on@07:45 
  ☼ Adult Secondary → commuting_start@09:15

» Evening Repatriation:
  ☾ Prime Homecoming contracted_clock_off@17:30
  ☾ Secondary Home See contracted_clock_off@18:45

Data Schema:
epoch,event_uuid,zone,interaction_class,actuator,thermal_value,moisture,presence_detected,space_state,photon_flux,energy_draw,acoustic_load,respiratory_index,portal_state,aperture_phase

Deliver formatted dataset:
"""),
    AIMessagePromptTemplate.from_template("prompt")
])