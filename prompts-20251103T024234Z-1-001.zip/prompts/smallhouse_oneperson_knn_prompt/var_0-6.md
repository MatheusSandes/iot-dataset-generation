
var_6 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Transform this smart home scenario into a rich, continuous timeline by intelligently filling gaps between observed IoT events.
Leverage the given reference events to craft new sensor readings that maintain logical consistency with:
- Household routines
- Environmental conditions
- Device interactions
- Physical laws of thermodynamics and motion
"""),
    HumanMessagePromptTemplate.from_template(r"""
SMART HOME EVENT SYNTHESIS REQUEST
----------------------------------

INITIAL OBSERVATIONS (K=3 Nearest Neighbors):

timestamp                 event_id location   sensor_type              reading_1 reading_2 reading_3
2025-06-01T06:01:45Z   | evt_001 | Bedroom   | Temperature              | 22.3°C   | 68%RH    | -
2025-06-01T06:04:55Z   | evt_002 | LivingRm  | Motion+Environment       | 23.0°C   | Motion   | 1
2025-06-01T06:06:33Z   | evt_003 | Kitchen   | Temperature+Power        | 24.0°C   | 250W     | -

SCENARIO PARAMETERS:
• Structure: Compact urban dwelling (36m² total)
• Active period: Morning (06:00-08:00), Evening (17:00-22:30)
• Resident: Professional (30s, weekday routine)
• Climate: Brazilian winter (moderate humidity, mild temperatures)

DEVICE ECOSYSTEM:
[Room] Device (SensorID) [Relationships]
• Bed:
  - ThermoNode (T_bed)
  - Lumos Bulb (L_bed)
  - MotionSense (PIR_bed) 

• Living:
  - ThermoSense (T_liv)
  - MotionGrid (PIR_liv)
  - SmartView TV
  - DoorGuard (Lock_01)

• Kitchen:
  - ChillCheck (T_kit)
  - WattMonitor (P_kit)
  
PHYSICAL CONSTRAINTS:
(∆Temp per motion event) = 0.7-1.5K (20-45min half-life)
(Power spike on motion) = (120/cosθ) ±15% W
(Occupancy → Door status) = 85% correlation

SYNTHESIS RULES:
1. Distribute 3-8 new events between given samples
2. Maintain:
   - Physical realism (thermodynamics)
   - Sensor hysteresis (thermal inertia)
   - Device handshaking (logical sequences)
3. Add Gaussian noise:
   ±σ(0.5°C temp, 2% humidity, 5W power)
4. Exclude sleep/away hours (auto-fill as blank)

OUTPUT FORMAT:
Columnar CSV with header:
timestamp ISO8601, location, sensor_type, reading_1, reading_2, reading_3
Include interpolated records in temporal order.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])