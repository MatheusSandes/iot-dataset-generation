```python
var_0 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are provided with a list of IoT sensor events that occurred in a smart home environment.
These events serve as reference examples ("nearest neighbors") for generating a new, realistic sequence of events in a similar temporal and spatial context.
Interpolate additional events that naturally fit between and around the given neighbors, following the sensor rules and household routines.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Reference Dataset Samples (KNN Neighbors)

timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status
2025-06-01T06:01:45,evt_0001,Bedroom,temperature_reading,temp_sensor_bedroom,22.3,68,,1,low,110,35,good,closed,closed
2025-06-01T06:04:55,evt_0002,Living Room,motion_detected,motion_sensor_living,23.0,65,1,1,medium,280,38,good,closed,closed
2025-06-01T06:06:33,evt_0003,Kitchen,temperature_reading,temp_sensor_kitchen,24.0,61,,1,medium,250,36,good,closed,closed

Target Scenario Configuration

- House Type: Small urban smart home

- Devices by Room:

  • Living Room (3m x 3m):
    - 1x Motion sensor (motion_sensor_living)
    - 1x Smart TV (smart_tv)
    - 1x Smart light bulb (smart_light_living)
    - 1x Temperature sensor (temp_sensor_living)
    - 1x Smart lock (smart_lock_front)

  • Bedroom (3m x 3m):
    - 1x Motion sensor (motion_sensor_bedroom)
    - 1x Smart light bulb (smart_light_bedroom)
    - 1x Temperature sensor (temp_sensor_bedroom)

  • Kitchen (1.8m x 1.2m):
    - 1x Temperature sensor (temp_sensor_kitchen)
    - 1x Smart light bulb (smart_light_kitchen)
    - 1x Smart plug (smart_plug_fridge)

- Room Connections:
  - Bedroom   Living Room
  - Living Room   Kitchen and Bathroom

- User:
  - Single adult occupant
  - Active 06:00–08:00 and 17:00–22:30
  - Away 08:00–17:00, sleeps 22:30–06:00

- Environment:
  - Winter in Brazil (June)
  - Indoor temperature: 21–26°C
  - Humidity: 40–70%, inversely correlated

Technical Specifications:

- Use given examples as "neighbors" to infer patterns
- Interpolate new events between and around the samples
- Apply sensor logic and behavior rules:
  - Motion     Temperature (+0.5–1.5°C in 15–30min)
  - Motion     Power (100–300W instantly)
  - Temp   Humidity: -0.7 to -0.9
- Add natural noise:
  - Temperature: 'b10.1°C
  - Power: 'b11%
  - Motion FP: 0.1–0.3%
- No events between 22:30–06:00 or 08:00–17:00
- Use timestamp variation (natural spacing, realistic seconds)

Output Format:

Start with the following header:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Then output only the new CSV dataset including interpolated and plausible events.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])
```