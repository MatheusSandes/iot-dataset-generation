
var_8 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
As an intelligent home simulation engine, your task is to generate plausible IoT sensor events for a residential smart home.
Using the provided reference events as contextual anchors, synthesize additional realistic sensor activations that fit naturally within the household's daily routines and environmental conditions.
Maintain strict adherence to device capabilities and real-world physics while generating events.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Event Anchors (Reference Data Points)

timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status
2025-06-01T06:01:45,evt_0001,Bedroom,temperature_reading,temp_sensor_bedroom,22.3,68,,1,low,110,35,good,closed,closed
2025-06-01T06:04:55,evt_0002,Living Room,motion_detected,motion_sensor_living,23.0,65,1,1,medium,280,38,good,closed,closed
2025-06-01T06:06:33,evt_0003,Kitchen,temperature_reading,temp_sensor_kitchen,24.0,61,,1,medium,250,36,good,closed,closed

Residential Specifications

- Property Type: Compact smart apartment (60m²)
- Climate Zone: Tropical winter (June in Brazil)
- Occupancy Pattern: Solo adult resident
  - Active periods: 06:00-08:00 and 17:00-22:30
  - Sleeping hours: 22:30-06:00
  - Away hours: 08:00-17:00

Device Ecosystem:

[Living Space]
• Dimensions: 3×3m
• Hardware:
  - Presence detection: motion_sensor_living
  - Climate monitoring: temp_sensor_living
  - Lighting: smart_light_living
  - Entertainment: smart_tv (350W peak)
  - Security: smart_lock_front

[Sleeping Quarters]
• Dimensions: 3×3m
• Hardware:
  - Presence detection: motion_sensor_bedroom
  - Climate monitoring: temp_sensor_bedroom
  - Lighting: smart_light_bedroom

[Food Preparation Area]
• Dimensions: 1.8×1.2m  
• Hardware:
  - Climate monitoring: temp_sensor_kitchen
  - Lighting: smart_light_kitchen
  - Appliance control: smart_plug_fridge

Environmental Constraints:
- Temp range: 21-26°C (inverse humidity correlation)
- Humidity range: 40-70% RH
- Power Surge Pattern: +100-300W upon activation

Event Generation Rules:
1. Interpolate temporally between anchor points (natural intervals)
2. Respect device limitations and physics
3. Apply environmental perturbations:
   - Temperature variance: ±0.3°C
   - Power fluctuation: ±5%
   - Sensor error rates: 0.2% false positives
4. Enforce physical dependencies:
   - Motion → Power spike (100-300W)
   - Occupancy → Motion (after 10-20 sec delay)
   - Temperature ↔ Humidity (ΔH = -0.8×ΔT)

Output Directive:
Generate CSV data starting with header row, then populate with realistic interpolated events.
Format all values precisely as:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status
"""),
    AIMessagePromptTemplate.from_template("prompt")
])