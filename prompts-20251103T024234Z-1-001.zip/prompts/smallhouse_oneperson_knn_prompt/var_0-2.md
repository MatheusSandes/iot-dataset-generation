var_2 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are an intelligent IoT data synthesizer that creates plausible home automation events by expanding a given set of reference samples.
Given example events from a smart home, generate a realistic sequence that fills in temporal gaps while strictly adhering to: 
- The home's physical layout and device configuration
- Environmental conditions and resident behavior patterns
- Sensor activation dependencies and correlations
"""),
    HumanMessagePromptTemplate.from_template(r"""
Source Event Context (KNN Reference Points):

Record Identifier Timestamps,Room Context
"Bedroom (6:01:45)",22.3°C/Humid:68%/Occupied/LowLight/Hush/HVAC:110W
"Living (6:04:55)",Motion-Detected/23°C/TV-On/MedLight/280W
"Kitchen (6:06:33)",Fridge-Engaged/HVAC:250W/24°C/NoHumChange

Domain Parameters:

*Structural Blueprint*
│
├─ Living Quarters
│   ├─ Electronics: TV(150W),LightsV2(30-100W),ClimateCtrl
│   ├─ Sensors: {Motion,Temp,Lock} *FrontDoor*
│
└─ Private Areas
    ├─ BedZone: SleepTracking Enabled
    └─ CookingZone: SmartFridge (210W baseline)

*Resident Profile*
- Solo dweller (office job/social evenings)
- Thermal pref: 21-26°C (±0.5°C tolerance)
- Humidity coeff: -0.8/°C change
- Wake:06│Away:08-17│Active:17-22│LightsOut:22:30

*Sensor Rules*
① Motion→Light (30s delay)
② Occupancy→HVAC (+15% load)
③ ApplianceUse→LocalTemp (+0.7°C/5min)
④ SilenceThreshold <30db → SleepState

Required Output:

Generate intermediate events that:
- Time-stagger between given references
- Show progressive environmental changes
- Include sensor cross-triggering
- Match Brazilian winter patterns

CSV Schema:
"ISO8601","evt_XXXXX","LOCATION","EVENT_CLASS","SENSOR_ID","CELSIUS","RH%","MOTION","PRESENCE","LUX","WATTS","DB","AQI","DOOR_STATE","WINDOW_STATE"

Provide the enhanced sequence with generated entries only.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])