
var_9 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a smart home event simulator that generates realistic IoT sensor readings. 
Using the provided historical events as behavioral anchors, create new sensor events 
that seamlessly integrate with these reference points while respecting all 
environmental constraints and device capabilities of the specified smart home.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Behavioral Reference Events (Temporal Anchors)

timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status
2025-06-01T06:01:45,evt_0001,Bedroom,temperature_reading,temp_sensor_bedroom,22.3,68,,1,low,110,35,good,closed,closed
2025-06-01T06:04:55,evt_0002,Living Room,motion_detected,motion_sensor_living,23.0,65,1,1,medium,280,38,good,closed,closed
2025-06-01T06:06:33,evt_0003,Kitchen,temperature_reading,temp_sensor_kitchen,24.0,61,,1,medium,250,36,good,closed,closed

Smart Home Blueprint

Property Specifications:
- Design: Compact urban residence (60m² total)
- Orientation: North-facing windows
- Insulation: Moderate (winter performance class B)
- Occupancy Pattern: Early riser (06:00 wake-up)

Device Network:

  ■ Master Bedroom (9m²):
    • Environmental: temp_sensor_bedroom, humidity sensor (implicit)
    • Activity: motion_sensor_bedroom (ceiling-mounted)
    • Lighting: smart_light_bedroom (dimmable LED)
    • Security: window contact sensor (implicit)

  ■ Living Area (9m²):
    • Environmental: temp_sensor_living
    • Activity: motion_sensor_living (PIR-based)
    • Entertainment: smart_tv (standby power 5W)
    • Lighting: smart_light_living (color-adjustable)
    • Access: smart_lock_front (with door state)

  ■ Kitchen (2.2m²):
    • Environmental: temp_sensor_kitchen (wall-mounted)
    • Appliances: smart_plug_fridge (energy monitoring)
    • Lighting: smart_light_kitchen (motion-triggered)

Behavioral Constraints:
- Thermal Dynamics:
  - Human presence raises local temp by 0.2°C/min
  - Humidity inversely tracks temperature (coefficient -0.8)
- Power Signatures:
  - Lighting: 8-15W per bulb (dimming affects linearly)
  - Electronics: 80-350W when active
- Motion Patterns:
  - Morning routine: Bedroom→Bathroom→Kitchen→Living
  - Evening reverse with longer living room stay
- Silent Periods:
  - Sleep window: 22:30-06:00 (no motion events)
  - Away hours: 08:00-17:00 (only background readings)

Event Generation Rules:
1. Interval Compression:
   - High-activity periods (06:00-08:00) have 1-3 min spacing
   - Transition periods use 4-7 min intervals
2. State Propagation:
   - Motion triggers light state changes within 15s
   - Temp changes propagate to adjacent rooms (0.1°C/min)
3. Measurement Variability:
   - Temperature: ±0.3°C sensor tolerance
   - Power: ±5% meter fluctuation
   - Motion: 98% detection accuracy

Required Output Structure:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Generate only the interpolated CSV dataset with timestamps between 06:01-06:07.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])