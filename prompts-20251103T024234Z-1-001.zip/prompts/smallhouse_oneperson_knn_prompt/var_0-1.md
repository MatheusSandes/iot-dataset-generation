var_1 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are an IoT event simulator that generates realistic smart home sensor data by analyzing given reference events. 
Create a plausible sequence of events that bridges the temporal gaps between reference samples while strictly following:
1) Physical/logical constraints of home automation systems
2) Observed patterns in the reference dataset
3) Provided environmental and behavioral parameters
"""),
    HumanMessagePromptTemplate.from_template(r"""
Input Data (Reference Events):

timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status
2025-06-01T06:01:45,evt_0001,Bedroom,temperature_reading,temp_sensor_bedroom,22.3,68,,1,low,110,35,good,closed,closed
2025-06-01T06:04:55,evt_0002,Living Room,motion_detected,motion_sensor_living,23.0,65,1,1,medium,280,38,good,closed,closed
2025-06-01T06:06:33,evt_0003,Kitchen,temperature_reading,temp_sensor_kitchen,24.0,61,,1,medium,250,36,good,closed,closed

Simulation Parameters:

Location Profile:
• Spacious Living Room (9m²)
  - Motion sensor
  - Entertainment system (280W baseline)
  - Adjustable lighting
  - Climate monitoring

• Quiet Bedroom (9m²)  
  - Sleep monitoring
  - Ambient lighting (110W)
  - Precise climate control

• Compact Kitchen (2.16m²)
  - Appliance load monitoring
  - Task lighting
  - Spot climate sensing

Resident Behavior:
- Early riser (06:00 wake-up)
- Morning routine duration: ~45min
- Spends 3-7min per room transition
- Prefers gradual lighting changes

Environmental Context:
- Tropical winter morning
- Stable indoor climate
- Natural light increasing
- Low external noise

Technical Rules:
1. Apply physics-based correlations:
   - Δ1°C ~ Δ-1% humidity
   - Motion → +0.8°C (±0.3) within 20min
   - Occupancy → 85% chance of lighting change

2. Real-world variability:
   - Timestamps: ±7sec jitter
   - Sensor readings: ±0.5% noise
   - Power draws: ±15W fluctuation

3. Device interactions:
   - Adjacent rooms show coupled climate
   - Lighting follows motion with 5-15sec delay
   - High power devices cause +1-2°C local temp

Required Output:
CSV dataset beginning with header row, then chronologically ordered events that:
- Fill natural gaps between references
- Show resident's movement pattern
- Demonstrate system reactivity
- Include derived measurements
"""),
    AIMessagePromptTemplate.from_template("prompt")
])