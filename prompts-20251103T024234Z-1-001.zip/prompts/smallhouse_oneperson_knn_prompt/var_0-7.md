
var_7 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
As a smart home pattern generator, you'll create realistic IoT event sequences by analyzing provided reference samples (nearest neighbors) and expanding them with contextually appropriate interpolations.
Maintain strict adherence to sensor behaviors, household patterns, and environmental conditions while introducing natural variability.
"""),
    HumanMessagePromptTemplate.from_template(r"""
SOURCE DATA (Event Neighborhood)

timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status
2025-06-01T06:01:45,evt_0001,Bedroom,temperature_reading,temp_sensor_bedroom,22.3,68,,1,low,110,35,good,closed,closed
2025-06-01T06:04:55,evt_0002,Living Room,motion_detected,motion_sensor_living,23.0,65,1,1,medium,280,38,good,closed,closed
2025-06-01T06:06:33,evt_0003,Kitchen,temperature_reading,temp_sensor_kitchen,24.0,61,,1,medium,250,36,good,closed,closed

GENERATION PARAMETERS

Residence Profile:
- Compact urban dwelling (60m² total)
- Primary areas: 
  ¤ Sleeping Quarter (9m²): motion_sensor_bedroom, smart_light_bedroom, temp_sensor_bedroom
  ¤ Social Space (9m²): motion_sensor_living, smart_tv, smart_light_living, temp_sensor_living, smart_lock_front
  ¤ Food Prep Zone (2.2m²): temp_sensor_kitchen, smart_light_kitchen, smart_plug_fridge

Occupancy Pattern:
- Solitary resident (adult)
- Active windows: 
  • Morning: 06:00–08:00
  • Evening: 17:00–22:30
- Quiet periods:
  • Sleep: 22:30–06:00
  • Away: 08:00–17:00

Environmental Context:
- Southern hemisphere winter (June)
- Indoor climate norms:
  - Temperature: 21–26°C
  - Humidity: 40–70% (inverse relationship with temp)
  
Technical Constraints:

1. Event Generation:
   - Insert plausible events between given neighbors
   - Extend sequence naturally before/after samples
   - Honor device capabilities and room connections

2. Sensor Interactions:
   - Motion → +0.5–1.5°C temp rise (15–30min lag)
   - Occupancy → immediate 100–300W power spike
   - Temp/Humidity: ΔHum ≈ -0.8 * ΔTemp

3. Realistic Variability:
   - Measurement noise:
     • Temp: ±0.1°C
     • Power: ±11%
   - False positives:
     • Motion: 0.1–0.3% random activation

4. Temporal Parameters:
   - No events during inactive hours
   - Timestamps: human-paced intervals (natural second values)

Deliverable Format:

Begin with exact header line:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Follow with complete CSV dataset of new events maintaining original data structure.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])