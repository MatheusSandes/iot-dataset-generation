var_5 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a smart home sensor data generator. Using provided reference events as anchors, craft realistic sequences that fill temporal gaps while respecting home automation patterns.
Generate interpolated sensor readings that maintain environmental continuity between the given events, following physical laws of thermodynamics and occupant behavior patterns.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Anchoring Sensor Events (KNN Reference Points)

timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status
2025-06-01T06:01:45,evt_0001,Bedroom,temperature_reading,temp_sensor_bedroom,22.3,68,,1,low,110,35,good,closed,closed
2025-06-01T06:04:55,evt_0002,Living Room,motion_detected,motion_sensor_living,23.0,65,1,1,medium,280,38,good,closed,closed
2025-06-01T06:06:33,evt_0003,Kitchen,temperature_reading,temp_sensor_kitchen,24.0,61,,1,medium,250,36,good,closed,closed

Home Configuration Profile:

- Layout: Compact smart home (50m²)
- Occupancy Pattern: 1 adult, no pets
- Active Hours:
  * Morning routine: 06:00-08:00
  * Evening activity: 17:00-22:30
  * Sleep period: 22:30-06:00
  * Away hours: 08:00-17:00

Device Inventory:

1. Bedroom:
   - Environmental: temp_sensor_bedroom
   - Presence: motion_sensor_bedroom
   - Lighting: smart_light_bedroom (dimmable)

2. Living Room:
   - Environmental: temp_sensor_living
   - Presence: motion_sensor_living
   - Entertainment: smart_tv (energy monitoring)
   - Access: smart_lock_front

3. Kitchen:
   - Environmental: temp_sensor_kitchen
   - Appliances: smart_plug_fridge
   - Lighting: smart_light_kitchen

Environmental Constraints:
- Season: Southern hemisphere winter
- Indoor temperature range: 21-26°C
- Humidity/temperature relationship:
  Δ1°C → Δ-0.8% humidity (±0.1)
- Sensor noise parameters:
  * Temperature: ±0.2°C
  * Power: ±5%

Behavioral Rules:
1. Motion triggers:
   - Lighting activation (delay 2-8s)
   - Temperature increase 0.5-1.5°C/30min
2. Device interactions:
   - TV on → +180-220W instantly
   - Fridge cycles every 20-40 minutes
3. Temporal spacing:
   - Minimum 10s between same-room events
   - Motion events precede environment changes

Generation Requirements:
- Bridge the temporal gaps between reference points
- Apply device interaction logic consistently
- Introduce realistic sensor variations
- Maintain occupant presence continuity
- Exclude events during inactive periods

Output Instructions:

Begin with CSV header row:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Follow with only the generated event data in chronological order.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])