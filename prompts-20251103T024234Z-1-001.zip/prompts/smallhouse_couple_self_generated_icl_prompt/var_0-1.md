var_1 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
First, craft 2-3 authentic sensor event samples that embody typical morning and evening activities in this smart home.
Then, leverage these prototypes to extrapolate a coherent, extended timeseries dataset that maintains natural behavioral rhythms.
Inject appropriate randomness while preserving contextual relationships between sensors and resident patterns.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Blueprint

▲ Residential Layout
- Compact city apartment (72m² total)
- Room Dimensions & Tech:
  • Lounge (9m²):
    ↘ Motion detector (motion_lounge)
    ↘ 4K TV (tv_lounge) 
    ↘ Connected bulb (light_lounge)
    ↘ Thermal sensor (thermo_lounge)
    ↘ Electronic deadbolt (lock_main)

  • Master (9m²):
    ↘ Presence sensor (motion_bed)
    ↘ Dimmable bulb (light_bed)
    ↘ Climate node (thermo_bed)

  • Cooking Area (2.16m²):
    ↘ Temp probe (thermo_kit)
    ↘ Smart fixture (light_kit)
    ↘ Appliance module (plug_fridge)

  • Washroom (2.4m²): Unsensored

▲ Connectivity Map
  Bedroom ↔ Living ↔ [Kitchen | Bathroom]

▲ Occupant Profiles

  Person A:
  ☀ Rise: 06:00  ✈ Depart: 08:00  🏠 Return: 17:00  🌙 Retire: 22:30

  Person B: 
  ☀ Rise: 07:00  ✈ Depart: 09:00  🏠 Return: 18:00  🌙 Retire: 23:00

▲ Environmental Context
- Season: Southern winter
- Thermal band: 21–26°C
- Moisture: 40–70% (inverse relationship)

Guidelines:

① Develop 2-3 archetypal event records spanning either early morning (06:00-09:00) or evening (17:00-23:00).
② Expand these seed examples into a comprehensive event log while:
   ➤ Maintaining cause-effect chains between sensors
   ➤ Introducing plausible variability
   ➤ Respecting temporal constraints
   ➤ Following occupant schedules

Technical Parameters:
- Thermal drift: 0.5–1.5°C per 15–30min
- Power spikes: 100-300W on activation
- Temp-Humidity R: -0.7 to -0.9
- Real-world imperfections:
  ±0.1°C temp variation
  ±1% power fluctuation 
  0.1-0.3% false motion positives
- Quiet hours: 
  No activity 23:00-06:00
  Vacant period 09:00-17:00

Required Output Structure:

Header Row (CSV):
timestamp,device_id,space,event_class,source_sensor,temp_C,rel_humidity,movement_status,resident_count,illumination,wattage,acoustic_volume,ppm_CO2,entrance_state,fenestration

Then sequentially provide:
- Your initial exemplar events
- The extended synthetic dataset
"""),
    AIMessagePromptTemplate.from_template("prompt")
])