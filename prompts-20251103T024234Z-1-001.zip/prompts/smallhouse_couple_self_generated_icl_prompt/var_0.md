```python
var_0 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Start by generating 2 to 3 representative sensor event examples based on the scenario below.
Then, use those examples as in-context demonstrations to generate a longer, realistic dataset that continues the same behavioral patterns.
Ensure the full dataset respects time constraints, correlations, and natural variability.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Scenario Configuration

- House Type: Small urban smart home

- Devices by Room:

  • Living Room (3m x 3m):
    - 1x Motion sensor (motion_sensor_living)
    - 1x Smart TV (smart_tv)
    - 1x Smart light bulb (smart_light_living)
    - 1x Temperature sensor (temp_sensor_living)
    - 1x Smart lock (smart_lock_front)

  • Bedroom (3m x 3m):
    - 1x Motion sensor (motion_sensor_bedroom)
    - 1x Smart light bulb (smart_light_bedroom)
    - 1x Temperature sensor (temp_sensor_bedroom)

  • Kitchen (1.8m x 1.2m):
    - 1x Temperature sensor (temp_sensor_kitchen)
    - 1x Smart light bulb (smart_light_kitchen)
    - 1x Smart plug (smart_plug_fridge)

  • Bathroom (2m x 1.2m): no sensors

- Room Connections:
  - Bedroom   Living Room
  - Living Room   Kitchen and Bathroom

- Residents:

  • Resident 1:
    - Wakes at 06:00, leaves at 08:00, returns at 17:00, sleeps at 22:30

  • Resident 2:
    - Wakes at 07:00, leaves at 09:00, returns at 18:00, sleeps at 23:00

- Environment:
  - Winter (Brazil, June)
  - Indoor temperature range: 21–26°C
  - Humidity: 40–70%, inversely correlated

Instructions:

- Step 1: Generate 2–3 self-created in-context examples (rows of the dataset) reflecting realistic behavior between 06:00 and 09:00 or 17:00 and 22:30.
- Step 2: Use those examples to continue generating a longer sequence of consistent events.
- All events must follow time windows, correlations, and household behavior patterns.
- Avoid rigid timestamp spacing or excessive regularity.

Technical Specifications:

- Motion     Temperature (0.5–1.5°C in 15–30 min)
- Motion     Power (100–300W immediately)
- Temperature   Humidity: correlation -0.7 to -0.9
- Add realistic noise:
  - Temperature 'b10.1°C
  - Power 'b11%
  - Motion FP: 0.1–0.3%
- No events during:
  - 23:00–06:00 (both asleep)
  - 09:00–17:00 (house empty)

Output Format:

Begin with this header:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Then provide both:
- The few-shot examples you generated, and
- The full dataset continuation for the same scenario.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])
```