
var_3 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
First, create 2-3 authentic sensor event demonstrations that precisely match the household patterns described.
Using these demonstrations as behavioral templates, expand them into a comprehensive dataset that maintains continuity.
Pay special attention to natural delays between events, environmental interactions, and plausible sensor variations.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Home Automation Blueprint

● Property Configuration:
  - Urban compact smart residence (32 m² total)
  
● Smart Components:

  ▲ Common Area (3x3m):
    ⚫ Infrared motion detector - motion_living
    ⚫ 4K streaming display - tv_entertainment
    ⚫ Adjustable LED fixture - light_main
    ⚫ Climate monitor - temp_common
    ⚫ Electronic entry system - lock_primary

  ▲ Sleeping Quarters (3x3m):
    ⚫ Presence detector - motion_rest
    ⚫ Dimmable lighting - light_sleep
    ⚫ Thermal sensor - temp_bed

  ▲ Food Preparation Zone (1.8x1.2m):
    ⚫ Ambient thermometer - temp_kitchen
    ⚫ Task lighting - light_prep
    ⚫ Appliance controller - plug_refrigerator

  ▲ Sanitation Area: Unmonitored

● Room Accessibility Map:
  - Rest Suite ↔ Common ↔ (Food Zone + Sanitation)

● Occupant Profiles:

  ♛ Primary Occupant:
    - 06:00 Awakening | 08:00 Departure
    - 17:00 Re-entry | 22:30 Retiring

  ♛ Secondary Occupant:
    - 07:00 Awakening | 09:00 Departure
    - 18:00 Return | 23:00 Sleep Initiation

● Seasonal Context:
  - Brazilian winter month
  - Interior climate: 21-26°C
  - Moisture levels: 40-70% (inverse thermal relationship)

Generation Protocol:

1. Craft 2-3 prototype sensor readings (complete dataset rows) capturing plausible activity during either morning (06:00-09:00) or evening (17:00-22:30) windows.
2. Extrapolate these into a complete sequence maintaining all constraints:
   - Temporal validity
   - Cross-sensor dependencies
   - Human behavior patterns
   - Environmental fluctuations

Technical Parameters:

▶ Motion→Thermal: 0.5-1.5°C shift over 15-30 minutes
▶ Motion→Energy: 100-300W instantaneous draw
▶ Temperature-Humidity: Strong negative correlation (-0.7 to -0.9)
▶ Realistic anomalies:
   - ±0.1°C thermal variance
   - ±1% power fluctuation
   - 0.1-0.3% false motion positives
▶ Silent periods:
   - 23:00-06:00 (sleep cycle)
   - 09:00-17:00 (unoccupied)

Data Structure:

Mandatory header:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Include both:
- Your initial behavioral exemplars
- The extended realistic event sequence
"""),
    AIMessagePromptTemplate.from_template("prompt")
])