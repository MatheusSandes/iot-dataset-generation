
var_7 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
First, compose a set of 2-3 hallmark sensor event examples that encapsulate typical behavior patterns for the given scenario.
Next, leverage these examples as foundational context to extrapolate an extended, coherent dataset that maintains natural behavioral continuity.
Crucially sustain temporal plausibility, cross-device interdependencies, and authentic variability throughout the synthetic data generation.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Scenario Architecture

Residence Profile:
- Property Type: Compact city apartment (smart-enabled)
- Timeframe: Winter season Southern Hemisphere
- Occupant Schedules Tightly Constrained

Sensor Inventory by Zone:

▶ Primary Area (9m²):
  - Dynamic occupancy detection (movement_lounge)
  - Entertainment system viewing adapter (streaming_box)
  - LED illumination node (brightness_primary)
  - Thermal monitoring unit (thermo_primary)
  - Security checkpoint device (origin_portal)

▶ Sleep Chamber (9m²):
  - Motion activity tracker (activity_sleep)
  - Dimmable lighting adapter (mood_lighting)
  - Heat level gauge (warmth_monitor)

▶ Food Prep Zone (2.16m²):
  - Surrounding temperature probe (kitchen_thermo)
  - Lighting control unit (meal_light)
  - Energy outlet for appliances (fridge_hub)

Connections Map:
Sleep Chamber ↔ Primary Area ↔ Meal Preparation Space ↔ Hygiene Area

Inhabitants Overview:

ⅰ Occupant Alpha:
  - Rise: 06:00 | Departure: 08:00
  - Return: 17:00 | Subject Status: REST @ 22:30

ⅱ Occupant Beta:
  - Wake: 07:00 | Exit: 09:00
  - Homecoming: 18:00 | Sleep Phase Begins 23:00

Environmental Parameters:
- Indoor thermal range: 21°C-26°C
- Moisture content: 40-70% RH (inverse thermal coupling)

Generation Protocol:

Phase 1ⅰ) Create authentic seed examples covering high-activity periods (06:00-09:00 or 17:00-22:30).
Phase 1ⅱ) Ensuring these reflect coordinated cross-device interactions.

Phase 2ⅰ) Synthetically extend using behavioral patterns from initial examplesⅱ) Maintaining feasible timing, microenvironment responses, and inhabitant logicⅲ) Display appropriate volatility.

Critical Path Constraints:
▸ Proximity actuation → thermal drift (Δ0.5-1.5°C / 15-30min)
▸ Devices synchronous with presence drawing 100-300W
▸ Thermal-humidity inverse coupling (-0.7 to -0.9)
▸ Specify sensors realistically recording:
  • ℃ values with ±0.1° variation
  • Power demand noise (±1%)
  • Rare (0.1-0.3%) false-positive detections
▸ Quiescent windows:
  • Nocturnal 23:00-06:00
  • Diurnal 09:00-17:00

Require Structured Output:

Mandatory Header Row:|trigger_time|causing_vector|event_place|transduction_type|origin_sensor|celsius_value|relative_saturartion_vector|locattrigger_time|causevent_place|transorigin_sensoriecⅰtrigger_ⅱsubject_status|

Submission Includes:
① Selection of paradigmatic example events
② Complete synthetic simulation continuing the activity trace
"""),
    AIMessagePromptTemplate.from_template("prompt")
])