var_9 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
First, create 2-3 prototype sensor events that accurately capture typical household behavior within the specified time windows.
Using these prototypes as a foundation, expand your generation to create a comprehensive, logically consistent sequence of sensor events.
Maintain realistic transitions between states while incorporating natural fluctuations in sensor readings and event timing.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Resident Behavior Simulation Setup

Home Layout & Devices:

**Living Area (9m² core space)**:
- Motion detection at entrance (zone_1_motion)
- Entertainment system <smart_tv_lounge>
- Ambient lighting control (light_zone_1)
- Climate sensor (temp_zone_1)
- Secure entry (front_door_lock)

**Sleeping Quarter (9m² private space)**:
- Bed motion tracker (bed_occupancy)
- Reading light (light_zone_2)
- Microclimate monitor (temp_zone_2)

**Food Preparation Area (2.16m²)**:
- Refrigeration sensor (temp_zone_3)
- Task lighting (light_zone_3)
- Appliance monitor (fridge_power)

Space Connections:
   Sleeping   Living
   Living   Food Prep + Hygiene

Occupant Patterns:

*Primary Resident*:
  - Rise: 0600
  - Departure: 0800
  - Return: 1700
  - Rest: 2230

*Secondary Resident*:
  - Rise: 0700
  - Departure: 0900
  - Return: 1800
  - Rest: 2300

Environmental Context:
- Season: Southern Winter <Brazilian June>
- Indoor thermal range: 21-26°C
- Hydration index: 40-70% (inverse thermal relationship)

Data Generation Protocol:

1. Create 2-3 seed events demonstrating natural <0600-0900> or <1700-2230> behaviors
2. Use seed events to build extended synthetic data
3. Ensure temporal, correlational, and behavioral fidelity
4. Introduce organic variations in intervals and readings

Sensor Interactions:
- Movement → Thermal shift (0.5-1.5°C per 15-30min)
- Activation → Energy spike (100-300W instant)
- Temperature-Humidity: -0.7 to -0.9 correlation
- Realistic measurement variance:
  - Thermal ±1.1°C
  - Power ±9%
  - ERS (0.1-0.3% false motion)

Quiet Periods:
- Night: 2300-0600 (resting)
- Day: 0900-1700 (unoccupied)

Output Schema:

CSV header <include all fields>:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Present both:
- Initial behavioral prototypes
- Complete simulation run
"""),
    AIMessagePromptTemplate.from_template("prompt")
])