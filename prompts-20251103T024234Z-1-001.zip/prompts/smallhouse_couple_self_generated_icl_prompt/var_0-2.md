var_2 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
First create 2-3 realistic sensor event sequences that showcase typical home automation interactions for the given situation.
Then expand these anchor examples into a comprehensive timeline that maintains situational logic and environmental constraints.
Insert natural deviations while preserving realistic device coordination patterns.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Residential Environment Profile

- Property Specifications:
  • Compact metropolitan residence (~60m² total)
  
- Room Breakdown & Smart Devices:

  【Lounge Area】
  - Dimensions: 3×3m zone
  - Sensors:
    ➤ Movement detector (ID: motion_lounge)
    ➤ Temperature probe (ID: temp_lounge)
  - Controlled devices:
    ➤ Connected television
    ➤ Smart bulb cluster (3 bulbs)
    ➤ Main entrance lock system

  【Sleeping Quarters】
  - Dimensions: 3×3m private space
  - Equipment:
    ➤ Presence detector
    ➤ Ambient temperature gauge
    ➤ Smart lighting fixture

  【Food Preparation Zone】
  - Dimensions: 1.8×1.2m workspace
  - Monitoring:
    ➤ Temperature tracker
    ➤ Smart refrigerated appliance controller
    ➤ Brightness adjusting luminaire

- Physical Connections:
  • Bedchamber ↔ Main living space
  • Lounge ↔ Nutrition area & Hygiene chamber

- Human Elements:

  【Primary Occupant】
  - Circadian pattern:
    ↑ 06:00 activation
    ← 08:00 departure
    → 17:00 return
    ↓ 22:30 repose

  【Secondary Resident】
  - Daily cadence:
    ↑ 07:00 arousal
    ← 09:00 exit
    → 18:00 homecoming
    ↓ 23:00 cessation

- Climate Context:
  • Seasonal: Southern hemisphere winter (June)
  • Interior thermal bounds: [21.0, 26.0]°C ±0.15 variance
  • Comparative sensor relationships:
     ↓Temperature →↑Moisture (r ≈ -0.8)
     Movement →↑Energy use (100W baseline + behavior flux)

Execution Plan:

Phase I: Create 3 prototype event chains representing authentic morning or evening routines (06:00-09:00 or 17:00②②:30)
Phase II: Develop an extended event stream continuing these demonstrated behaviors with:
  • Appropriate temporal distribution
  • Non-mechanical irregularity
  • Real-world perception behavior
  • Physical space transitions

Industrial-grade Constraints:

◈ Thermal inertia lead time: 20-45 minutes between sensor states
◈ Artifacts include:
   • Humidity inverse behavior (-.05 per .1°C↑)
   • Background perception misses (p=0.002)
   • Measurement variations (±.14°C/±14RH%/±13W)
◈ Blackout periods strictly enforced
◈ No device coordination beyond realistic home behavior

Delivery Protocol:

Required schema heading:
time_attribute,event_key,zone_code,interaction_category,activation_trigger,thermal_read,humidity_read,kinetic_state,human_presence,illumination_value,power_draw,ambient_noise,air_metric,access_state,transparency_status

Must contain:
1. Your high-fidelity prototype entries
2. The expanded full-feature data projection"""),
    AIMessagePromptTemplate.from_template("prompt")
])