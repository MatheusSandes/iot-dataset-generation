var_4 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Generate diverse yet realistic synthetic smart home datasets for the scenario below. 
Produce several variations that creatively differ in temporal patterns, sensor interactions, 
and resident behaviors while strictly adhering to all specified constraints. 
After internal evaluation, output only the single most plausible dataset 
that demonstrates cohesive home automation dynamics and believable resident activities.
"""),
    HumanMessagePromptTemplate.from_template(r"""
SMART HOME PROFILE

Location Type: Compact urban residence (42m² total)

Room Configurations:

‣ MASTER BEDROOM (Bedroom1):
  ■ Dimensions: 3m × 3m
  ■ Sensors: 
    → Motion_BR1 (ceiling-mounted)
    → Thermo_BR1 (wall-mounted)
    → RGB_Light_BR1 (dimmable)
  
‣ SECOND BEDROOM (Bedroom2):
  ■ Identical layout to Bedroom1
  ■ Sensor Prefix: BR2_

‣ CENTRAL LIVING SPACE:
  ■ Includes: 
    → 360° Motion_LR
    → Climate_LR sensor
    → Entertainment: SmartTV (55")
    → Main lighting: LED_LR
    → Digital Deadbolt

‣ KITCHENETTE:
  ■ Compact: 1.8m × 1.2m
  ■ Appliances:
    → Climate_KT
    → Under-cabinet lighting
    → SmartPlug (refrigerator)

Resident Patterns:

☀ Morning Phase:
- 06:00-07:00: Resident1 active solo
- 07:00-09:00: Both residents preparing
- 09:00-17:00: Home unoccupied

🌙 Evening Phase:
- 17:00-18:00: Resident1 returns
- 18:00-22:30: Evening routines
- 22:30-23:00: Resident2 retires later

Technical Constraints:

▸ Sensor Relationships:
- Motion → Light activation (1-3s delay)
- Thermostat → Maintain 20-23°C daytime
- Humidity inversely tracks temp (r=-0.8±0.05)

▸ Realistic Artifacts:
- Temperature ±0.3°C sensor noise
- Occasional motion false positives
- Power fluctuations up to 15%

▸ Temporal Requirements:
- No phantom nighttime activities
- Minimal midday events
- Asynchronous wake/sleep patterns

Output Structure:

Begin with CSV header:
timestamp,device_id,room,event_type,sensor_origin,temp_C,humidity_pct,motion_state,occupancy,light_pct,power_W,sound_db,air_quality_idx,door_state,window_state

Then provide the optimized dataset.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])