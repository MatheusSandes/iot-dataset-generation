
var_5 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Generate diverse synthetic datasets for the smart home scenario below, iteratively refining for optimal realism.
Create 10 distinct variations that subtly differ in temporal patterns, device interactions, and environmental fluctuations.
After internal quality assessment, output ONLY the most plausible dataset that best fits real-world residential dynamics.
"""),
    HumanMessagePromptTemplate.from_template(r"""
SMART HOME SIMULATION PARAMETERS

* Residence Profile: 
Terraced urban dwelling containing light + environmental sensor network
8m ceiling height across all monitored spaces

* Monitored Zones & Equipment:

▲ Primary Suite (BR1):
- motion_d1: PIR sensor (120° FOV)
- ambient_B1: environmental monitor
- ceiling_LED1: dimmable smart light

▲ Secondary Bedroom (BR2):
- presence_S2: mmWave sensor
- thermo_N2: triple-sensor array
- accent_L2: smart bulb system

◉ Great Room (LR):
Day/Night light control setup with:
- occupancy_LR
TranscriptTemp-lib
IP camera (disabled)
Illoom light system
Security deadbolt

△ Cooking Area:
3-zone temperature monitoring
Snap light + refrigerator monitor
Ground-level leakage detector

■ Utility Node:
Basement entry motion alert
Machinery space air quality tracker

〘 Unmonitored Areas 〙
Half-bath + closet space

† Residential Patterns:
* Adult A (Day worker):
05:45 wake | 07:15 depart
17:45 arrive | 01:30 deep sleep
* Adult B (Shift worker):
Day 1: 09:00-21:30 active
Day 2: 13:00-normal cycle
(Synchronized sleep in master)

⌚ Device Activation Schedule:
▸ 05:45-07:15 Dual occupation
▸ 07:15-09:00 Solitary mode
▸ 09:00-Dark: Conditional empty
▸ Evening triple-blend mode
▸ Sleep-phase cooldown after 00:00

PHYSICAL SYSTEM CONSTRAINTS:

● MOTION → light (instant 74-86% draw)
● Δ1°C air → 2.17% humidity swing (~12min lag)
● Action-blanked periods:
1900 light-EMPTY
0000 deep-sleep mode enable
● Environmental noise model:
Temp ±0.33K sigma
Load ±8% rating tolerance
Security false positive (<0.45%)
Mutual device interference contours

REQUIRED OUTPUT FORMAT:

Initiate with metadata header:

timestamp(SES),event_MAC,geo_tag,trigger_class,sensor_ID,baseline_tmp,RH%,trace_movement,resident_count,photometric_state,instant_wattage,acoustic_db,SDS011_index,binary_access,binary_egress

Then provide RAW observational datestamp values.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])