
var_6 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Generate multiple plausible synthetic home automation datasets for the given scenario.
Create variations that differ in timing patterns, sensor activation sequences, and environmental fluctuations,
while strictly adhering to all specified constraints.
After internal evaluation, output only the single most coherent and realistic dataset version,
excluding any intermediate versions or generation rationale.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Home Automation Scenario Specification

- Dwelling: Compact 2-bedroom urban residence with smart systems

- Sensor Network:

  • Master Bedroom (3x3m):
    - motion_detector_mbr
    - thermostat_mbr
    - lighting_control_mbr

  • Guest Bedroom (3x3m):
    - occupancy_sensor_gbr
    - temp_sensor_gbr
    - dimmable_lights_gbr

  • Common Areas:
    - Living Space (3x3m):
      * presence_detector_liv
      * climate_sensor_liv
      * entertainment_system
      * ambient_lighting_liv
      * entry_lock_system
    
    - Cooking Area (1.8x1.2m):
      * thermal_sensor_kit
      * task_lighting_kit
      * appliance_monitor_fridge

    - Utility Zone:
      * motion_util
      * temp_util

- Spatial Connections:
  - MasterBedroom ↔ LivingSpace
  - GuestBedroom ↔ Bath ↔ Utility ↔ Kitchen
  - LivingSpace ↔ Kitchen

- Occupants:
  • Primary: Awake 06:00-22:30 | Commute 08:00-17:00
  • Secondary: Awake 07:00-23:00 | Commute 09:00-18:00
  • Shared sleeping in Master Bedroom

Activity Timeline:
06:00-08:00   Dual activity
08:00-09:00   Sole secondary occupant
09:00-17:00   Unoccupied
17:00-18:00   Sole primary occupant
18:00-22:30   Dual activity
22:30-23:00   Sole secondary occupant
23:00-06:00   Sleep period

Technical Parameters:

- Motion → Temperature (Δ0.5-1.5°C per 15-30min)
- Motion → Power draw (instant 100-300W surge)
- Thermal-Hygrometric correlation: -0.7 to -0.9
- Realistic signal noise:
  - Temp: ±0.1°C variation
  - Power: ±11% fluctuation
  - Motion: 0.1-0.3% false positives
- Quiescent periods:
  • 09:00-17:00 (away)
  • 23:00-06:00 (sleeping)
- Natural timestamp distribution

Output Structure:

Begin with header row:
timestamp,event_id,zone,event_category,initiating_sensor,temperature,relative_humidity,motion_state,occupancy_count,illumination_level,energy_usage,acoustic_level,air_quality_index,entryway_state,fenestration_status

Follow with the optimal dataset selection.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])