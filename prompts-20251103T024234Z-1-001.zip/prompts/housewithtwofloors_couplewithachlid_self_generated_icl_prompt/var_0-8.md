var_8 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are an advanced home automation simulator with contextual learning capabilities.
First generate internal reference scenarios based on the family routines and device setup.
Use these scenarios to inform your final output without displaying them.
Only provide the completed dataset at the end.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Household Dynamics Configuration

- Resident Patterns:

  ▸ Parent A: 
    ↑ 06:00 | Depart 08:00 | Home 17:00 | ↓ 22:30
  ▸ Parent B: 
    ↑ 07:00 | Depart 09:00 | Home 18:00 | ↓ 23:00
  ▸ Children (2): 
    ↑ 06:30 | School 07:30 | Home 17:30 | ↓ 21:30

- Property: Modern two-level connected residence

- Smart Ecosystem:

  ■ Primary Bedroom:
    • movement_tracker_main, climate_node_main, illumination_main, entertainment_main

  ■ Child Room 1:
    • presence_sensor_room1, thermal_node_room1, lighting_room1, media_room1

  ■ Child Room 2:
    • presence_sensor_room2, thermal_node_room2, lighting_room2

  ■ Common Areas:
    • motion_detector_lounge, climate_monitor_lounge, ambience_lounge, entertainment_lounge, entry_system

  ■ Food Prep Zone:
    • temp_sensor_cooking, illumination_cooking, appliance_control_fridge

  ■ Utility Zone:
    • motion_detector_utility, temp_sensor_utility

- Network Topology:
  - Living   Kitchen   Utility   Laundry
  - Living   BathroomA
  - Living   Stairwell   Hallway   Sleeping Quarters   BathroomB   WC

Internal Context Models (not shown):

¤ Dawn Sequence:
  06:05—06:45 movement cascade begins in main suite
  Thermal adjustments follow movement (+0.7°C/10min)
  Power surge from idle to active devices (75W→250W)

¤ Evening Transition:
  17:20—18:30 staggered returns with distinct room activations
  Illumination patterns follow occupant paths
  Entry/exit events with security state changes

Data Generation Principles:

- Morning activity peaks (06:00-08:30, multiple zones)
- Daytime dormancy (09:30-16:45 minimal events)
- Afternoon reactivation sequence (17:15-19:00)
- Nighttime quiescence (post 23:15)
- Introduce realistic temporal jitter (±7 minutes)
- Maintain device interaction causality

System Parameters:

» Motion→Climate: Δ0.6-1.7°C over 12-35 minutes
» Presence→Energy: 50-350W instantaneous change
» Climate Coupling: Humidity -0.6 to -0.95
» Error Margins: 
   Temp (10.2°C±0.8) | Power (12%±1.3) 
   False positives: 0.15-0.4%

Output Specification:

Mandatory header row (verbatim):
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Generate comprehensive dataset adhering to above parameters.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])