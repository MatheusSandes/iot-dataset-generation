
var_2 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are an advanced home automation simulator with contextual generation capabilities.
First generate silent reference examples to understand the household dynamics,
then use this internal context to create a comprehensive dataset.
Output only the final data with precision and realistic patterns.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Household Configuration Profile

- Resident Timeline Matrix:

  ▸ Primary Adult: 
    Activates 06:00 | Commutes 08:00–17:00 | Rest period 22:30  
  ▸ Secondary Adult: 
    Activates 07:00 | Commutes 09:00–18:00 | Rest period 23:00  
  ▸ Minors (2):
    School schedule 06:30–17:30 | Sleep cycle 21:30

- Dwelling Structure: Urban two-level connected residence

- Device Matrix:

  • PrivateZone_Master:
    - presence_detector, thermal_sensor, adaptive_lighting, entertainment_display

  • PrivateZone_Child1:
    - presence_detector, thermal_sensor, adaptive_lighting, entertainment_display

  • PrivateZone_Child2:
    - presence_detector, thermal_sensor, adaptive_lighting

  • SocialZone_Main:
    - presence_detector, thermal_sensor, adaptive_lighting, entertainment_display, entry_control

  • UtilityZone_Kitchen:
    - thermal_sensor, adaptive_lighting, appliance_regulator

  • ServiceZone:
    - presence_detector, thermal_sensor

- Spatial Connectivity:
  - SocialZone ↔ UtilityZone ↔ ServiceZone ↔ TechnicalZone
  - SocialZone → HygieneZone1
  - SocialZone → VerticalAccess → TransitionSpace → [PrivateZones, HygieneZone2, SanitationZone]

Reference Patterns (internal modeling):

- Pattern Alpha:
  06:05 — PrivateZone_Master: presence → thermal delta (+0.8°C) → illumination activation

- Pattern Beta:
  17:40 — PrivateZone_Child2: entry detection → illumination sequence

- Pattern Gamma:
  22:45 — System-wide: energy conservation mode activation

Dataset Specifications:

- Capture morning multi-zone activation sequences
- Minimal activity during 09:00–17:00 window
- Phase return sequence: minors (17:30) → adults (18:00)
- Noise floor implementation post-23:00
- Integrate natural timestamp offsets and cross-sensor correlations

Data Relationships:

- Presence → Thermal (Δ0.7–1.6°C over 12–25 min)
- Presence → Energy (150–350W immediate)
- Temp ∝ Humidity: -0.68 to -0.92
- Sensors: Threshold variance ±11% | False positive rate 0.08–0.25%

Output Structure:

Mandatory initial header (exact copy):
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Proceed with dataset generation using understood patterns.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])