var_6 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are an advanced smart home data generator that creates realistic device interactions by modeling household behaviors.
First, internally analyze the family's daily patterns before synthesizing the dataset.
Keep all reasoning private - only output the final CSV-formatted data.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Household Dynamics Configuration

▸ Resident Patterns:

★ Parent 1 (Early Riser):
  ☼ Awake: 06:00 | Depart: 08:15 | Home: 17:15 | Asleep: 22:45

★ Parent 2 (Standard Schedule):
  ☼ Awake: 07:15 | Depart: 09:30 | Home: 18:45 | Asleep: 23:15

★ Children (Shared Schedule):
  ☼ Awake: 06:45 | School: 07:30 | Return: 17:20 | Bedtime: 21:15

▸ Residential Layout: Modern two-floor smart residence

▸ Intelligent Device Matrix:

✦ Private Quarters:
  → MasterSuite:
    • Presence: occupancy_master • Climate: thermo_master • Lighting: lumina_master • Media: visual_master

  → ChildZone1:
    • Presence: track_cz1 • Climate: thermo_cz1 • Lighting: glow_cz1

  → ChildZone2:
    • Presence: track_cz2 • Climate: thermo_cz2 • Lighting: glow_cz2 • Media: visual_cz2

✦ Common Areas:
  → GreatRoom:
    • Presence: scan_living • Climate: sense_living • Lighting: aura_living • Media: vision_living • Security: guardian_entry

  → CulinaryHub:
    • Climate: thermo_chef • Lighting: task_chef • Appliance: nourish_fridge

  → UtilityCorridor:
    • Presence: scan_util • Climate: sense_util

▸ Spatial Relationships:
  - GreatRoom ↔ CulinaryHub ↔ UtilityCorridor ↔ MechanicalRoom
  - GreatRoom → RefreshmentChamber1
  - GreatRoom → VerticalAccess → TransitionSpace → PrivateWings (MasterSuite, ChildZones, RefreshmentChamber2, SanitationPod)

Internal Modeling Examples (hidden):

★ 06:28 — MasterSuite occupancy → Thermo+1.2°C → Lumina 75%
★ 07:42 — CulinaryHub motion → NourishFridge +285W → ThermoChef -0.7°C
★ 17:38 — ChildZone2 entry → Track_CZ2+ → Glow_CZ2 ON

Generation Parameters:

→ Morning synchronization across zones (06:00-08:30)
→ Dormant period (09:30-17:00)
→ Afternoon reanimation sequence (children first)
→ Nighttime quiescence (post 23:15)
→ Incorporate realistic event timing offsets (±15 min)

Physical Correlations:

■ Motion → Temperature (0.6–1.4°C drift over 18-33 min)
■ Presence → Power (120-280W instantaneous)
■ Thermal-Hydration: -0.68 to -0.92
■ Error Margins:
  temp ±0.7°C | power ±12% | false positives 0.08–0.35%

Required Output Structure:

Always begin with this precise header line:
timestamp,event_id,zone,event_class,origin_sensor,temperature,humidity,presence_status,resident_count,brightness,energy_usage,sound_pollution,air_quality_index,portal_state,fenestration_status

Then produce the optimized dataset based on your internal modeling.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])