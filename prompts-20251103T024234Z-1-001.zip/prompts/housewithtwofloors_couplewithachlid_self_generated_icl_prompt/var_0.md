```python
var_0 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a smart home simulator capable of self-generating examples.
Before producing the final dataset, you will create a few relevant examples based on the current household configuration.
Use these examples as internal context to structure the final dataset.
Only output the final dataset.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Scenario Configuration

- Family Composition:

  • Adult 1: wakes 06:00, leaves 08:00, returns 17:00, sleeps 22:30  
  • Adult 2: wakes 07:00, leaves 09:00, returns 18:00, sleeps 23:00  
  • Child 1 and Child 2: wake 06:30, leave 07:30, return 17:30, sleep 21:30

- House Type: Two-story urban smart home

- Devices by Room:

  • MasterSuite:
    - motion_sensor_suite, temp_sensor_suite, smart_light_suite, smart_tv_suite

  • Bedroom1:
    - motion_sensor_bedroom1, temp_sensor_bedroom1, smart_light_bedroom1, smart_tv_bedroom1

  • Bedroom2:
    - motion_sensor_bedroom2, temp_sensor_bedroom2, smart_light_bedroom2

  • LivingDining:
    - motion_sensor_living, temp_sensor_living, smart_light_living, smart_tv_living, smart_lock_front

  • Kitchen:
    - temp_sensor_kitchen, smart_light_kitchen, smart_plug_fridge

  • ServiceArea:
    - motion_sensor_service, temp_sensor_service

- Connectivity:
  - LivingDining   Kitchen   ServiceArea   UtilityRoom
  - LivingDining   Bathroom1
  - LivingDining   Stairs   Circulation   MasterSuite, Bedroom1, Bedroom2, Bathroom2, WC

Self-Generated Examples (internal, do not output):

- Example 1:
  timestamp: 06:15 — motion in MasterSuite   temperature rise   light turns on

- Example 2:
  timestamp: 07:00 — motion in Kitchen   power to smart_plug_fridge   temp adjusts

- Example 3:
  timestamp: 17:35 — child enters Bedroom2   motion detected   light on

Dataset Guidelines:

- Reflect morning concurrency across rooms (bedrooms, kitchen)
- Inactivity from 09:00 to 17:00
- Children return first (17:30), followed by adults
- Quiet after 23:00
- Include natural timestamp variation and event correlation

Correlations and Noise:

- Motion     Temperature (0.5–1.5°C in 15–30 min)
- Motion     Power (100–300W instantly)
- Temp   Humidity: -0.7 to -0.9
- Temp 'b10.1°C | Power 'b11% | Motion FP: 0.1–0.3%

Output Format:

Begin with this exact header:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Then generate the dataset informed by your self-generated context.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])
```