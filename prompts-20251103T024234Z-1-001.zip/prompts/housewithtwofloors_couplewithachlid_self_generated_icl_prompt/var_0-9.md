var_9 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You're an advanced domestic activity generator modeling real-world smart home behaviors.
First, mentally simulate implicit routines following the given household configuration.
Use this simulation to create representative events before constructing the output dataset.
Never display your preparatory analysis - only provide the final formatted data.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Household Dynamics Configuration

- Resident Patterns:

  » Primary Caregiver: rises 05:45, departs 08:15, home by 16:45, retires 22:15  
  » Secondary Caregiver: rises 06:30, departs 09:15, home by 17:30, retires 23:15  
  » Dependents (2): rise 07:00, depart 08:00, return 16:15, bedtime 20:45

- Dwelling: Three-level smart-enabled townhouse with basement

- Enabled Devices:

  » MasterLevel:
    - presence_grid_master, climate_module_master, luminance_panel_master, smart_glass_master

  » JuniorRoomA:
    - proximity_array_roomA, thermoregulator_roomA, illumination_ring_roomA

  » JuniorRoomB:
    - proximity_array_roomB, thermoregulator_roomB, daylight_ring_roomB

  » SocialHub:
    - spatial_scanner_lounge, ambient_module_lounge, lighting_array_lounge, media_wall_lounge, e-latch_entry

  » FoodPrepZone:
    - thermal_grid_kitchen, smart_illuminators_kitchen, appliance_monitor_fridge

  » ServicePerimeter:
    - area_scanner_service, thermal_node_service

- Spatial Relationships:
  - SocialHub ↔ FoodPrepZone ↔ ServicePerimeter ↔ TechnicalSpace
  - SocialHub ↔ SanitationModule1
  - SocialHub ↔ VerticalAccess ↔ TransitZone ↔ MasterLevel ↔ JuniorRoomA ↔ JuniorRoomB ↔ SanitationModule2 ↔ WC

Cognitive Simulation (hidden pre-processing):

¤ Simulated Sequence 01:
  temporal marker: 05:50 — thermal shift in MasterLevel ≈ +1.2°C → illumination rise

¤ Simulated Sequence 02:
  temporal marker: 08:05 — appliance_monitor_fridge power flux → FoodPrepZone thermal adjustment

¤ Simulated Sequence 03:
  temporal marker: 16:20 — movement in JuniorRoomB → illumination response

Generation Parameters:

- Model morning activity overlap across private/social zones
- Dormant phase between 09:15-16:15
- Youth return precedes adult arrivals
- Silent mode activates post 23:15
- Introduce natural temporal offsets and sensor interdependencies

Cross-Sensor Relationships:

- Presence ≈ Thermal shift (0.4–1.8°C over 10–25 min)
- Movement ≈ Energy spike (80–350W instantaneous)
- Temp ≈ Humidity: -0.6 to -0.8 correlation
- Thermals &10.5°C | Load variances &15% | False detection range 0.05–0.4%

Required Output Schema:

Initiate with this precise header row:
timestamp,event_id,zone,event_category,origin_sensor,thermal_read,humidity_factor,movement_state,resident_count,luminosity_index,energy_draw,acoustic_level,atmospheric_quality,portal_state,aperture_status

Then produce the dataset informed by your internal simulation.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])