var_1 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Generate authentic smart home sensor data by first producing representative examples that capture the household's behavioral patterns.
After establishing these baseline scenarios, extend the dataset to include a complete day of consistent, correlated events that follow physical realities and resident interactions.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Residence Profile:

Property Type: Compact city apartment (55m²)

Device Network:

- Master Bedroom (10m²):
  ✧ room_presence_main
  ✧ thermal_sensor_main
  ✧ dimmable_bulb_main

- Child's Room (9m²):
  ✧ junior_motion_detector
  ✧ climate_sensor_junior
  ✧ junior_smart_lamp

- Common Spaces:
  ✓ Lounge Area (12m²):
    • living_zone_sensor
    • ambient_thermometer
    • entertainment_system
    • accent_lighting
    • front_entry_system
    • room_energy_monitor

  ✓ Cooking Area (4m²):
    • cooking_thermostat
    • kitchen_illumination
    • refrigerator_monitor

  ✓ Utility Zone:
    • back_motion_detector
    • utility_temp_gauge

Occupant Schedules:
- Parent 1: Rises 06:15 | Departs 07:45 | Home 16:45 | Retires 22:45  
- Parent 2: Rises 07:15 | Departs 09:15 | Home 18:15 | Sleeps 23:30  
- Young Resident: Awake 06:45 | School Depart 07:30 | Return 15:30 | Bedtime 21:30  
- Sleeping Quarters: Parents in Master, child in Junior

Creation Guidelines:
1. Establish 2-3 prototype events demonstrating inter-device relationships
2. Extend timeline with 15+ events showing:
   • Sequential movement patterns
   • Environmental feedback loops
   • Power consumption interactions

Physical Constraints:
- Warmth Fluctuation | 0.4–1.7°C per 12–30 minute interval
- Presence ⇒ Energy Spikes | 80–320W immediate
- Warm-Cool | Dampness Ratio: -0.65 to -0.95
- Natural Variance:
  ✓ Climate readings ±0.2°C
  ✓ Power ±9%
  ✓ Presence false-positives <0.35%
- Quiet Hours:
  ✘ 09:15-16:45 (vacant)
  ✘ 23:30-06:15 (resting)

Delivery Specification:

Headers:
recorded_time,event_uid,zone,activity_category,sensor_origin,ambient_temp,moisture_level,space_activity,person_count,brightness_index,energy_usage,acoustic_level,aeration_state,access_position

Process:
1. Display 2-3 signature occurrences
2. Output developed event chronology
"""),
    AIMessagePromptTemplate.from_template("prompt")
])