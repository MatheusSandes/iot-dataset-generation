
var_7 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Generate synthetic smart home data that follows realistic patterns for the specified household scenario.
First create 3 representative sample events that demonstrate typical interactions.
Then expand these into a comprehensive dataset maintaining proper temporal sequences and inter-sensor relationships.
"""),
    HumanMessagePromptTemplate.from_template(r"""
## Home Configuration

### Property Layout
- Type: Compact urban apartment
- Occupancy: 2 adults (primary bedroom), 1 child (secondary bedroom)

### Smart Devices
**Primary Bedroom (3x3m)**
- motion_primary_bed
- temp_primary_bed  
- dimmer_light_primary  

**Child's Bedroom (3x3m)**
- motion_child_room  
- temp_child_room  
- basic_light_child  

**Common Areas**
- Living Room (4x3m):
  - motion_living  
  - main_thermostat  
  - entertainment_system  
  - front_door_lock  

- Kitchen (2.5x1.5m):
  - fridge_power_monitor  
  - kitchen_temp  
  - overhead_light  

### Daily Routines
**Adult 1**  
06:00 Wake | 07:30 Depart | 17:00 Return | 22:30 Sleep  

**Adult 2**  
07:00 Wake | 08:30 Depart | 18:00 Return | 23:00 Sleep  

**Child**  
06:30 Wake | 07:15 Depart | 16:30 Return | 21:45 Sleep  

## Data Generation Rules

### Sensor Relationships
- Movement → Lighting (80-100% activation)
- Occupancy → Thermostat adjustment (Δ0.8-1.2°C/hour)
- Evening activity → Power surge (175-400W)

### Environmental Settings
- Temp-Humidity: -0.85 correlation
- Baseline noise:  
  - Temperature: ±0.3°C  
  - Power: ±7% variance  
  - 0.2% false motion triggers  

### Quiet Periods
- Unoccupied: 09:00-16:00
- Sleep: 23:30-05:30

Output Specifications:
timestamp,event_id,room,device_type,activated_sensor,temp_read,rel_hum,motion_state,resident_presence,light_pct,power_watts,sound_db,air_score,entry_status,window_state

1. Provide 3 initial prototype events
2. Extend with 15+ sequential records
"""),
    AIMessagePromptTemplate.from_template("prompt")
])