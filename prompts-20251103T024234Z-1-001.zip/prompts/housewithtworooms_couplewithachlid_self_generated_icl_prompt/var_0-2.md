var_2 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
First synthesize believable smart home sensor readings that reflect actual home dynamics for the given layout.
Generate initial event samples showing natural device interactions, then extend these patterns into a complete temporal sequence.
Only provide the final output starting with your seed examples followed by the complete synthetic trace.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Living Space Configuration

- Residence Type: Compact city apartment with two sleeping quarters

- Connected Device Mapping:

  • Primary Bedroom (3x3m):
    - presence_detector_master
    - thermal_sensor_master
    - adjustable_lamp_master

  • Secondary Bedroom (3x3m):
    - presence_detector_secondary
    - thermal_sensor_secondary
    - dimmable_lamp_secondary

  • Common Area (3x3m):
    - occupancy_sensor_commons
    - climate_sensor_commons
    - entertainment_system
    - illumination_commons
    - entry_security_commons

  • Food Prep Zone (1.8x1.2m):
    - climate_sensor_kitchen
    - task_lighting_kitchen
    - refrigerator_monitor

  • Utility Space:
    - motion_detector_utility
    - thermal_sensor_utility

- Spatial Connections:
  - MasterBedroom ↔ CommonArea
  - SecondaryBedroom ↔ HygieneRoom
  - HygieneRoom ↔ UtilitySpace ↔ FoodPrep
  - CommonArea ↔ FoodPrep

- Inhabitants:
  • Parent 1: rises 06:00, departs 08:00, re-enters 17:00, retires 22:30  
  • Parent 2: rises 07:00, departs 09:00, re-enters 18:00, retires 23:00  
  • Youth: rises 06:30, departs 07:30 for education, returns 17:30, sleeps 22:00  
  • Parents occupy MasterBedroom, youth in SecondaryBedroom

Production Guidelines:
1. Fabricate 3 prototype sensor activations demonstrating habitation patterns
2. Extend with 15-25 sequential events preserving cause-effect relationships
3. Ensure natural environmental progressions and device state transitions

Technical Specifications:

- Presence → Thermal (0.5–1.5°C drift per 15-30 min)
- Presence → Energy (instant 100-300W draw)
- Thermal-Humidity: inverse relationship (-0.7 to -0.9)
- Include realistic variances:
  - Thermal ±0.1°C
  - Energy ±12%
  - Presence false positives: 0.1-0.3%
- Omit events during:
  • 09:00–17:00 (unoccupied)
  • 23:00–06:00 (sleeping)

Data Structure:

Begin with header:
timestamp,event_id,zone,event_category,activated_sensor,thermal_reading,humidity_index,presence_state,occupancy_count,illumination_value,energy_usage,sound_level,atmosphere_quality,entry_state,portal_status

Then:
1. Show 3 prototype events (self-created)
2. Append full sequential dataset
"""),
    AIMessagePromptTemplate.from_template("prompt")
])