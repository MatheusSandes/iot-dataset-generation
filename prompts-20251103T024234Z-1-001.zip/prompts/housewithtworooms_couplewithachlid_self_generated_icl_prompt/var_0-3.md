
var_3 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Begin by crafting 2–3 representative smart home sensor events that logically fit the residential scenario provided. 
Using these as foundational examples, systematically expand to generate a comprehensive synthetic dataset that maintains:
- Temporal consistency with resident routines
- Physical correlations between sensor types
- Plausible environmental interactions
Only provide the complete dataset output starting with your initial seed examples.
"""),
    HumanMessagePromptTemplate.from_template(r"""
**Residential Smart Home Configuration**

**Property Details:**
- Layout: Compact urban dwelling (68 sqm total)
- Bedrooms: 2 (Primary: 9sqm, Secondary: 9sqm)

**Smart Device Network:**

**Primary Bedroom:**
- Motion Detector: bed1_motion
- Climate Monitor: bed1_temp
- Lighting Control: bed1_light

**Secondary Bedroom:**
- Motion Detector: bed2_motion
- Climate Monitor: bed2_temp
- Lighting Control: bed2_light

**Common Areas:**
- Living Space (9sqm):
  - Presence Sensor: living_motion
  - Thermal Sensor: living_temp
  - Entertainment: living_tv
  - Lighting: living_light
  - Security: front_lock

- Cooking Area (2.2sqm):
  - Climate: kitchen_temp
  - Lighting: kitchen_light
  - Appliance: fridge_plug

- Utility Zone:
  - Motion: utility_motion
  - Temperature: utility_temp

- Sanitation (2.4sqm): Unmonitored

**Spatial Connections:**
- Primary ↔ Living
- Secondary ↔ Sanitation ↔ Utility ↔ Cooking
- Living ↔ Cooking

**Occupant Patterns:**

│ Resident   │ Awake │ Depart │ Return │ Sleep │
│------------│-------│--------│--------│-------│
│ Parent 1   │ 06:00 │ 08:00  │ 17:00  │ 22:30 │
│ Parent 2   │ 07:00 │ 09:00  │ 18:00  │ 23:00 │
│ Dependent  │ 06:30 │ 07:30  │ 17:30  │ 22:00 │

**Sleep Arrangement:**
- Parents: Primary bedroom
- Child: Secondary bedroom

**Data Generation Protocol:**

1. Seed with 2–3 prototype events demonstrating correlational patterns
2. Extend with 15–25 contiguous events maintaining:
   - Thermodynamic consistency (±0.8°C/30min)
   - Occupancy-linked triggers
   - Device interaction logic
3. Apply naturalistic variations:
   - Sensor error margins (thermal ±0.3°C)
   - False activations (motion 0.2% probability)
   - Power surges (±12%)

**Temporal Restrictions:**
- Active hours: 06:00–23:00 (omit midday vacancy 09:00–17:00)
- Night quiet hours: 23:00–06:00 (minimal events)

**Output Specifications:**
CSV header:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Produce:
1. Initial seed events (2–3 rows)
2. Extended dataset sequence
"""),
    AIMessagePromptTemplate.from_template("prompt")
])