```python
var_0 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You will first generate a few in-context examples of realistic smart home sensor events for the scenario described.
Then, based on these examples, continue producing a full synthetic dataset that aligns with the routines, structure, and temporal logic of the household.
Only output the final dataset, starting with your self-generated examples followed by expanded data.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Scenario Configuration

- House Type: Small urban smart home with two bedrooms

- Devices by Room:

  • Bedroom1 (3m x 3m):
    - motion_sensor_bedroom1
    - temp_sensor_bedroom1
    - smart_light_bedroom1

  • Bedroom2 (3m x 3m):
    - motion_sensor_bedroom2
    - temp_sensor_bedroom2
    - smart_light_bedroom2

  • LivingRoom (3m x 3m):
    - motion_sensor_living
    - temp_sensor_living
    - smart_tv
    - smart_light_living
    - smart_lock_front

  • Kitchen (1.8m x 1.2m):
    - temp_sensor_kitchen
    - smart_light_kitchen
    - smart_plug_fridge

  • ServiceArea:
    - motion_sensor_service
    - temp_sensor_service

  • Bathroom (2m x 1.2m): no sensors

- Room Connections:
  - Bedroom1   LivingRoom
  - Bedroom2   Bathroom
  - Bathroom   ServiceArea   Kitchen
  - LivingRoom   Kitchen

- Residents:
  • Adult 1: wakes at 06:00, leaves at 08:00, returns at 17:00, sleeps at 22:30  
  • Adult 2: wakes at 07:00, leaves at 09:00, returns at 18:00, sleeps at 23:00  
  • Child: wakes at 06:30, leaves at 07:30 for school, returns at 17:30, sleeps at 22:00  
  • Adults sleep in Bedroom1, child in Bedroom2

Generation Instructions:
1. Create 2–3 initial sensor event rows consistent with the routines and correlations
2. Expand with 10–20 additional events that follow those patterns
3. Maintain coherent transitions and environmental dynamics

Technical Requirements:

- Motion     Temperature (0.5–1.5°C within 15–30 min)
- Motion     Power (100–300W instantly)
- Temperature   Humidity: correlation -0.7 to -0.9
- Add realistic noise:
  - Temp 'b10.1°C
  - Power 'b11%
  - Motion FP: 0.1–0.3%
- Avoid events during:
  • 09:00–17:00 (house empty)
  • 23:00–06:00 (asleep)

Output Format:

Start with:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Then:
1. Output 2–3 in-context examples (self-generated)
2. Follow with the full dataset expansion
"""),
    AIMessagePromptTemplate.from_template("prompt")
])
```