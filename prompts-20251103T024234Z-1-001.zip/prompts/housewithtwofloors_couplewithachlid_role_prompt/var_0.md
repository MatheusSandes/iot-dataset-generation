```python
var_0 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are acting as a Smart Home Behavior Analyst and Senior IoT Data Engineer.
Your task is to simulate a realistic synthetic dataset of sensor events for a two-story smart home.
You must take into account the daily routines of a typical working couple and their two school-aged children.
Ensure the output follows natural behavioral patterns and sensor correlation logic.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Scenario Configuration

- House Type: Two-story urban smart home

- Residents:

  • Adult 1: wakes at 06:00, leaves at 08:00, returns at 17:00, sleeps at 22:30  
  • Adult 2: wakes at 07:00, leaves at 09:00, returns at 18:00, sleeps at 23:00  
  • Child 1: wakes at 06:30, leaves at 07:30, returns at 17:30, sleeps at 21:30  
  • Child 2: wakes at 06:30, leaves at 07:30, returns at 17:30, sleeps at 21:30  

- Devices by Room:

  • MasterSuite:
    - motion_sensor_suite
    - temp_sensor_suite
    - smart_light_suite
    - smart_tv_suite

  • Bedroom1 (Child 1):
    - motion_sensor_bedroom1
    - temp_sensor_bedroom1
    - smart_light_bedroom1
    - smart_tv_bedroom1

  • Bedroom2 (Child 2):
    - motion_sensor_bedroom2
    - temp_sensor_bedroom2
    - smart_light_bedroom2

  • LivingDining:
    - motion_sensor_living
    - temp_sensor_living
    - smart_light_living
    - smart_tv_living
    - smart_lock_front

  • Kitchen:
    - temp_sensor_kitchen
    - smart_light_kitchen
    - smart_plug_fridge

  • ServiceArea:
    - motion_sensor_service
    - temp_sensor_service

- Room Connectivity:
  - LivingDining   Kitchen   ServiceArea   UtilityRoom
  - LivingDining   Bathroom1
  - LivingDining   Stairs   Circulation
  - Circulation   Bedroom1, Bedroom2, MasterSuite, Bathroom2, WC

Analyst Instructions:

- Simulate morning activity with overlapping motion in bedrooms, kitchen, and service area
- Ensure no activity from 09:00 to 17:00 (all away) until children return at 17:30
- Simulate natural power usage (TV, lights, fridge) in evenings
- Lights off and sensors quiet after sleep times
- Ensure realistic timestamp gaps and noisy but plausible sensor values

Correlations to Apply:

- Motion     Temp (0.5–1.5°C in 15–30 min)
- Motion     Power (100–300W instantly)
- Temp   Humidity: -0.7 to -0.9

Sensor Noise:

- Temp 'b10.1°C  
- Power 'b11%  
- Motion FP: 0.1–0.3%

Inactive Periods:

- 09:00–17:00 (empty)
- After 23:00 (asleep)

Output Format:

Start with this header:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Then provide the dataset based on your role as a smart home behavior analyst.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])
```