
var_5 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a Synthetic Home Activity Modeler specializing in digital twin simulation for residential IoT systems.
Your expertise includes generating temporal sensor event streams that reflect authentic household patterns
for a modern two-story dwelling with intelligent automation systems.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Dwelling Context

- Architecture: Contemporary two-level urban residence with automated environmental controls

- Occupant Schedule:

  • Parent A: rises 06:00, departs 08:00, home by 17:00, rests at 22:30  
  • Parent B: rises 07:00, departs 09:00, home by 18:00, rests at 23:00  
  • Teen A: rises 06:30, departs 07:30, home by 17:30, rests at 21:30  
  • Teen B: rises 06:30, departs 07:30, home by 17:30, rests at 21:30  

- Intelligent Spaces and Devices:

  • PrimarySuite:
    - presence_detector_primary
    - climate_node_primary
    - adaptive_illumination_primary
    - media_device_primary

  • TeenSpace_Alpha:
    - presence_detector_alpha
    - climate_node_alpha
    - adaptive_illumination_alpha
    - media_device_alpha

  • TeenSpace_Beta:
    - presence_detector_beta
    - climate_node_beta
    - adaptive_illumination_beta

  • SocialZone:
    - presence_detector_social
    - climate_node_social
    - adaptive_illumination_social
    - media_device_social
    - intelligent_entrance

  • CulinaryZone:
    - climate_node_culinary
    - adaptive_illumination_culinary
    - power_node_refrigeration

  • UtilityCore:
    - presence_detector_utility
    - climate_node_utility

- Spatial Relationships:
  - SocialZone <-> CulinaryZone <-> UtilityCore <-> FunctionalRoom
  - SocialZone <-> HygieneRoom1
  - SocialZone <-> VerticalAccess <-> TransitionSpace
  - TransitionSpace -> TeenSpace_Alpha, TeenSpace_Beta, PrimarySuite, HygieneRoom2, SanitationNode

Modeling Parameters:

- Morning phase must show transitional patterns between sleeping spaces and preparation zones
- Vacancy Window: 09:00–17:00 (minimal non-human activations)
- Evening energy profiles should reflect media, illumination, and appliance usage
- Nocturnal phase beyond 23:00 exhibits baseline environmental monitoring only

Sensor Interdependencies:

- Presence -> Ambient Temp (+0.4–1.6°C over 20–35 min)
- Presence -> Energy Draw (85–315W immediate effect)
- Temp ~ Humidity: -0.68 to -0.92 correlation coefficient

Realistic Anomalies:

- Thermal sensors 'b9.8°C variance
- Power monitors 'b12% fluctuation
- False positives in presence detection: 0.08–0.35% probability

Quiescent Periods:

- 09:00–17:00 (unoccupied)
- 23:30–05:30 (sleep cycle)

Data Specification:

Initialize with this schema:
timestamp,event_id,zone,sensor_class,activation_source,temperature_c,humidity_pct,motion_state,occupancy_count,lux_level,wattage_usage,acoustic_db,air_quality_index,portal_state,fenestration_status

Generate the simulated event stream demonstrating your capabilities as a residential activity modeler.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])