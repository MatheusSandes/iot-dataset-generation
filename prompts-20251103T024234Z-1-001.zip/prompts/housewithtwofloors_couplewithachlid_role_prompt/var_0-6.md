
var_6 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
As a Residential Activity Pattern Specialist and IoT Simulation Engineer,
your mission is to generate a highly realistic synthetic dataset representing
smart home interactions for a two-story suburban dwelling.
Model the behaviors and device interactions of a dual-income household
with two children, incorporating natural movement patterns and device correlations.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Dwelling Specifications:

- Property: Contemporary two-story suburban smart home
- Residents Profile (Monday-Friday):
   ◈ Parent A: Morning routine 06:15-08:15, Work absence 08:15-17:15, Evening 17:15-22:45
   ◈ Parent B: Morning routine 07:00-09:15, Work absence 09:15-18:15, Evening 18:15-23:15
   ◈ Teenager (14): Morning 06:45-07:45, School 07:45-15:45, Evening 15:45-22:00
   ◈ Child (10): Morning 06:30-07:30, School 07:30-15:30, Evening 15:30-21:15

Sensor Network Layout:

FIRST FLOOR:
■ Great Room Cluster:
   • ambient_sensor_living
   • presence_detector_living
   • iot_tv_living
   • smart_light_living
   • door_sensor_main

■ Culinary Zone:
   • thermo_sensor_kitchen
   • current_monitor_fridge
   • cabinet_motion_array
   • illumination_kitchen

■ Service Corridor:
   • utility_motion_sensor
   • boiler_temp_probe

SECOND FLOOR:
■ Primary Suite:
   • sleep_motion_array
   • climate_sensor_suite
   • dimmable_lights_suite
   • media_output_suite

■ Youth Chambers (East/West):
   • student_motion_detector
   • room_thermostat
   • task_lighting
   • (East only) entertainment_unit

Behavioral Simulation Guidelines:

1. Morning (06:00-09:15):
   - Layer concurrent bathroom use with staggered departures
   - Breakfast-related kitchen activity peaks 07:00-07:45

2. Daytime (09:15-15:30):
   - Maintain base load (refrigeration, boiler)
   - Random service visits (1-2 events total)

3. Afternoon/Early Evening (15:30-20:00):
   - Children return before parents
   - Multimedia/study activity gradients
   - Kitchen reactivation during dinner prep

4. Nighttime (After 22:00):
   - Progressive room deactivation
   - Only essential systems remain active

Physically Constrained Interactions:
◆ No concurrent use of non-adjacent rooms
◆ Occupancy follows room adjacency (see floorplan map at end)

Required Sensor Correlations:
□ Movement → Temperature: +0.25-1.75°C proportional to duration
□ Electronics → Power: Non-linear step changes (see curve reference)
□ Humidity follows inverse temp trend (R² ~ -0.82)

Environmental Noise Models:
• Temperature: ±0.15°C Gaussian noise
• Power: ±3% baseline fluctuation
• Motion: <0.2% false positives

Output Specification:
Begin with CSV header:
timestamp,zone,device_id,event_class,temperature,humidity,power_state,motion_flag,light_state,media_status,portal_state

Then generate 24-hour patterned activity data with rational transitions.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])