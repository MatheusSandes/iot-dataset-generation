
var_1 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are an Advanced Smart Home Simulation Expert specializing in realistic IoT data generation.
Your objective is to create a comprehensive synthetic dataset that accurately represents a two-story smart home's sensor network patterns.
The simulation must reflect the typical behaviors of a professional couple and their two children, including their weekday routines, interactions with devices, and environmental changes.
"""),
    HumanMessagePromptTemplate.from_template(r"""
SIMULATION PARAMETERS:

Property Details:
- Architecture: Modern two-story townhouse
- Climate Zone: Temperate Urban

Resident Profiles:
1. Parent A (Workday Schedule):
   │- Awake: 06:00 │ Depart: 07:45 │ Return: 17:15 │ Asleep: 22:15
2. Parent B (Workday Schedule):
   │- Awake: 06:30 │ Depart: 08:30 │ Return: 18:15 │ Asleep: 22:45
3. Child X (School Schedule):
   │- Awake: 06:15 │ Depart: 07:15 │ Return: 15:45 │ Asleep: 21:15
4. Child Y (School Schedule):
   │- Awake: 06:15 │ Depart: 07:15 │ Return: 15:45 │ Asleep: 21:15

IoT Deployment Map:

PRIMARY ZONES & SENSORS:
◆ Master Suite:
  - presence_detector_ms
  - climate_sensor_ms
  - ambient_light_ms
  - entertainment_unit_ms

◆ Kid's Room 1:
  - motion_array_k1
  - enviro_sensor_k1
  - learning_lights_k1

◆ Kid's Room 2:
  - motion_array_k2
  - enviro_sensor_k2
  - learning_lights_k2

◆ Common Areas:
  - omni_motion_living
  - smart_climate_living
  - adaptive_lighting_living
  - media_system_living
  - entry_system

◆ Utility Spaces:
  - kitchen_cluster
  - service_zone_sensors
  - hvac_monitors

Connectivity Pattern:
Living Core ↔ Kitchen Hub ↔ Service Wing
Living Core ↔ Washroom Complex
Living Core ↔ Central Staircase
Central Staircase ↔ All Bedrooms + Secondary Bath

SIMULATION GUIDELINES:

◆ Morning Sequence:
  - Simulate staggered wake-up patterns
  - Breakfast preparation traces in kitchen
  - School prep activities in bedrooms

◆ Daytime Pattern:
  - Minimal activity 08:30-15:45 (away period)
  - HVAC maintenance cycles only

◆ Evening Flow:
  - After-school routines starting 15:45
  - Family dinner preparation
  - Evening relaxation patterns
  - Gradual wind-down sequence

PHYSICAL CORRELATIONS:
¤ Motion → Temp Drift (0.4–1.6°C over 12-28 min)
¤ Presence → Energy Spike (90–350W immediate)
¤ Thermal-Humidity: -0.68 to -0.92 correlation

SENSOR REALISM FACTORS:
- Temperature: ±0.15°C variation
- Power: ±9% measurement noise
- False Alarms: 0.08–0.25% probability

QUIET PERIODS:
- 08:30-15:45 (occupant absence)
- Post 22:45 (sleeping phase)

DATA STRUCTURE REQUIREMENT:

Required Header Format:
timestamp,event_id,zone,sensor_class,temperature,humidity,presence_flag,light_state,energy_draw,sound_pressure,air_index,entry_status,portal_state

Generate the comprehensive dataset as an elite smart home simulation specialist.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])