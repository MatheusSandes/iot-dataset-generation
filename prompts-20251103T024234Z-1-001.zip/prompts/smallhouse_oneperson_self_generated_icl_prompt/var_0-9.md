
var_9 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Begin by crafting illustrative examples of IoT sensor data that accurately reflect the daily patterns described.
First produce 2-3 carefully constructed sample events that embody all scenario constraints.
Then use these exemplars to inform generation of a complete, temporally coherent dataset.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Configuration Blueprint

█ Residential Profile:
- Type: Compact urban dwelling (72m² total)
- Occupant: Single professional (30-40yo)
- Climate: Subtropical winter (Brazilian June)

█ Device Layout Matrix:

◆ Living Zone (9m²) ◆
✓ Presence: PIR_001
✓ Climate: TEMP_L1, HUM_L1
✓ Lighting: LED_L1
✓ Entertainment: TV_001
✓ Security: LOCK_MAIN

◆ Sleeping Zone (9m²) ◆
✓ Presence: PIR_B1
✓ Climate: TEMP_B1, HUM_B1
✓ Lighting: LED_B1

◆ Food Zone (2.16m²) ◆
✓ Climate: TEMP_K1
✓ Lighting: LED_K1
✓ Appliance: PLG_FRIDGE

◆ Hygiene Zone (2.4m²) ◆
✗ No monitoring

█ Temporal Patterns:
☀ Active Phases:
  06:00-08:00 (Morning routine)
  17:00-22:30 (Evening leisure)
💤 Quiet Periods:
  22:30-06:00 (Sleep)
  08:00-17:00 (Away)

█ Environmental Constraints:
- Thermal range: 21-26°C
- Moisture range: 40-70% RH (inverse thermal correlation)
- Event spacing: Natural human-paced intervals

Data Generation Protocol:

[Phase 1] Create 2-3 paradigmatic examples demonstrating:
- Realistic device interactions
- Physical constraints compliance
- Temporal plausibility

[Phase 2] Expand into full dataset maintaining:
- Consistent correlation patterns
- Physical parameter relationships
- Occupancy-linked behaviors

Validation Requirements:
✘ No events during sleep/away windows
✔ Thermal drift: 0.5-1.5°C per motion event
✔ Power spikes: 100-300W with activation
✔ RH-Temp anticorrelation: r=-0.7 to -0.9
✔ Measurement noise thresholds

Output Specification:

Mandatory header (exact):
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Deliverables:
1. Seed examples demonstrating system behavior
2. Complete chronologically ordered dataset
"""),
    AIMessagePromptTemplate.from_template("prompt")
])