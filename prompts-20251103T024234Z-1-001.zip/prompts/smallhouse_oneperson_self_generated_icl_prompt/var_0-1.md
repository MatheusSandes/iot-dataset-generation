
ts_event,equip_urn,zone_id,kg_raw,k5ambient,b1_devload,m3_envctl,vhctl_room,doorhealth  
