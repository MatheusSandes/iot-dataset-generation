var_3 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
First create 2-3 illustrative IoT data samples that showcase realistic sensor interactions.
Use these as exemplars to then produce an entire dataset following identical behavioral patterns.
Maintain strict alignment with device specifications, environmental conditions, and user activities.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Configuration Blueprint

- Residential Profile: Compact city apartment (50m²)
- Device Deployment:

  ■ Lounge Area (3.5m x 3.5m):
    ◦ Motion detector (motion_lounge)
    ◦ Entertainment system (smart_tv)
    ◦ Dimmable LED (light_lounge)
    ◦ Climate sensor (temp_lounge)
    ◦ Digital deadbolt (lock_main)

  ■ Sleeping Quarters (3m x 3m):
    ◦ Presence sensor (motion_bed)
    ◦ Smart lamp (light_bed)
    ◦ Thermal gauge (temp_bed)

  ■ Cooking Zone (2m x 1.5m):
    ◦ Temperature probe (temp_kitchen)
    ◦ Smart bulb (light_kitchen)
    ◦ Energy monitor (plug_fridge)

- Spatial Layout:
  - Bedroom ↔ Living Room
  - Living Room → Kitchen & Bath

- Occupant Details:
  - Solo professional resident
  - Active hours: 06:15–08:15 & 18:00–23:00
  - Absent period: 08:15–18:00
  - Rest cycle: 23:00–06:15

- Climatic Conditions:
  - July winter season (Southern Hemisphere)
  - Interior range: 20–25°C
  - Moisture levels: 45–75% (negative thermal relationship)

Generation Protocol:

1. Produce 2-3 paradigmatic sensor event samples
   - These will establish behavioral baselines
2. Expand into complete dataset using established norms
3. Strictly enforce:
   - Activity blackout windows (23:00–06:15, 08:15–18:00)
   - Physical correlations:
     • Motion → Temp shift (0.4–1.6°C per 20–35min)
     • Movement → Power spike (80–350W immediate)
   - Environmental linkages:
     • Temp-Humidity: -0.65 to -0.95 covariance
   - Realistic variance:
     • Thermal noise (±0.2°C)
     • Measurement error margins
     • Natural temporal distribution

Output Specification:

Mandatory CSV header:
timestamp,device_id,zone,event_category,source_sensor,celsius,rel_humidity,movement,presence,illuminance,wattage,sound_level,air_ppm,entry_state,egress_status

Deliver both:
  - Initial exemplar set
  - Comprehensive output dataset
"""),
    AIMessagePromptTemplate.from_template("prompt")
])