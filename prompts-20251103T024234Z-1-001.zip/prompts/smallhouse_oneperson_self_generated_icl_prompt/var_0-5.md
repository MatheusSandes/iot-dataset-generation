var_5 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
First, create 3 prototype IoT sensor events that realistically represent the configured smart home scenario.
Use these prototypes as behavioral templates when generating the complete dataset afterwards.
Maintain strict consistency across all parameters including timing patterns, device interactions, and environmental correlations.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Configuration Blueprint

- Residence Type: Compact city apartment (42 m² total)

- Device Mapping:

  » Lounge Area (9 m²):
    • Motion tracker (motionDetector_sofaZone)
    • Entertainment hub (mediaWallscreen_L1)
    • Ambient lighting (ledPanel_main)
    • Climate sensor (envProbe_LR)
    • Entry system (secureEntry_main)

  » Sleep Chamber (9 m²):
    • Movement scanner (sleepZone_tracker)
    • Bedside illumination (moodLight_BR)
    • Thermal sensor (tempCheck_BR)

  » Food Prep Zone (2.16 m²):
    • Heat monitor (kitchen_thermometer)
    • Task lighting (underCabinet_LED)
    • Appliance controller (coldStorage_powerNode)

  » Hygiene Area (2.4 m²): no monitoring devices

- Spatial Relationships:
  - Sleep Chamber <> Lounge Area
  - Lounge Area <> Food Prep Zone and Hygiene Area

- Occupant Profile:
  - Solo professional resident
  - Active periods: 06:30–08:15 and 18:00–23:00
  - Absent hours: 08:30–17:45
  - Rest cycle: 23:30–06:00

- Environmental Conditions:
  - Seasonal: Southern hemisphere winter
  - Interior climate range: 20.5–25.5°C
  - Moisture levels: 38–68%, negative correlation with temperature

Generation Protocol:

Phase 1: Create 3 prototype sensor event records
  - These form the behavioral foundation for subsequent data
Phase 2: Scale up generation using established patterns
All entries must adhere to:
  - Silent periods: 23:30–06:00 and 08:30–17:45
  - Movement→Thermal: +0.7–1.3°C per 12–28 minutes
  - Activity→Energy: 120–290W immediate spike
  - Heat⇄Humidity: r-value = -0.75 ± 0.1
  - Measurement tolerances:
    • Temperature (±0.15°C)
    • Power (±9W)
    • Motion false positives (0.15±0.05%)

Required Output Structure:

Begin with exact header specification:
utc_timestamp,event_id,zone,event_category,activation_device,deg_c,relative_humidity,movement_state,resident_status,luminance,energy_usage,sound_index,air_quality_index,entrance_state,fenestration_status

Then provide:
  - The 3 prototype event records
  - Expanded dataset following identical behavior patterns
"""),
    AIMessagePromptTemplate.from_template("prompt")
])