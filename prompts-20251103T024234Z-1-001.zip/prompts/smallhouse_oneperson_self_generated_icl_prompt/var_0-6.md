
var_6 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You will simulate realistic IoT device behaviors for a smart home environment.
First demonstrate your understanding by creating 2-3 initial examples that capture typical device interactions.
Then use these patterns to generate a complete time-series dataset that maintains all physical and logical constraints.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Simulation Parameters:

Dwelling & Configuration:
- Property: Compact urban apartment (52m² total)
- Floor Plan:
  • Lounge (9m²): 
    [motion_sensor_01, smart_tv, lighting_lounge, temp_lounge, door_lock_main]
  • Bedchamber (9m²):
    [motion_primary, lighting_sleep, temp_bedroom]
  • Cooking Area (2.16m²):
    [temp_kitchen, lighting_kitchen, plug_refrigeration]
  • Washing Facilities (2.4m²): No instrumentation

Temporal Dynamics:
- Resident Profile:
  + Work schedule: Weekdays 08:30-18:00
  + Active periods: Mornings (06:00-08:30) & Evenings (18:00-23:00)
  + Sleep cycle: 23:00-06:00 daily
  + Weekend variation: +2hrs waking/sleeping

Environmental Context:
- Seasonal: Southern Hemisphere winter
- Thermal range: 20-25°C interior
- Hygrometric properties: 35-65% RH with inverse temp relationship
- Initial data requirements:
  1. Create 2-3 prototypical event sequences showing device-state transitions
  2. Expand these into full timeline respecting all constraints

Physical Constraints:
- Silence windows: 23:00-06:00 & 08:30-18:00 (no events)
- Device response parameters:
  > Motion → Thermal: +0.8±0.3°C over 20±5min
  > Activation → Energy: 150±50W instantaneous
  > Thermal-humidity: r = -0.8±0.1
  > Measurement error ranges:
    • Temp: ±0.8°C
    • Power: ±15W
    • Motion: 0.2% false positives

Output Specification:

Mandatory header (include exact punctuation):
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Deliver both:
- Initial representative examples
- Complete synthetic dataset
"""),
    AIMessagePromptTemplate.from_template("prompt")
])