var_4 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
First, create 2-3 high-quality prototype sensor events that realistically represent the given smart home scenario.
Use these prototypes as reference patterns to generate the complete dataset while maintaining:
- Physical consistency (e.g., temperature changes when motion detected)
- Temporal patterns matching occupancy schedule
- Energy and environmental correlations
- Realistic sensor noise and variability
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Configuration Blueprint

◆ Residential Profile:
- Type: Compact urban apartment (60m² total)
- Occupant: Working professional (solo)
- Active Hours: 
  ☀ Morning: 06:00-08:00
  🌙 Evening: 17:00-22:30
- Away Hours: 08:00-17:00 (work)
- Sleep Hours: 22:30-06:00

◆ Device Ecosystem:

[Living Zone]
- Motion Detection: motion_sensor_living
- Climate: temp_sensor_living (±0.2°C)
- Lighting: smart_light_living (dimmable)
- Entertainment: smart_tv (energy monitoring)
- Security: smart_lock_front (status reporting)

[Sleeping Zone]  
- Presence: motion_sensor_bedroom
- Lighting: smart_light_bedroom
- Thermal: temp_sensor_bedroom

[Food Zone]
- Appliance: smart_plug_fridge
- Ambient: temp_sensor_kitchen
- Lighting: smart_light_kitchen

◆ Environmental Parameters:
- Season: Southern hemisphere winter
- Temperature Bounds: 21-26°C
- Humidity Range: 40-70% (inverse temp correlate)
- Energy Profile:
  - Baseline: 50W (sleep)
  - Active: 150-300W (usage peaks)

Data Generation Requirements:

1. Prototype Phase (2-3 rows):
   - Showcase realistic device interactions
   - Demonstrate environmental relationships
   - Include natural timestamp spacing

2. Full Dataset Phase:
   - Extend patterns from prototypes
   - Maintain physical/behavioral constraints
   - Add appropriate sensor noise:
     - Temp: ±0.3°C
     - Power: ±2% fluctuation
     - Motion: 0.2% false positives

Output Specification:

Required Header (exact):
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Deliver both:
  - Your carefully crafted prototype examples
  - The complete generated dataset
"""),
    AIMessagePromptTemplate.from_template("prompt")
])