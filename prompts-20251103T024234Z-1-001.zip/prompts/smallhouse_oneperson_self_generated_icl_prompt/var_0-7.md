var_7 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Create a realistic IoT sensor dataset by first producing 2-3 exemplar events that demonstrate authentic device interactions.
Use these examples as a foundation to expand into a complete dataset while maintaining coherent device behavior patterns.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Blueprint

- Property Profile: Compact urban residence (65m² total)
  
- Device Installation:

  ★ Primary Zone (Living Area: 9m²):
    ■ Motion detector (living_motion)
    ■ Entertainment system (tv_entertain)
    ■ Adaptive lighting (living_light)
    ■ Climate monitor (living_temp)
    ■ Entry security (main_lock)

  ★ Rest Zone (Sleeping Area: 9m²):
    ■ Presence detector (bed_motion)
    ■ Ambient lighting (bed_light)
    ■ Thermal sensor (bed_temp)

  ★ Preparation Zone (Kitchen: 2.16m²):
    ■ Thermal gauge (kitchen_temp)
    ■ Task lighting (kitchen_light)
    ■ Appliance controller (fridge_power)

- Area Connectivity:
  - Rest Zone ↔ Primary Zone
  - Primary Zone ↔ Preparation Zone & Hygiene Zone

- Resident Pattern:
  - Solo professional occupant
  - Active periods: Morning (06:00–08:00), Evening (17:00–22:30)
  - Absent: 08:00–17:00 daily
  - Rest period: 22:30–06:00

- Environmental Context:
  - Seasonal: Brazilian winter (June)
  - Interior climate range: 21–26°C
  - Moisture levels: 40–70%, inverse relationship to temperature

Data Generation Protocol:

1. Initially create 2-3 prototype event records demonstrating:
   - Plausible sensor activations
   - Logical device interactions
   - Realistic event sequencing

2. Scale these patterns into a comprehensive dataset while maintaining:
   - Temporal restrictions (no events during rest/absent periods)
   - Thermal-motion relationship (0.5–1.5°C fluctuation per activation)
   - Power response correlation (instant 100–300W draw)
   - Inverse temp/humidity linkage (-0.7 to -0.9 coefficient)
   - Realistic signal variations (±10% measurement noise)

Delivery Specification:

Begin with precisely this header:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Include both:
  - Initial exemplar events
  - Complete expanded dataset
"""),
    AIMessagePromptTemplate.from_template("prompt")
])