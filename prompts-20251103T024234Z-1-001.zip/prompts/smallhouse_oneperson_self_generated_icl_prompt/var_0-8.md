
var_8 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
First, conceptualize 2–3 typical IoT sensor events that would occur in the described scenario.
Use these synthetic examples as pattern references to produce the complete dataset.
Maintain realistic device interactions, temporal sequences, and environmental dependencies.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Configuration Profile

Residence Type: Compact urban dwelling (45m² total)

Device Inventory:

+ Main Living Area (9m²):
  • Presence detection (motion_main)
  • Entertainment system (tv_main)
  • Illumination control (light_main)
  • Climate monitoring (temp_main)
  • Access control (lock_main)

+ Sleeping Quarters (9m²):
  • Motion scanning (motion_sleep)
  • Lighting (light_sleep)
  • Thermal sensor (temp_sleep)

+ Food Preparation Zone (2.16m²):
  • Temperature gauge (temp_kitchen)
  • Lighting (light_kitchen)
  • Appliance control (plug_fridge)

+ Hygiene Facility (2.4m²): Not monitored

Site Connectivity:
  - Sleeping Quarters ↔ Living Area
  - Living Area ↔ Kitchen & Hygiene Facility

Occupant Pattern:
  - Solo adult resident
  - Active periods: 06:00–08:00, 17:00–22:30
  - Operational hours: 08:00–17:00 (vacant)
  - Rest cycle: 22:30–06:00

Climate Context:
  - Seasonal phase: Southern winter (June)
  - Thermal range: 21–26°C indoor
  - Moisture index: 40–70% RH (inverse thermal relationship)

Procedure:
1. Create 2–3 prototype event records
   - These establish behavioral templates
2. Scale to complete dataset following established patterns
3. Enforce these constraints:
   - Event blackout: 22:30–06:00 and 08:00–17:00
   - Thermal impact of presence: +0.5–1.5°C per 15–30min
   - Energy spikes from activity: 100–300W immediate
   - Thermal-humidity correlation: -0.7 to -0.9
   - Measurement variance: temp (±0.1°C), power (±1%)
   - False positives: motion (0.1–0.3% rate)
   - Temporal distribution (natural intervals)

Required Output Format:

Begin with this exact column header:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Include both:
  - Initial sample records
  - Expanded dataset following identical logic
"""),
    AIMessagePromptTemplate.from_template("prompt")
])