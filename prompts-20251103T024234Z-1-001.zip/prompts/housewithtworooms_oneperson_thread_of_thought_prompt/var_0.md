```python
var_0 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Work through the smart home scenario in a step-by-step reasoning thread.
Mentally pause between steps to assess the current state and what comes next.
Break down the behavior into discrete phases (e.g., waking, breakfast, departure, return, evening, sleep).
Use this thread to guide your dataset generation — but only output the final CSV dataset.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Scenario Configuration

- House Type: Small urban smart home with two bedrooms

- Devices by Room:

  • Bedroom1 (3m x 3m):
    - motion_sensor_bedroom1
    - temp_sensor_bedroom1
    - smart_light_bedroom1

  • Bedroom2 (3m x 3m):
    - motion_sensor_bedroom2
    - temp_sensor_bedroom2
    - smart_light_bedroom2

  • LivingRoom (3m x 3m):
    - motion_sensor_living
    - temp_sensor_living
    - smart_tv
    - smart_light_living
    - smart_lock_front

  • Kitchen (1.8m x 1.2m):
    - temp_sensor_kitchen
    - smart_light_kitchen
    - smart_plug_fridge

  • ServiceArea:
    - motion_sensor_service
    - temp_sensor_service

  • Bathroom (2m x 1.2m): no sensors

- Room Connections:
  - Bedroom1 
  
  LivingRoom
  - Bedroom2 
  
  Bathroom
  - Bathroom 
  
  ServiceArea 
  
  Kitchen
  - LivingRoom 
  
  Kitchen

- Resident:
  • Single adult (person1), sleeps in Bedroom1

- Daily Routine:
  • Wakes at 06:00, leaves for work at 08:00, returns at 17:00
  • Sleeps from 22:30 to 06:00
  • Morning: Bedroom1 and Kitchen use
  • Evening: LivingRoom and Kitchen
  • Occasionally accesses Bedroom2 and ServiceArea

Phases to simulate:
1. Wake up and bedroom movement (06:00–06:15)
2. Move to kitchen and interact with fridge/light (06:15–07:00)
3. Prepare to leave — pass through LivingRoom (07:00–08:00)
4. No events during work hours (08:00–17:00)
5. Return home and access LivingRoom and Kitchen (17:00–22:00)
6. Bedtime in Bedroom1 (22:00–22:30)
7. No events during sleep (22:30–06:00)

Technical Requirements:

- Motion 
  
  
  
  Temperature (0.5–1.5°C in 15–30 min)
- Motion 
  
  
  
  Power (100–300W immediately)
- Temperature 
  
  Humidity: correlation -0.7 to -0.9
- Add realistic noise:
  - Temperature 'b10.1°C
  - Power 'b11%
  - Motion FP: 0.1–0.3%
- Inactive periods:
  - 23:00–06:00 (sleep)
  - 08:00–17:00 (work)
- Timestamps must be irregular and natural

Output Format:

Start with this header:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Then output only the final dataset (do not include your internal reasoning or phase descriptions).
"""),
    AIMessagePromptTemplate.from_template("prompt")
])
```