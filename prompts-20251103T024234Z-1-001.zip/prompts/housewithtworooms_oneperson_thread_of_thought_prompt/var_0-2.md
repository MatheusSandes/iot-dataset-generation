var_2 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Carefully simulate daily residential patterns through multi-phase event generation.
Consider occupant behavior and device interactions at each time segment.
Maintain strict output format - only provide the final CSV with sensor readings.
"""), 
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Configuration:

|| Space Overview ||
• Type: Compact urban residence
• Dimensions: Two 9sqm bedrooms + shared spaces
• Duration: Full 24-hour cycle

|| IoT Deployment ||
● Sleeping Quarters 1:
  - presence_check_primary
  - climate_monitor_sleep1 
  - illumination_unit1

● Sleeping Quarters 2:
  - presence_check_secondary
  - climate_monitor_sleep2
  - illumination_unit2

● Social Zone:
  - multisensor_communal
  - entertainment_system
  - lighting_zone4
  - entry_controller

● Cooking Area:
  - temp_monitor_kitchen
  - lighting_zone5
  - appliance_node_fridge

● Utility Space:
  - presence_check_service
  - climate_monitor_utility

|| Flow Map ||
Primary ↔ Social ↔ Cooking                                         
Secondary ↔ Hygiene ↔ Utility

|| Resident Profile || 
- Adult solo occupancy (Sleeping Quarters 1)
- Chronological Pattern:
  06:00-06:15 Wake cycle
  06:15-07:00 Morning sustenance
  07:00-08:00 Preparation interval
  08:00-17:00 Occupational absence
  17:00-22:00 Home engagement
  22:00-22:30 Sleep preparation
  22:30-06:00 Sleep phase

|| Simulation Rules ||
✓ Motion ↔ Power: 100-300W with motion
✓ Climate data affects humidity (inverse relationship)
✓ Implement sensor imperfections: 
  - Temp variance ±1.5°
  - Motion false positives (0.1-0.3%)
✓ Off-cycle periods:
  - Extended absence (08:00-17:00)
  - Rest interval (23:00-06:00)
✓ Variable timing between recordings

Required Output Format:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status
"""),
    AIMessagePromptTemplate.from_template("prompt")
])