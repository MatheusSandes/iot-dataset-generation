var_3 = ChatPromptTemplate.from_messages([  
    SystemMessagePromptTemplate.from_template(r"""  
Build an intricate smart home simulation dataset by executing each temporal phase methodically.  
Pause critically between phases to verify state transitions and device interactions.  
Deconstruct the routine into precisely defined operational windows with unique behavioral patterns.  
Your cognitive process should underpin dataset generation — but produce only the final CSV output.  
"""),  
    HumanMessagePromptTemplate.from_template(r"""  
Home Infrastructure Layout  

- Dwelling: Compact metropolitan smart residence with dual sleeping quarters  

- Deployed Equipment:  

  • Primary Chamber (3m²):  
    - presence_scanner_chamberA  
    - thermal_reader_chamberA  
    - adaptive_illuminator_chamberA  

  • Secondary Chamber (3m²):  
    - presence_scanner_chamberB  
    - thermal_reader_chamberB  
    - adaptive_illuminator_chamberB  

  • Social Zone (3m²):  
    - presence_scanner_social  
    - thermal_reader_social  
    - entertainment_display  
    - ambient_regulator_social  
    - access_controller_main  

  • Culinary Sector (1.8m²):  
    - thermal_reader_culinary  
    - task_lighting_culinary  
    - consumption_edge_fridge  

  • Utility Block:  
    - presence_scanner_utility  
    - thermal_reader_utility  

  • Hygiene Unit (2m²): unsensored  

- Spatial Connectivity:  
  - Primary Chamber – Social Zone  
  - Social Zone – Culinary Sector  
  - Secondary Chamber – Utility Block  
  - Hygiene Unit accessible from both chambers  

- Occupant Profile:  
  • Solo professional inhabits Primary Chamber  

- Chronological Pattern:  
  • Consciousness activation 06:00, departure 08:00, re-entry 17:00  
  • Restorative interval 22:30–06:00  
  • Diurnal activities focused in Primary Chamber & Culinary Sector  
  • Nocturnal operations concentrated in Social Zone & Culinary Sector  
  • Sporadic utilization of Secondary Chamber & Utility Block  

Operator Activity Segments:  
1. Conscious emergence and spatial orientation (06:00–06:20)  
2. Nourishment preparation subsystem engagement (06:20–07:30)  
3. Departure protocol activation (07:30–08:15)  
4. Domestic void period (08:15–17:00)  
5. Re-occupation procedures (17:00–22:00)  
6. Renewal preparatory stage (22:00–22:30)  
7. Quiescent operations suspension (22:30–06:00)  

Technical Constraints:  

- Motion detection:  
  activation required for correlated state changes  
- Thermal variance:  
  0.5–2.0°C fluctuations in irregular increments  
- Energy profiles:  
  abrupt 150–400W demand shifts  
- Thermodynamic coupling:  
  inverse humidity linkage (-0.75 to -0.95)  
- Systematic anomalies:  
  thermal misinformation ±0.2°C  
  energy monitor offset ±2%  
  erroneous presence positives 0.05–0.4%  
- Dormant phases:  
  23:30–05:30 (inactive human state)  
  08:30–16:30 (occupant absenteeism)  
- Chronographic elements:  
  non-periodic temporal stamps  

Required Output Structure:  
Initiate with standardized recognition fields:  
timestamp_interaction,sequence_identifier,geo_position,event_classification,activation_cause,degrees_celsius,relative_humidity,presence_detected,human_occupation_status,luminous_intensity,wattage_measurement,sound_pressure_level,particulate_concentration,access_mechanism_status,transparent_barrier_state  

Transmit exclusively the refined dataset artifact (omit internal deliberation segments or phase commentaries).  
"""),  
    AIMessagePromptTemplate.from_template("prompt")  
])