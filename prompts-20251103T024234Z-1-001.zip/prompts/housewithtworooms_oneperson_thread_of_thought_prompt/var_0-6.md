
var_6 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Analyze the smart home case study through sequential inference steps.    
Visualize each phase distinctly and simulate realistic device interactions.
Map the resident's day into behavioral segments (awakening, preparation, absence, return, relaxation, rest).  
Verify consistency before finalizing your streamlined CSV dataset output.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Residential Automation Setup

- Architecture: Compact city residence (54qm) with interior connections:
  ▪ Bedroom Ø Living ▪ Living Ø Kitchen
  ▪ Bedroom Ø Bathroom ▪ Bathroom Ø ServiceZone

- Sensor & Device Network:

 ► Primary Suite (Bedroom1):
  ∙ Presence/Bed1 (#34521)  270° coverage
  ∙ Climate/Bed1 (#34522) ±0.3°C tracking
  ∙ Illumination/Bed1 (#44109) ADIM-capable

 ► Guest Room (Bedroom2):
  ∙ Movement/Bed2 (#34523)
  ∙ Thermal/Bed2 (#34524)
  ∙ Lighting/Bed2 (#44110)

 ► Social Space (LivingRoom):
  ∙ ActivityGrid (#51201) 3×3 array
  ∙ AmbientScan (#51202)
  ∙ EntertainmentHub (#67100)
  ∙ MoodLighting (#44111)
  ∙ EntryProtocol (#89100) biometric

 ► Food Preparation (Kitchen):
  ∙ ChillModule (#91234) ØC tracking
  ∙ TaskLights (#44112) 4000K
  ∙ ApplianceNode (#55321) monitoring

► Utility Zone:
  ∙ MovementDet (#34525)
  ∙ ClimatePod (#34526)

► Hygiene Room: Dedicated blind spot

- Resident Profile:
  ∙ Professional (30-40) ØC/Bed1
  ∙ Operational Windows:
     ▸ Activity Block 06:00-08:00
     ▸ Departed State 08:00-17:00
     ▸ Evening Block 17:00-22:30
     ▸ Sleep Cycle 22:30-06:00

Simulation Parameters ► must include:
❇ Differential thermal progression (0.2-1.2°C per 20min)
❇ Load spikes ► white goods (75-350W instant)
❇ Environmental correlation:
   ▪ Temp Ø Humidity ► -0.75±0.1 coefficient
❇ Reality injection:
   ▪ Sensor noise ØC in calibration set {2,5}
   ▪ Phantom triggers ▪ 0.2%±0.1 prevalence
❇ Quiescent Periods highlighted
❇ Responses require suppressed regular periodicity

Required Output ▼▼▼
Begin dataset with this exact structure:
utc_timestamp,device_uid,zone,event_class,origin_node,temp_C,RHpc,movement_state,presence,illum_lx,power_W,acoustic_db,VOC_ppm,secure_state,fenest_open

Then produce CLEAN data stream ONLY (no methodology commentary).
"""),
    AIMessagePromptTemplate.from_template("prompt")
])