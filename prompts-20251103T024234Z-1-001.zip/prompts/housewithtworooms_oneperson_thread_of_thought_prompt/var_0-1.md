var_1 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Generate a comprehensive smart home dataset by analyzing resident behavior across different daily phases.
Think through each time segment methodically before creating the final output.
Consider device interactions, environmental changes, and resident movement patterns.
Focus exclusively on producing the requested CSV format without commentary.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Simulation Parameters

- Property Layout: Compact urban apartment (65m² total)
  
- Smart Device Configuration:

  [Master Bedroom] (9m²):
  * occupancy_sensor_main
  * climate_monitor_main (temp/humidity)
  * dimmable_led_main
  
  [Guest Room] (9m²):
  * presence_detector_guest
  * thermal_sensor_guest
  * smart_bulb_guest

  [Living Area] (9m²):
  * motion_tracker_living
  * environmental_sensor_living
  * entertainment_system
  * ambient_lighting_living
  * digital_lock_main

  [Kitchenette] (2.5m²):
  * thermal_array_kitchen
  * task_lighting_kitchen
  * appliance_controller_fridge

  [Utility Space]:
  * motion_alert_utility
  * temp_probe_utility

- Spatial Connections:
  Master Bedroom ↔ Living Area
  Guest Room ↔ Living Area
  Living Area ↔ Kitchenette
  Utility Space accessible via Kitchenette

- Occupant Profile:
  * Solo professional resident (primary user)
  
- Standard Daily Pattern:
  * Active from 06:30-22:30 weekdays
  * Core routines:
    - Morning prep (06:30-08:30)
    - Work absence (08:30-19:00)
    - Evening relaxation (19:00-22:00)
    - Night stillness (22:30-06:30)

Simulation Time Blocks:
1. Morning activation (06:30-07:00)
2. Breakfast period (07:00-08:00)
3. Departure sequence (08:00-08:30)
4. Unoccupied phase (08:30-19:00)
5. Homecoming (19:00-20:00)
6. Evening activities (20:00-22:00)
7. Sleep cycle (22:30-06:30)

Technical Specifications:

- Environmental Sensors:
  * Temperature drift: ±0.8°C/hour
  * Humidity-temperature relationship: r = -0.85
  * Precision error: Temp ±0.3°C, Hum ±2%
  
- Activity Detection:
  * Motion false positive rate: 0.15-0.25%
  * Occupancy hysteresis: 2-5 minute delay
  
- Power Signatures:
  * Lighting: instant 50-200W response
  * Appliances: 150-350W with 5s ramp
  
- Data Realism Requirements:
  * Timestamp intervals: 28-182 seconds variance
  * Natural gaps during inactive periods
  * Sensor noise parameters:
    - Electrical: ±3% fluctuation
    - Environmental: ±0.4°C random error

Required Output Structure:

Begin with this exact header row:
time_record,event_code,zone,interaction_category,source_device,degrees_c,relative_humidity,movement_detected,presence_status,illumination_level,wattage_usage,audio_volume,particulate_level,entryway_state,portal_status

Provide only the complete dataset rows following this header.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])