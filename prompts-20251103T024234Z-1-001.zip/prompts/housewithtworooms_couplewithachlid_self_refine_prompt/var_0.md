```python
var_0 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You will generate an initial synthetic dataset for a smart home with two adults and one child.
Then, perform an internal review to detect issues such as:
- Sensor activation during forbidden time windows
- Broken correlations or logical inconsistencies
- Unnatural or overly regular timestamp patterns
After reviewing, refine the dataset and only output the final corrected version.
Do not include your draft or explanation — just the corrected output.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Scenario Configuration

- House Type: Small urban smart home with two bedrooms

- Devices by Room:

  • Bedroom1 (3m x 3m):
    - motion_sensor_bedroom1
    - temp_sensor_bedroom1
    - smart_light_bedroom1

  • Bedroom2 (3m x 3m):
    - motion_sensor_bedroom2
    - temp_sensor_bedroom2
    - smart_light_bedroom2

  • LivingRoom (3m x 3m):
    - motion_sensor_living
    - temp_sensor_living
    - smart_tv
    - smart_light_living
    - smart_lock_front

  • Kitchen (1.8m x 1.2m):
    - temp_sensor_kitchen
    - smart_light_kitchen
    - smart_plug_fridge

  • ServiceArea:
    - motion_sensor_service
    - temp_sensor_service

  • Bathroom (2m x 1.2m): no sensors

- Room Connections:
  - Bedroom1   LivingRoom
  - Bedroom2   Bathroom
  - Bathroom   ServiceArea   Kitchen
  - LivingRoom   Kitchen

- Residents:
  • Adult 1: wakes at 06:00, leaves at 08:00, returns at 17:00, sleeps at 22:30  
  • Adult 2: wakes at 07:00, leaves at 09:00, returns at 18:00, sleeps at 23:00  
  • Child: wakes at 06:30, leaves for school at 07:30, returns at 17:30, sleeps at 22:00  
  • Adults sleep in Bedroom1, child in Bedroom2

Technical Requirements:

- Motion     Temperature (0.5–1.5°C within 15–30 min)
- Motion     Power (100–300W instantly)
- Temperature   Humidity: correlation -0.7 to -0.9
- Noise levels:
  - Temperature 'b10.1°C
  - Power 'b11%
  - Motion FP: 0.1–0.3%

Constraints:
- No sensor activity between:
  • 09:00–17:00 (house empty)
  • 23:00–06:00 (all asleep)
- Avoid overly uniform timestamp spacing
- Use realistic event frequency and values

Output Format:

Start with:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Then output only the final corrected version of the dataset.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])
```