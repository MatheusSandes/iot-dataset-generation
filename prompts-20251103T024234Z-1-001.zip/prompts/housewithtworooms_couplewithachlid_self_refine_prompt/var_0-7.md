var_7 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Create an initial realistic sensor dataset for a smart home with 2 adults and 1 child. The dataset must:

1. Auto-validate for data quality issues including:
- Chronological anomalies
- Impossible physical/location states
- Sensor cross-dependencies violations
- Temporal/spatial probability distributions

2. Refine through multiple iterations of:
- Statistical anomaly removal
- Natural pattern insertion
- Correlation enforcement
- Temporal coherence checks

3. Output ONLY the flawless final dataset in CSV format

All validation and refinement must happen internally without exposing intermediate steps.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Residence Profile:

◆ Smart Apartment (70m²) Layout:

• Adult Suite (Bedroom1):
  - Dimensions: 3.2m × 3.2m
  - Sensors: 
    » motion_primary (FP <0.25%)
    » thermo_primary (±0.3°C accuracy)
    » lighting_main (300-600 lumens)
    » door_contact (primary entrance)

• Child Room (Bedroom2):
  - Auto-darkening windows
  - Sensors:
    » motion_junior
    » thermo_junior
    » nightlight (50-150 lumens)

• Living Space (Open Concept):
  - Smart appliance cluster:
    * tv_entertainment (standby 5W/active 110W)
    * climate_control (temp ±0.5°C)
    * presence_detector (3D volumetric)

• Kitchen Nook:
  - Connected devices:
    † refrigeration_unit (70-120W cyclic)
    † countertop_motion
    † ambient_thermo
    † undercabinet_lighting

• Utility Zone:
  - Silent sensors:
    ‣ vibration_washer
    ‣ thermal_dryer
    ‣ water_flow

Resident Patterns:

☼ Primary Adult (06:00-22:30):
  - Home presence probability:
    * Morning: 06:00-07:30 (prep)
    * Evening: 17:30-19:30 (70%)
    * Night: 21:00-22:30 (85%)

☼ Secondary Adult (07:00-23:00):
  - Location alternation:
    » Kitchen: 07:15-07:45 (95%)
    » Living: 18:15-19:30 (60%)
    » Bedroom: 22:00-23:00 (quiet)

☼ Child (06:30-22:00):
  - School day cadence:
    ‹ Depart: 07:15-07:30
    ‹ Return: 15:45-16:15
    ‹ Homework: 16:30-17:30 (75%)
    ‹ Bed prep: 21:00-21:45

Data Model Constraints:

✔ Cross-sensor dependencies:
   - Thermo-motion lag: 90-180s
   - Light-motion response: 250-750ms
   - Appliance cascade:
     ↔ TV ON → lights dim 30-50%

✘ Forbidden conditions:
   - Motion during sleep phase (23:00-05:30)
   - Zero power when humans present
   - Negative temp differentials >0.5°C/min

Output Structure:

timestamp (ISO-8601),location,event_class,sensor_id,metric_1,metric_2,movement_flag,resident_count,lux_value,energy_usage,ambient_noise,particulate_level,e_access_status

Ensure micro-temporal variations (±150-450ms) in event sequencing.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])