var_1 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a synthetic data generator for a smart home environment. 
Create a realistic behavioral dataset for a family of three, then rigorously validate for:
1. Time window violations (empty home & sleep hours)
2. Physical impossibilities (e.g., multiple presence without movement)
3. Sensor value correlations breaking defined parameters
4. Overly mechanical event sequencing
After validation cycles, output only the perfected dataset without commentary.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Dwelling Blueprint

- Residence: Compact 2-bedroom urban smart home (total 38m²)

- Sensor Deployment:

  ▫️ Primary Bedroom (9m²):
    - motion:primary_bed
    - climate:primary_bed
    - lighting:primary_bed

  ▫️ Child's Room (9m²):
    - motion:child_bed
    - climate:child_bed
    - lighting:child_bed

  ▫️ Common Areas:
    - Living Space (9m²):
      * motion:living
      * climate:living 
      * entertainment:tv
      * lighting:living
      * security:front_entry
    
    - Kitchen (2.2m²):
      * climate:kitchen
      * lighting:kitchen  
      * appliance:fridge

    - Utility Zone:
      * motion:utility
      * climate:utility

  ▫️ Wet Areas: No sensors installed

- Spatial Flow:
  Primary Bedroom ↔ Living ↔ Kitchen ↔ Utility ↔ Child's Room

- Occupant Profiles:
  │ Resident   │ Rise │ Depart │ Return │ Retire │
  │────────────│──────│────────│────────│────────│
  │ Parent 1   │ 0600 │ 0800   │ 1700   │ 2230   │
  │ Parent 2   │ 0700 │ 0900   │ 1800   │ 2300   │  
  │ Schoolchild│ 0630 │ 0730   │ 1730   │ 2200   │

Technical Specifications:

■ Event Relationships:
  • Motion → Lighting (50-400 lux transition in 2-5s)
  • Climate: Δtemp ≤1.2°C/20min
  • Device Power: Baseline +120-350W on activation

■ Environmental Correlations:
  • temp∝humidity (r=-0.8±0.1)
  • Error Margins:
    - Temp: ±0.3°C
    - Power: ±8%
    - Motion: 0.15% FP rate

■ Hard Constraints:
  ▼ No Events During:
     ➤ 0900-1700 (unoccupied)
     ➤ 2300-0600 (sleep cycle)
  ▼ Forbid:
     ➤ Sensor cross-talk
     ➤ Perfect event periodicity

Required Output Schema:

timestamp (ISO),event_id,zone,sensor_class,trigger_element,temp(°C),RH(%),motion_state,occupancy_count,illuminance(lux),power_draw(W),sound_db,IAQ(μg/m³),entry_status,fenestration
-------------------------------------------
[Validated dataset begins here]
"""),
    AIMessagePromptTemplate.from_template("prompt")
])