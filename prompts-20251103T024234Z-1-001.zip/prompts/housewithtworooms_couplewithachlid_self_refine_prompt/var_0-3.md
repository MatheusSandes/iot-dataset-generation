
var_3 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Generate a realistic synthetic dataset for a smart home with two working adults and one school-aged child.
After creation, rigorously validate the dataset by checking for:
- Temporal violations (activity during empty or sleep periods)
- Physical impossibilities (rooms cannot be in multiple states simultaneously)
- Abnormal event sequences or impossible transitions
- Statistical anomalies in sensor readings
Correct all issues and output only the polished final version without commentary.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Configuration Details:

- Spatial Layout:
  
  [Bedroom1] (Master, 9m²) ↔ [LivingRoom] (15m²) ↔ [Kitchen] (2.5m²)
  [Bedroom2] (Child, 9m²) → [Bathroom] (2.5m²) → [ServiceArea] (4m²) → [Kitchen]

- Device Network:

  • Master Bedroom:
    - mm_motion_sensor
    - mm_thermostat
    - mm_smart_led

  • Child's Room:
    - cr_motion_detector
    - cr_climate_sensor
    - cr_night_light

  • Living Area:
    - la_presence_detector
    - la_environment_sensor
    - la_entertainment_system
    - la_illumination
    - la_door_lock

  • Kitchen:
    - kit_temperature_probe
    - kit_lighting
    - kit_appliance_monitor

  • Utility Space:
    - util_motion_tracker
    - util_thermal_sensor

- Resident Profiles:

  Parent1:
  - Awake: 06:15–22:45
  - Work Hours: 08:30–17:45
  - Bedroom: Master

  Parent2:
  - Awake: 07:00–23:15
  - Work Hours: 09:15–18:30
  - Bedroom: Master

  Student:
  - Awake: 06:45–22:00
  - School Hours: 07:45–17:15
  - Bedroom: Child's Room

Technical Specifications:

1. Sensor Relationships:
- Motion → Power Draw (after 10-60s delay, 50-350W)
- Temperature → Humidity (r = -0.75 ± 0.1)
- Multi-sensor correlation coefficients:
  - Motion-Temperature: 0.2–0.4
  - Light-Power: 0.7–0.9

2. Data Variance:
- Temperature noise: ±0.8°C
- Power fluctuation: 5–15%
- Motion false positives: 0.2% ± 0.1

3. Forbidden Activity Windows:
- Weekday occupancy gaps: 09:45–17:00
- Nighttime silence: 23:30–06:00

Output Requirements:

Begin with header row:
timestamp,event_id,location,event_type,device_id,temp_C,humidity_pct,motion_status,occupancy_count,light_lux,power_W,sound_db,air_index,door_state,window_position

Then provide the finalized dataset without any generation notes.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])