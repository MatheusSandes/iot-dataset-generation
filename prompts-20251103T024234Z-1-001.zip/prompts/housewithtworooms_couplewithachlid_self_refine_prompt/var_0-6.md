var_6 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Create a synthetic smart home dataset simulating a realistic urban dwelling with three occupants.
After generating initial data, rigorously validate it against these criteria:
- Activity patterns matching resident schedules
- Physical and logical consistency between sensor readings
- Natural variations in event timing
- Correlation constraints between climate parameters
Fix any identified anomalies and output only the perfected dataset.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Home Configuration:

- Floor Plan:
  • Master Bedroom (3m x 3m) containing:
    - occupancy_sensor_master
    - climate_sensor_master
    - lighting_control_master

  • Child's Room (3m x 3m) with:
    - presence_sensor_child
    - temperature_sensor_child
    - nightlight_control

  • Main Living Space (5m x 4m) featuring:
    - living_area_motion
    - entertainment_system
    - security_door_sensor
    - ambient_light_sensor

  • Kitchen Area (2m x 3m) with:
    - appliance_monitoring
    - pantry_sensor
    - refrigeration_monitor

- Resident Routines:
  Parent 1: 
    - Active 6:15-22:45
    - Away 8:30-17:30
    - Primary bedroom occupant
  
  Parent 2:
    - Active 7:15-23:30
    - Away 9:15-18:15
    - Primary bedroom occupant
  
  Child:
    - Active 6:45-22:00
    - Away 7:30-17:00
    - Occupies children's room

Technical Specifications:

- Motion → Power draw (150-400W immediate spike)
- Temperature ↔ Humidity (inverse correlation -0.65 to -0.85)
- Sensor error margins:
  - Climate ±0.3°C
  - Power ±5%
  - Motion false positives ≤0.4%

Activity Constraints:
- Home unoccupied 9:00-17:00
- Quiet hours 23:30-6:00
- Minimum 1 minute between adjacent sensor events

Required Format:
Begin with CSV header:
timestamp,location,sensor_id,event_type,temperature,humidity,motion_state,power_usage,light_intensity,door_position

Then provide only the validated dataset.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])