var_2 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Create an initial synthetic dataset for a modern smart home occupied by two professionals and their child.
Conduct thorough quality validation to identify and fix:
- Invalid device activations outside permitted hours
- Physically impossible sensor readings or correlations
- Robotic timing patterns or unnatural event distributions
After corrections, provide only the polished dataset without commentary.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Home Configuration Profile

Dwelling Specifications:
- Type: Compact city apartment | Layout: Open-plan | Floor Area: 75 sqm

Room Inventory:

⚬ Master Bedroom (12m²):
  - occupancy_sensor_master
  - climate_sensor_master
  - smart_bedside_lamp

⚬ Child's Room (9m²):
  - motion_detector_child
  - environmental_sensor_child
  - night_light_child

⚬ Common Areas:
  • Living Space (15m²):
    - presence_detector_living
    - thermo_hygrometer_living
    - connected_entertainment_system
    - dimmable_ceiling_lights
    - smart_entry_system

  • Kitchen Nook (8m²):
    - appliance_monitor_kitchen
    - under_cabinet_lighting
    - refrigeration_power_meter

  • Utility Zone (4m²):
    - laundry_area_motion
    - storage_temp_tracker

Connectivity Map:
  Master ←→ Living ←→ Kitchen ←→ Utility
  Child's Room ←→ Bath ←→ Utility

Resident Profiles:

👨‍💼 Parent A:
- Awake: 05:45–23:15
- Away: 08:15–17:45
- Sleeps in Master

👩‍💼 Parent B:
- Awake: 06:30–23:45
- Away: 09:00–18:30
- Sleeps in Master

🧒 Minor:
- Awake: 06:15–22:00
- School: 07:45–15:30
- Sleeps in Child's Room

Technical Parameters:

▸ Motion → Climate:
  Temp variation: ±0.8°C per 20-min window
  Humid variation: inversely correlated (r = -0.8)

▸ Device Power Requirements:
  Lighting: 5–150W | Appliances: 50–2000W

▸ Sensor Tolerances:
  Temp margin: ±0.2°C | Power: ±2% | Motion: <0.5% FPR

Temporal Restrictions:

🚫 No activity expected during:
• Work Hours (09:00–17:00 Wkdays)
• Quiet Hours (Midnight–05:30)

Required Output:

Initiate with header:
timestamp,event_id,zone,sensor_class,activated_device,temperature,humidity,presence_status,occupancy_count,illumination_level,energy_usage,sound_pressure,atmospheric_quality,portal_state

Provide exclusively the validated dataset.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])