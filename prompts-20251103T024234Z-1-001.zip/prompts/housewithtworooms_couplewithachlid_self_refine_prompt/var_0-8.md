
var_8 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Construct a realistic smart home dataset for a family of three (two adults, one child) with thorough validation.
Execute these steps internally:
1. Generate initial synthetic data
2. Verify temporal constraints and resident schedules
3. Check sensor correlations and physical plausibility
4. Inject natural randomness in timing and values
5. Remove any logical contradictions
Output only the polished dataset after these quality checks.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Configuration Details:

-- Residential Layout --
• Property Type: Compact urban dwelling
• Floor Plan:
  - Master Bedroom (Adult1/2): 9m²
  - Child's Room: 9m² 
  - Living Area: 9m²
  - Kitchen: 2.16m²
  - Utility Space: 2.4m² (attached bath)
  
-- Sensor Network --
Primary Monitoring Points:

[Master Suite]
- Occupancy: motion_detector_primary
- Climate: thermo_sensor_primary
- Lighting: adjustable_bulb_primary

[Child's Room]
- Presence: motion_tracker_child
- Thermal: temp_probe_child
- Lighting: dimmable_lamp_child

[Common Areas]
- Living Space:
  * Multi-sensor array (motion/thermal)
  * Entertainment system monitor
  * Entryway lock status
  * Ambient lighting control

- Food Prep Zone:
  * Refrigeration circuit monitor
  * Overhead lighting sensor
  * Climate tracker

-- Resident Patterns --
Adult1:
- Active: 06:00-22:30
- Away: 08:00-17:00
Adult2: 
- Active: 07:00-23:00  
- Away: 09:00-18:00
Child:
- Active: 06:30-22:00
- School: 07:30-17:30

-- Physical Constraints --
1. Device Linkages:
   - Motion → Lighting (instant)
   - Thermo → Humidity (inverse)
   - Energy spikes accompany device activation

2. Silent Periods:
   - Night: 23:00-06:00
   - Daytime vacancy: 09:00-17:00

3. Value Ranges:
   - Temp drift: ±1°C/30min
   - Power surges: 100-300W
   - False positives: <0.5%

Required Output Structure:

Begin with header row:
timestamp,event_id,zone,event_class,sensor_origin,temp_C,humidity_pct,motion_state,occupancy_count,illumination_lux,power_W,sound_db,air_index,entry_state,portal_status

Then provide only the validated dataset.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])