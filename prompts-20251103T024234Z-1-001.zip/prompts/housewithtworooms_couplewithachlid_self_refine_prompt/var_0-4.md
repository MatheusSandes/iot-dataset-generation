var_4 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
INSTRUCTIONS:
1. Create a synthetic smart home dataset for a family of three following specified parameters
2. Perform quality validation to identify and fix:
   - Forbidden-timestamp violations
   - Unrealistic sensor value relationships
   - Statistical irregularities
   - Physical impossibilities
3. Only output the final validated dataset after silent corrections
4. Format exactly as specified below without commentary
"""),
    HumanMessagePromptTemplate.from_template(r"""
RESIDENCE PROFILE: Compact smart home (68 sqm total)

DWELLERS:
- Primary Resident: Up 06:00 | Out 08:00-17:30 | Asleep by 22:30
- Secondary Resident: Up 07:00 | Out 09:00-18:00 | Asleep by 23:00
- Child Resident: Up 06:30 | School 07:30-17:00 | Asleep by 22:00

SMART DEVICE NETWORK:

◉ Primary Suite (Bedroom1):
   • mmWave presence (motion_sensor_bedroom1)
   • Climate monitor (temp/humidity_bedroom1)
   • Adaptive lighting (smart_light_bedroom1)

◉ Secondary Suite (Bedroom2):
   • mmWave presence (motion_sensor_bedroom2)
   • Climate monitor (temp/humidity_bedroom2)
   • Adaptive lighting (smart_light_bedroom2)

◉ Common Areas:
   - Living Room:
     • Multi-sensor array (motion/temp/living)
     • Entertainment system (smart_tv)
     • Ambient lighting (smart_light_living)
     • Entry control (smart_lock_front)
   
   - Kitchen: 
     • Appliance monitor (smart_plug_fridge)
     • Under-cabinet lighting (smart_light_kitchen)

   - Utility Space: 
     • Cleaning robot base (service_area_sensor)

CONNECTIVITY MAP:
Bedroom1←→Living←→Kitchen←→Service←→Bathroom←→Bedroom2<←

DATA QUALITY REQUIREMENTS:

▧ Temporal Logic:
- No weekday triggers 09:30-16:00 (child at school)
- Overnight quiet period: 23:30-05:45 (all sleep phases)

▧ Sensor Relationships:
- Thermal drift: 0.4-0.9°C/flux cycle (15-22 minutes)
 Indonesia keywords",
 ],
 priority: 2,

▧ Output Schema:
(CSV format, include all specified fields exactly)

timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status
"""),
    AIMessagePromptTemplate.from_template("prompt")
])