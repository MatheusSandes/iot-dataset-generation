var_5 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Create an initial smart home activity dataset for a family of three (two adults, one child).
Conduct an automated quality check to identify and fix:
- Temporal violations (activity during inactivity periods)
- Physical impossibilities (e.g., simultaneous presence in distant rooms)
- Sensor value anomalies (outside normal operating ranges)
- Unrealistic event frequency patterns
Generate only the validated final dataset after all corrections.
No intermediate output or explanations—just the clean data.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Blueprint

=== HOME LAYOUT ===
Residence: Compact urban dwelling (75 sqm total)

ROOMS & DEVICES:
1. Master Bedroom (9 sqm):
   - occupancy_sensor_1
   - climate_sensor_master
   - smart_lamp_master

2. Child's Room (9 sqm):
   - motion_detector_child
   - thermo_sensor_child
   - nightlight_child

3. Living Area (9 sqm):
   - presence_sensor_living
   - environmental_monitor_living
   - entertainment_system
   - main_lights
   - entrance_lock

4. Kitchen (2.2 sqm):
   - heat_sensor_kitchen
   - undercabinet_lights
   - refrigerator_monitor

5. Utility Space:
   - movement_sensor_utility
   - temperature_probe_utility

6. Bathroom (2.4 sqm): Unmonitored

ROOM CONNECTIVITY:
Master <-> Living
Child's <-> Bath <-> Utility <-> Kitchen
Living <-> Kitchen

=== FAMILY SCHEDULE ===
ADULT 1:
   Rise: 06:00 | Depart: 08:00 | Return: 17:00 | Bed: 22:30
ADULT 2:
   Rise: 07:00 | Depart: 09:00 | Return: 18:00 | Bed: 23:00
CHILD:
   Wake: 06:30 | School: 07:30 | Home: 17:30 | Sleep: 22:00
Sleeping arrangements: Adults in Master, Child in Child's Room

=== SENSOR RELATIONSHIPS ===
- Motion -> Power draw (150-350W immediate)
- Temp change (0.4-1.6°C per 10-35 min)
- Temp-Humidity: inverse correlation (-0.65 to -0.95)
- Expected error margins:
   - Temperature ±0.2°C
   - Power ±12%
   - False motion positives: 0.05-0.35%

=== ACTIVITY RESTRICTIONS ===
BLACKOUT PERIODS:
- Weekday absences: 09:00-17:00
- Nighttime: 23:00-06:00
- Natural event timing variance required
- Realistic value distributions expected

DATA OUTPUT FORMAT:

Begin with header:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_usage,audio_level,air_quality,door_state,window_status

Then provide only the polished final dataset.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])