
var_3 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
As an IoT Data Architect specializing in residential environments, you're tasked with creating lifelike smart home datasets.
Generate synthetic data reflecting genuine resident behavior patterns while maintaining technical accuracy for device interactions,
environmental conditions, and energy consumption profiles within the given specifications.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Residence Simulation Parameters

▸ Dwelling Configuration:
- Type: Compact urban studio flat
- Active Periods: 
  ☀ Morning phase: 05:45–08:15
  🌙 Evening phase: 17:30–23:15  
  💤 Sleep cycle: 23:15–05:45 ABSOLUTE QUIET PERIOD

▸ Device Deployment:

┌───────────────┬─────────────────────────────────────────┐
│  Zone         │  Instrumentation                       │
├───────────────┼─────────────────────────────────────────┤
│ Main Living   │ • PIR-001 (motion)                     │
│ (3.2×3.4m)    │ • CLI-001 (ambient lighting)           │
│               │ • THS-001 (climate station)            │
│               │ • DLC-001 (primary entry)              │
└───────────────┴─────────────────────────────────────────┘

┌───────────────┬─────────────────────────────────────────┐
│  Sleeping     │ • PIR-002 (motion)                     │
│ Quarters      │ • CLI-002 (mood lighting)              │
│ (3.6×2.8m)    │ • THS-002 (thermal sensor)             │
└───────────────┴─────────────────────────────────────────┘ 

▸ Environmental Context:
(Brazilian Winter Conditions)
- Thermal range: 20.5–25.5°C (living), 18–22°C (bedroom)
- Moisture variance: daily cycle 35%–65% 
 steady cooldown after activity periods
  
┌──────────────────┬─────────────────────────┬──────────┐
│ Physical Trigger │ System Response        │ Lag Time │
├──────────────────┼─────────────────────────┼──────────┤
│ Movement         │ +0.7–1.8°C temp rise   │ 12–25min │
│ Lighting         │ 90–280W load surge     │ Instant  │
│ Appliance Use    │ Humidity drop 5–15%    │ 5–8min   │
└──────────────────┴─────────────────────────┴──────────┘

Absolute Simulation Rules:
✗ No phantom events during quiet hours (23:15–05:45) 
✗ Missing activity when resident is absent (08:15–17:30) 
✓ Natural timestamp jitter (±1–4min for recurring events) 

Output Structure Requirements:
timestamp(BR time),sensor_id,space,category,trigger,
ambient_temp(RH%),motion_state,presence,
illuminance(lux),current_draw(W),sound_level(dB),
particulate(µg/m³),entrance_state 

Begin immediately with this header EXACTLY:
timestamp,sensor_id,space,category,trigger,ambient_temp,motion_state,presence,illuminance,
current_draw,sound_level,particulate,entrance_state
"""),
    AIMessagePromptTemplate.from_template("prompt")
])