
var_5 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
As an accomplished Synthetic Data Architect specializing in residential IoT ecosystems, your mission is to craft an authentic behavioral dataset that mirrors human- habitat interactions. 
Your solution must embody: 
- Scientifically valid device interdependencies
- Mathematicaly sound environmental relationships
- Cognitively plausible activity patterns
for this digital twin of a smart dwelling.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Living Space Digitalization Request 

▣ Premise: Compact city residence  

▣ Spatial Configuration:

Living Sphere (9m²):
◇ PresenceDetector_L1 (binary)  
◇ EntertainmentUnit_TV1 (stateful)  
◇ IlluminationNode_L1 (dimmable 0-100%)  
◇ EnvironmentalSensor_TL1 (thermo-hygrometer)  
◇ AccessPoint_D1 (state: locked/unlocked)

Resting Chamber (9m²):
◇ PresenceDetector_B1  
◇ IlluminationNode_B1  
◇ EnvironmentalSensor_TB1  

Nutrition Preparation Zone (2.16m²):
◇ EnvironmentalSensor_TK1  
◇ IlluminationNode_K1  
◇ PowerMonitor_F1 (appliance load meter)

Sanitation Area: Uninstrumented  

▣ Connectivity Graph:
Bedroom ⇄ Living ⇄ Kitchen  

▣ Human Factor:
- Solitary inhabitant (diurnal rhythm synchronized)
- Active phases: dawn (06h-08h) & evening (17h-22.5h)
- Quiescent period: 22.5h-06h
- Absence interval: 08h-17h  

▣ Ambient Profile:
- Seasonal context: Brazil winter solstice period
- Thermoregulation bounds: 294-299 Kelvin
- Moisture oscillation: 40-70% RH (inverse thermal coupling)

Technical Parameters

∮ Cross-Sensor Dynamics:
- Movement→Thermal (+0.5-1.5K over 900-1800s)
- Movement→Energetics (instant 100-300W draw)
- Thermal-Hygrometric: ρ ≈ -0.8  

∮ Signal Integrity Considerations:
- Thermal resolution: ±0.1K uncertainty
- Power monitoring tolerance: ±11W
- False detection rate: 0.1-0.3% (Poisson distributed)

∮ Hard Constraints:
- Data nullification during inactive windows
- Temporal spacing must follow Weibull distribution

Required Output Schema

Initiate with this precise header (without modification):
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Subsequently generate ONLY the synthetized telemetry matrix in CSV format.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])