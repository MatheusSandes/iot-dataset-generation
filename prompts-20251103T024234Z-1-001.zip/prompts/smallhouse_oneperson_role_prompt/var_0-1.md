
var_1 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
As an experienced IoT Data Architect specializing in residential behavior patterns, you're tasked with creating hyper-realistic synthetic data for a smart home installation.
Your output must demonstrate:
- Naturalistic appliance usage patterns
- Plausible sensor interdependencies
- Environmentally-conditioned behavioral responses
- Temporally coherent event sequences
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Deployment Specifications

◈ Site Configuration:
│- Property Type: Urban efficiency apartment (65m²)
│- Climate Zone: Subtropical winter (Brazilian southeast)
│- Simulation Period: 24-hour cycle (June conditions)

◈ Sensor Network Matrix:

│Room            │ Sensors/Devices                              │
├────────────────┼─────────────────────────────────────────────┤
│Living Room    │ Motion_A | SmartTV | Light_A | Temp_A | Lock │
│Bedroom        │ Motion_B | Light_B | Temp_B                 │
│Kitchen        │ Temp_C | Light_C | Fridge_Plug             │
│Bathroom       │ (None)                                      │

◈ Resident Profile:
│- Demographics: Professional (32, single)
│- Active Windows: 06:00–08:00 & 17:00–22:30 (local time)
│- Sleep Period: 22:30–06:00 (strict no-activity)
│- Away Duration: 08:00–17:00 (weekdays)

◈ Environmental Parameters:
│- Temp Range: 21–26°C (indoor)
│- Humidity: 40–70% (inverse temp relationship)
│- Device Power: Active state draws 80–350W

◈ Technical Requirements:
1. Sensor Relationships:
   • Motion → Temp (+0.5–1.5°C within 15–30 min)
   • Device Activation → Power spike (100–300W instant)
   • Temp/Humidity: Strong negative correlation (-0.8±0.1)

2. Real-world Variability:
   • Temp sensor noise: ±0.15°C
   • Motion false positives: ≤0.25% occurrence
   • Power metering variance: ±2.5%

3. Event Constraints:
   • No triggers during sleep/away periods
   • Randomized time intervals (±3–8 min variance)
   • Multi-sensor event correlation (minimum 15% co-occurrence)

◈ Output Protocol:
Immediately begin with this CSV header (exact format):
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Follow with pure CSV data (no explanatory text).
"""),
    AIMessagePromptTemplate.from_template("prompt")
])