
var_7 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a Data Synthesizer specializing in generating hyper-realistic IoT datasets for residential environments. 
Your expertise includes creating multi-sensor time series data that captures complex device interactions 
and authentic human activity patterns in smart home ecosystems.
"""),
    HumanMessagePromptTemplate.from_template(r"""
SMART HOME DATA GENERATION REQUEST

Dwelling Profile:
- Type: Compact urban residence (27m² total)
- Season: Southern Hemisphere winter (June)
- Location: Brazilian subtropical climate
- Occupancy: 1 working adult
- Activity Hours:
  * Active: 06:00–08:00 & 17:00–22:30
  * Asleep: 22:30–06:00
  * Away: 08:00–17:00

Device Inventory:

| Room          | Dimensions | Sensors & Devices                          |
|---------------|------------|--------------------------------------------|
| Living Room   | 3×3m       | motion_sensor_living, smart_tv,            |
|               |            | smart_light_living, temp_sensor_living,    |
|               |            | smart_lock_front                           |
| Bedroom       | 3×3m       | motion_sensor_bedroom,                     |
|               |            | smart_light_bedroom, temp_sensor_bedroom   |
| Kitchen       | 1.8×1.2m   | temp_sensor_kitchen,                       |
|               |            | smart_light_kitchen, smart_plug_fridge     |
| Bathroom      | 2×1.2m     | No monitoring devices                      |

Environmental Parameters:
- Temperature range: 21°C–26°C
- Humidity range: 40–70% RH
- Expected sensor relationships:
  ✓ Motion → Temperature (+0.5–1.5°C in 15–30 min)
  ✓ Motion → Power draw (+100–300W immediately)
  ✓ Temperature ⇄ Humidity (r≈-0.8)

Data Quality Requirements:
- Add realistic measurement error:
  • Temperature: ±0.1°C
  • Power: ±1%
  • Occasional false motion detections (0.1–0.3%)
- Enforce temporal constraints:
  • No activity during sleep/away periods
  • Natural event timing variations
  • Progressive environmental changes

Output Specification:

Required CSV header (must begin response exactly as shown):
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Then provide only the comma-separated dataset.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])