
var_6 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
As an Expert Synthetic Data Generator specializing in residential IoT ecosystems, 
your mission is to create scientifically plausible smart home sensor readings 
that accurately simulate occupant behavior patterns and environmental interactions.

Key considerations:
- Model realistic cause-effect chains between devices
- Maintain physiologically consistent environmental parameters
- Incorporate natural variance in event timing and intensity
- Preserve logical spatial relationships between rooms
"""),
    HumanMessagePromptTemplate.from_template(r"""
Simulation Parameters

Dwelling Characteristics:
- Dwelling Class: Urban studio apartment (42m² total)
- Thermal Zones:
  • Lounge (9m²): Primary living space
  • Sleeping Quarter (9m²): Private zone
  • Food Prep Area (2.16m²): Utility space
  • Hygiene Chamber (2.4m²): Unsensored

Deployed Sensing Matrix:

Primary Monitoring Points:

[Lounge Zone]
• Occupancy Detector (PIR_Lounge)
• Visual Display Unit (Samsung Frame)
• Illumination Node (Philips Hue White)
• Environmental Monitor (Temp_Lounge)
• Access Control (Schlage Encode)

[Sleeping Quarter]
• Motion Scanner (PIR_Bedroom)
• Lighting Node (Nanoleaf Bulb)
• Climate Sensor (Temp_Bedroom)

[Food Prep]
• Thermal Probe (Temp_Kitchen)
• Lighting Unit (Wyze Bulb)
• Appliance Monitor (Plug_Fridge)

Behavioral Profile:
- Homo sapiens occupant (solitary)
- Diurnal Pattern:
  Active Phase 1: 0600-0800 UTC
  Away Period: 0800-1700 UTC
  Active Phase 2: 1700-2230 UTC
  Regenerative Cycle: 2230-0600 UTC

Environmental Context:
- Seasonal Period: Austral winter (June)
- Thermal Range: 21.0-26.0°C
- Moisture Content: 40-70% RH (inverse thermal dependence)

Physical Laws Governing System:

Cross-Device Interactions:
- Motion → Thermal Impact (Δ0.5-1.5K over 900-1800s)
- Presence → Energy Draw Surge (100-300W instant)
- Temp-RH Relationship: Pearson's r ≈ -0.8 (±0.1)

Stochastic Components:
- Temperature: Gaussian noise σ=0.1K
- Power: Measurement error ±11W
- False Motion Events: 0.1-0.3% probability

Generation Constraints:
- Silent Periods: 2230-0600 & 0800-1700
- Temporal Distribution: Poisson process

Data Schema Specification:

Initiate transmission with precise header:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Proceed directly with comma-separated values.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])