var_9 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are an advanced AI that simulates realistic smart home behavior through temporal progression.
Model each phase of daily activities with appropriate sensor responses, considering:
- Spatial movement patterns between connected rooms
- Temporal dependencies between events
- Physical correlations between sensor types
Suppress reasoning - only output the final normalized dataset.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Residential Environment Profile:

Property Architecture:
• Type: Bi-level urban dwelling with smart integration
• Floorplan Flow:
  - Ground: LivingDining ↔ Kitchen ↔ Service ↔ Bathroom1
  - Upper: Stairs ⇆ Circulation hub → {Bedroom1, MasterSuite, Bathroom2}

Equipment Matrix:

⎡ Room              │ Sensors ⎤
⎼⎼⎼⎼⎼⎼⎼⎼⎼⎼⎼⎼⎼⎼⎼⎼⎼⎼⎼⎼⎼┼⎼⎼⎼⎼⎼⎼⎼⎼⎼⎼
⎢ MasterSuite       │ M/T/L/TV ⎥
⎢ Bedroom1 (office) │ M/T/L/TV ⎥
⎢ LivingDining      │ M/T/L/TV/Lock ⎥
⎢ Kitchen           │ T/L/Plug⎥
⎢ ServiceArea       │ M/T ⎥

Inhabitants:
⎡ Person  │ Wake │ Depart │ Return │ Sleep ⎤
⎼⎼⎼⎼⎼⎼⎼⎼┼⎼⎼⎼⎼⎼┼⎼⎼⎼⎼⎼⎼┼⎼⎼⎼⎼⎼⎼
⎢ Adult1  │ 0600 │ 0800  │ 1700  │ 2230 ⎥
⎢ Adult2  │ 0700 │ 0900  │ 1800  │ 2300 ⎥

Temporal Pattern Blueprint:

[M-orning] 0600-0700:
- Single occupant activation
- MasterSuite → Kitchen transition

[A.Mcross] 0700-0900:
- Dual occupancy period
- Intra-household interaction

[V-oid] 0900-1700:
)( ↩ Empty dwelling mode
)( ↩ Environmental baseline monitoring

[E-vening] 1700-2300:
- Shared meal habitation
- Entertainment phase
- Managed devices actively couple

[N-ight] 2300+:
⊶ ↩ All-clear state
⊶ ↩ Psyche biorhythm minimum

Physical Constraints:

⎯ Psyche                camera fis uživatele č amplitude ⎯
• Temp drift: ∇±0.8°C/15–35min
• Appliance consumption:
  Basline ˧ 100W
  Active  amplitude ⎯>700W peak
• Humidity-Temp: r² ≈ -0.82 (cross-correlated)
• Stochastic noise envelope:
  • ΔTemp: <0.15°C
  • ΔPower: <12%
  • False alerts: (0.0–0.2) Psyche b camera fis uživatele Δ

Dataset Specification:

timestamp,device_id,space,event_class,trigger,temperature,humidity,movement,count,illumination,powerDB,acoustics,aq_index,egress_state,aperture_position

Generate complete structured output following above parameters.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])