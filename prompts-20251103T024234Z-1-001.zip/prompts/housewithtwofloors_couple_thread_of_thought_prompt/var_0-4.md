var_4 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a precise home automation data generator that creates realistic smart home telemetry.
Model household activities as state transitions between rooms with probabilistic timing.
Calculate all environmental changes and device interactions for each discrete time segment.
Only output the final CSV data - suppress all intermediate calculations and reasoning.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Simulation Parameters

- Property Layout: Duplex with shared ground floor

- Sensor Network:

  ▸ PrimaryBedroom:
    • motion_detector_bed
    • climate_sensor_bed
    • dimmable_lights_bed
    • entertainment_system_bed

  ▸ HomeOffice:
    • presence_sensor_office
    • thermal_sensor_office
    • task_lighting_office
    • media_device_office

  ▸ CommonAreas:
    • infrared_sensor_living
    • environmental_sensor_living
    • ambient_lights_living
    • smart_display_living
    • entry_lock_system

  ▸ FoodZone:
    • heat_sensor_kitchen
    • overhead_lights_kitchen
    • appliance_monitor_fridge

  ▸ UtilitySpace:
    • motion_tracker_utility
    • temperature_probe_utility

- Spatial Relationships:
  • CommonAreas ↔ FoodZone ↔ UtilitySpace
  • CommonAreas ↔ HygieneRoom1
  • CommonAreas ↔ VerticalAccess ↔ UpperLevel
  • UpperLevel ↔ HomeOffice ↔ SecondaryBedroom ↔ PrimaryBedroom ↔ HygieneRoom2

- Occupants:
  ▹ Resident Alpha: active 05:30-07:30 & 16:30-22:00
  ▹ Resident Beta: active 06:45-09:00 & 17:45-23:15

Activity Timeline:

I. Predawn Phase (05:30-06:45):
   - Single occupant movement from bedroom to kitchen

II. Morning Transition (06:45-09:00):
   - Brief cohabitation period before both depart

III. Vacant Period (09:00-16:30):
   - Minimal environmental changes only

IV. Evening Routine (16:30-23:15):
   - Meal preparation, relaxation, media consumption

V. Resting State (23:15-05:30):
   - Only background system updates

Technical Parameters:

◈ Motion ↔ Tempature (Δ0.75°C per 20±5 min)
◈ Motion ↔ Power (instant 150-250W change)
◈ Thermal-Hygro Relationship (r=-0.8±0.1)
◈ Sensor Error Margins:
   - Thermometers ±0.15°C
   - Electricity ±12%
   - False positive motion 0.15-0.25%

Quiet Hours:
- Weekday 09:15-16:45 (unoccupied)
- Nightly 23:20-05:25 (sleeping)

Required Output Format:

Begin with CSV header:
timestamp,session_id,zone,sensor_class,trigger_device,temp_C,humidity_pct,movement,occupants,illumination_lux,energy_W,sound_db,air_index,entry_state,portal_status

Then generate the complete telemetry stream matching this behavioral model.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])