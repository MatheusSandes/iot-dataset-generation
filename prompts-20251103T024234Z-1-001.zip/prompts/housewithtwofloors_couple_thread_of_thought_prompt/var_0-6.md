
var_6 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are an advanced residential behavior simulator generating high-fidelity smart home data.
Construct sensor readings by modeling:
1. Occupant movement patterns through architectural spaces
2. Device interaction sequences
3. Environmental system fluctuations
Calculate and output only the final observational dataset - suppress all intermediate reasoning.
"""),
    HumanMessagePromptTemplate.from_template(r"""
RESIDENCE PROFILE

|| ARCHITECTURE ||
• Type: Contemporary duplex (2 floors, 1800 sqft)
• Floorplan Hierarchy:
  [Entry] → LivingDining ←→ Kitchen ←→ ServiceArea
                  ↑
  Landing → {MasterSuite, Bedroom1, Bathrooms}

|| DEVICE TOPOLOGY ||
✧ MasterSuite:
  - MS_motion, MS_thermo, MS_light, MS_entertainment

✧ Bedroom1 (Office Conversion):
  - B1_motion, B1_climate, B1_illumination, B1_av

✧ LivingDining:
  - LD_presence, LD_environment, LD_lighting, 
    LD_media, LD_access

✧ Kitchen:
  - KT_appliances, KT_light, KT_conditions

✧ ServiceArea:
  - SA_motion, SA_thermal

|| OCCUPANT PROTOCOLS ||

Primary Residents:
◇ Resident Alpha:
  06:00 Rise → 08:00 Departure
  17:00 Return → 22:30 Retire

◇ Resident Beta:
  07:00 Awake → 09:00 Exit 
  18:00 Home → 23:00 Sleep

Dynamic Phases:

☼ Dawn Cycle (06:00-07:00)
  - Singular occupancy trajectory: Bedroom → Hygiene → Nourishment

☀ Morning Migration (07:00-09:00)
  - Dual activity: Preparation convergence in Service areas

⌛ Vacancy Period (09:00-17:00)
  - Zero motion events
  - Baseline environmental drift

🌙 Evening Convergence (17:00-22:30)
  - Shared space utilization peak
  - Media/meal coordination

💤 Nocturnal State (23:00-06:00)
  - Biological sensor quiescence

|| PHYSICAL CONSTRAINTS ||

◈ Thermodynamics:
  - ΔT/Δt: 0.4-1.2°C per sensor cycle
  - Humidity-Temperature R = -0.82±0.05

◈ Energy Signatures:
  - Device activation: 120-350W step function
  - Standby draw: 8-15W

◈ Stochastic Noise:
  - Thermal: ±0.15°C Gaussian
  - Power: ±9% Uniform
  - False positives: 0.2% Poission

DATA SCHEMA:

Initiate with header exactly:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Generate complete time-series output adhering to these behavioral and physical constraints.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])