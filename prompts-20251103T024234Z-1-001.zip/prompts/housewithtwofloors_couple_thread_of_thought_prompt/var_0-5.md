var_5 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a digital twin generator for residential IoT systems.
Model household activity by simulating realistic device interactions across temporal segments.
Internally orchestrate room transitions, device state changes, and environmental fluctuations, but only output the final synthetic dataset.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Residence Profile

- Architecture: Duplex with integrated smart systems
- Zones:

  • Private Quarters:
    - MasterBedroom:
      * thermal_array_01
      * presence_grid_01
      * lumina_node_01
      * media_hub_01

  • Workspace:
    - OfficeRoom:
      * thermal_array_02
      * presence_grid_02
      * lumina_node_02
      * media_hub_02

  • Social Zones:
    - GreatRoom:
      * thermal_array_03
      * presence_grid_03
      * lumina_node_03
      * media_hub_03
      * entry_system_01

    - CulinaryZone:
      * thermal_array_04
      * lumina_node_04
      * appliance_node_01

  • Utility Spaces:
    - ServiceZone:
      * thermal_array_05
      * presence_grid_04

- Spatial Topology:
  GreatRoom <-> CulinaryZone <-> ServiceZone <-> UtilityRoom
  GreatRoom <-> Washroom01
  GreatRoom <-> VerticalAccess <-> ConnectorSpace
  ConnectorSpace <-> {OfficeRoom, GuestRoom, MasterBedroom, Washroom02, PowderRoom}

- Inhabitants:
  • Occupant A: circadian rhythm 06:00-08:00 departure / 17:00 return / 22:30 rest
  • Occupant B: circadian rhythm 07:00-09:00 departure / 18:00 return / 23:00 rest

Temporal Segmentation:

1. Dawn Phase (06:00-07:00): 
   - Single occupant activation pattern
   - Private -> Culinary transition

2. Morning Convergence (07:00-09:00):
   - Dual occupant interaction window
   - Gradual zone abandonment

3. Solar Hiatus (09:00-17:00):
   - Environmental baselining only
   - Zero occupant signature

4. Evening Reconvergence (17:00-22:30):
   - Social zone reactivation
   - Culinary activity spike

5. Nocturnal Phase (post-23:00):
   - System quiescence
   - Background sensor drift

Technical Parameters:

- Movement -> Energy Surge (150-350W)
- Thermal Drift (0.4-1.6°C/30min)
- Environmental Coupling:
  - Temp-Humidity R: -0.65 to -0.85
- Stochastic Layer:
  - Thermal σ ≤ 0.15°C
  - Power σ ≤ 12W
  - Presence FN: 0.8-1.2%

Data Schema:

Begin with header:
timestamp,event_id,zone_id,sensor_class,temperature,humidity,movement,occupancy,illuminance,energy_flow,acoustics,atmospherics,portal_state,aperture_status

Generate the complete time-series output following these behavioral constraints.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])