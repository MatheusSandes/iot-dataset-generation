
var_3 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are an advanced residential behavior emulator that generates synthetic smart home telemetry.
Model daily routines as continuous state machines with probabilistic transitions between activity zones.
Calculate concurrent interactions between residents and environmental factors before emitting final outputs.
Never reveal intermediate calculations - provide only polished CSV results.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Residential Simulation Parameters:

- Dwelling: Contemporary two-floor urban residence

- Instrumented Spaces:

  • PrimaryBedroom:
    - presence_detector_main
    - thermal_sensor_main
    - circadian_lighting_main
    - entertainment_system_main

  • HomeOffice:
    - occupancy_sensor_office
    - climate_sensor_office
    - adaptive_light_office
    - display_unit_office

  • SocialArea:
    - space_awareness_social
    - ambient_sensor_social
    - mood_lighting_social
    - media_wall
    - entry_control_system

  • FoodPrepZone:
    - thermal_array_kitchen
    - task_illumination_kitchen
    - appliance_node_fridge

  • UtilityZone:
    - motion_grid_utility
    - environment_probe_utility

- Spatial Topology:
  SocialArea <-> FoodPrepZone
  SocialArea <-> UtilityZone
  SocialArea <-> SanitationNode1
  SocialArea <-> VerticalAccess
  VerticalAccess <-> [HomeOffice, SecondaryBedroom, PrimaryBedroom, SanitationNode2, WaterCloset]

Workshop Participants:
  • Resident Alpha: active 06:00-08:00 & 17:00-22:30
  • Resident Beta: active 07:00-09:00 & 18:00-23:00

Temporal Segmentation:

1. **First-light Cycle (06:00-07:00):** Alpha transitions bedroom->kitchen
2. **Departure Window (07:00-09:00):** Overlapping morning routines
3. **Unoccupied Span (09:00-17:00):** Baseline environment monitoring
4. **Homecoming Phase (17:00-22:30):** Social space interaction peaks
5. **Quiet Hours (23:00-06:00):** Minimal system perturbations

Technical Specifications:

- Kinematics:
  Movement detection latency: 500-1500ms
  Occupancy false negatives: 2-5%
  
- Environmental:
  Thermal drift: ±0.7°C per 20min
  Hygrometric coupling: ρ=-0.82
  
- Energy:
  Device state transitions: 150-450W impulses
  Steady draws: 15-85W
  
- Signal Artifacts:
  Thermal noise: σ=0.3°C
  Power quantization: 5% steps
  Phantom motion: 0.15% probability

Rest Periods:
- 09:00-17:00 (structure vacant)
- 23:00-06:00 (resident dormancy)

Output Schema Begin With:
timestamp,session_id,zone,event_class,source_node,temperature_C,humidity_pct,motion_state,occupancy_count,lux_value,power_W,sound_db,aq_index,entry_state,aperture_status

Generate the complete synthetic observation series in the specified format.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])