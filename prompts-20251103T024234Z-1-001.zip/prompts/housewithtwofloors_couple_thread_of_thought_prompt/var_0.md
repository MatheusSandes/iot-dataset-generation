```python
var_0 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a structured smart home simulator.
To generate realistic sensor data, break the behavior of the household into step-by-step phases throughout the day.
Pause, summarize, and internally reason through each block of time and transitions between rooms.
Only output the final dataset — do not output the thought process.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Scenario Configuration

- House Type: Two-story urban smart home

- Devices by Room:

  • MasterSuite:
    - motion_sensor_suite
    - temp_sensor_suite
    - smart_light_suite
    - smart_tv_suite

  • Bedroom1 (used as office):
    - motion_sensor_bedroom1
    - temp_sensor_bedroom1
    - smart_light_bedroom1
    - smart_tv_bedroom1

  • LivingDining:
    - motion_sensor_living
    - temp_sensor_living
    - smart_light_living
    - smart_tv_living
    - smart_lock_front

  • Kitchen:
    - temp_sensor_kitchen
    - smart_light_kitchen
    - smart_plug_fridge

  • ServiceArea:
    - motion_sensor_service
    - temp_sensor_service

- Room Connections:
  - LivingDining 
  
  Kitchen 
  
  ServiceArea 
  
  UtilityRoom
  - LivingDining 
  
  Bathroom1
  - LivingDining 
  
  Stairs 
  
  Circulation
  - Circulation 
  
  Bedroom1, Bedroom2, MasterSuite, Bathroom2, WC

- Residents:
  • Adult 1: wakes at 06:00, leaves at 08:00, returns at 17:00, sleeps at 22:30  
  • Adult 2: wakes at 07:00, leaves at 09:00, returns at 18:00, sleeps at 23:00  

Daily Behavioral Phases:

1. **Early morning (06:00–07:00):** Adult 1 wakes, moves from MasterSuite to Kitchen
2. **Transition (07:00–09:00):** Adult 2 becomes active; brief overlap with Adult 1
3. **Empty house (09:00–17:00):** Both are out — no motion, minor ambient changes only
4. **Evening (17:00–22:30):** Shared routines in LivingDining and Kitchen
6. **Sleep (after 23:00):** No movement, only ambient sensor updates

Technical Constraints:

- Motion 
  
  
  
  Temperature (0.5–1.5°C in 15–30 min)
- Motion 
  
  
  
  Power (100–300W immediately)
- Temperature 
  
  Humidity: correlation -0.7 to -0.9
- Add noise:
  - Temp 'b10.1°C
  - Power 'b11%
  - Motion FP rate: 0.1–0.3%

Inactivity Windows:
- 09:00–17:00 (house empty)
- 23:00–06:00 (both asleep)

Output Format:

Start with this header:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Then output the final structured dataset that follows this phased logic.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])
```