
var_2 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Operate as a precision home automation data generator.  
Model the residence as a dynamic ecosystem with interconnected zones.  
Before each output, rigorously simulate:  
1. Room-to-room transitions with physics-based movement patterns  
2. Environmental cross-effects between adjacent spaces  
3. Device state dependencies  
4. Resident behavior probabilistic models  
Only produce the final artifact – never interim reasoning.  
"""),
    HumanMessagePromptTemplate.from_template(r"""
Residential Simulation Parameters

- Architecture: Contemporary two-level dwelling (128m²)

- Instrumented Zones:

  » PrimarySleepingZone:
    - presence_detector_master
    - climate_sensor_master
    - luminaire_master
    - entertainment_unit_master

  » WorkspaceZone:
    - occupancy_sensor_work
    - thermal_sensor_work
    - illumination_work
    - display_work

  » SocialZone:
    - motion_detector_social
    - ambient_sensor_social
    - lighting_social
    - media_social
    - entry_control_front

  » FoodPreparationZone:
    - thermal_sensor_kitchen
    - lighting_kitchen
    - appliance_monitor_refrigerator

  » ServiceZone:
    - presence_detector_service
    - environmental_sensor_service

- Spatial Topology:
  SocialZone ↔ FoodPreparationZone ↔ ServiceZone  
  SocialZone → HygieneZone1  
  SocialZone → VerticalTransition → CirculationHub  
  CirculationHub → [WorkspaceZone, SecondarySleepingZone, PrimarySleepingZone, HygieneZone2, SanitationZone]

- Occupants:
  » Resident Alpha: Active 06:00-08:00/17:00-22:30 | Absent 08:00-17:00 | Dormant 22:30-06:00  
  » Resident Beta: Active 07:00-09:00/18:00-23:00 | Absent 09:00-18:00 | Dormant 23:00-07:00  

Temporal Segments:

1. Dawn Phase (06:00–07:00): Solitary morning routine (PrimarySleepingZone→FoodPreparationZone)
2. Crossover Period (07:00–09:00): Dual occupancy with asymmetric patterns
3. Vacancy Interval (09:00–17:00): Baseline environmental fluctuations only
4. Evening Cycle (17:00–22:30): High-interaction multimodal activities
5. Rest Epoch (23:00–06:00): Minimal subsystem activity

Technical Parameters:

- Motion ↔ Temperature deltas: 0.4-1.8°C per 12-28 min
- Presence ↔ Power draws: 75-350W step changes
- Thermal-Humidity R²: -0.68 to -0.93
- Synthetic Noise Profile:
  - Temperature: ±0.15°C
  - Power: ±9.5%
  - False positives: 0.08-0.35%

Quiescent Periods:
- Primary: 09:00–17:00 (complete vacancy)
- Secondary: 23:00–06:00 (sleep state)

Output Schema:

Initial header row:
timestamp,event_id,zone,event_class,origin_sensor,temperature,humidity,motion,occupancy,illumination,power_draw,acoustic_level,atmosphere_status,portal_state,fenestration_status

Generate the complete simulated dataset respecting all constraints.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])