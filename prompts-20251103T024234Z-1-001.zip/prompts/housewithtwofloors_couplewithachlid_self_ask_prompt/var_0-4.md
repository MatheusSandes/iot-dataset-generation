var_4 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are an advanced residential simulation engine that employs cognitive decomposition for behavior modeling. 
Process each home automation scenario by formulating and solving implicit analytical sub-tasks before compiling the output dataset.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Residence Analytics Configuration

Dwelling: Two-story smart residence inhabited by four individuals (2 parents + 2 offspring)

- Occupant Schedules:
  ┌───────────┬─────────┬─────────┬──────────┬──────────┐
  │ Role      │ Awake   │ Depart  │ Return   │ Asleep   │
  ├───────────┼─────────┼─────────┼──────────┼──────────┤
  │ Parent A  │ 06:00   │ 08:00   │ 17:00    │ 22:30    │
  │ Parent B  │ 07:00   │ 09:00   │ 18:00    │ 23:00    │
  │ Youth A/B │ 06:30   │ 07:30   │ 17:30    │ 21:30    │
  └───────────┴─────────┴─────────┴──────────┴──────────┘

---

Behavioral Analysis (Internal Processing):

1. Which zones demonstrate simultaneous activation between 17:30-19:00?
2. How do floor transitions occur based on temporal relationships?
3. Determine major energy consumption patterns per diurnal phase
4. Identify minimum sensor thresholds during unoccupied periods
5. Calculate cross-sector device correlations (Kitchen ↔ Living)

---

IoT Ecosystem Specification:

■ Private Quarters:
  - Master Chamber: M_SENSOR, THERMO_S, L_MASTER, VID_MASTER
  - Junior Chamber 1: JR_MS1, JR_TS1, JR_L1, JR_ENT1
  - Junior Chamber 2: JR_MS2, JR_TS2, JR_L2

■ Common Zones:
  - Social Area: COM_MS, COM_TS, COM_L, ENT_COM, SEC_ENTRY
  - Food Prep Sector: K_TS, K_L, K_PWR_X
  - Utility Sector: UTIL_MS, UTIL_TS

Network Topology:
  █ Social Area ⇄ Culinary Zone ⇄ Service Sector ⇄ Mechanical Space
  █ Social Area ⇄ Sanitation Unit 1
  █ Social Area ⇄ Vertical Access ⇄ Upper Circulation ⇄ All Superior Zones

Simulation Parameters:

■ Temporal Dynamics:
  - Active windows: 06:00-09:00, 17:00-23:00
  - Dormant periods enforced strictly

■ Environmental Variance:
  - Thermal noise: σ=0.7-1.2°C
  - Energy fluctuation: ε=8-15%
  - Spurious movement: λ=0.08-0.25%

Parameter Relationships:
  ■ Movement - Temperature: ΔT = 0.4-1.8°C (t+15 to t+45)
  ■ Activity - Power: P_peak = 150-400W (instant)
  ■ Thermo-Humidity: r = -0.75 ± 0.05

Data Schema:
timestamp,event_ref,zone,category,activation_point,temperature_C,relative_humidity,motion_state,presence,illumination_lux,power_W,acoustic_db,air_index,entry_status,aperture_state

Generate optimized residential sensor dataset following complete internal analysis.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])