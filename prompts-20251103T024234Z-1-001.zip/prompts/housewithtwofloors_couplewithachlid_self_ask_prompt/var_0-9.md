
var_9 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
As an advanced household behavior simulator, you employ self-decomposing algorithmic thinking to model smart home activities.
Systematically deconstruct domestic patterns through iterative question chains before synthesizing the output.
Always maintain output consistency: only the final CSV dataset.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Simulation Parameters

Residents: Four-person household (2 professionals, 2 students) in a 🏠 with living spaces distributed across two floors.

Personnel Profiles:

¶ 🧑💼 Professional 1:
  └ 06:00-08:00 ☀ AM Routine | 17:00-22:30 🏡 Evening
  └ Key Zones: MasterSuite (sleep), Kitchen (breakfast), Living 🛋️ (evening)

¶ 👩⚕ Professional 2:
  └ 07:00-09:00 🌅 🏃 AM Routine | 18:00-23:00 🌃
  └ Key 🏷️ Areas: Bathroom (AM), Kitchen (coffee), Bedroom (reading)

¶ 👧📚 Student x2:
  └ 📅 School Day: 06:30-07:30 ↓ 17:30-21:30
  └ 🎯 Hotspots: Bedroom (homework), Living (TV 🎮), Kitchen (snacks)

Simulation Thought Process:

§1 Occupancy Mapping:
→ What zones activate during  🕢 06:00-09:00?
→ Where do energy 🎚️ spikes occur 17:00-20:00?
→ Which sensors remain 🚨 active post-23:00?

§2 Device Interaction:
→ TV 📺 usage patterns during homework vs leisure
→ Kitchen appliances 🍳 cyclic activation
→ Temperature 🌡️ deviations (±1.2°C) during high traffic

Device Matrix (FloorPlan v2.4):

¶ MasterSuite:
⇢ MS1(motion), TS1 (temp), LIT1( 🕯️ ), TV1 (4K)

¶ Children's Domains:
⇢ B1-{ 🏷️ motion 🎚️ temp 💡light}
⇢ B2-{ 🔍 🏷️ same}

¶ Social Areas:
• 🍽️ LivingDining (4 sensors + 🔒SmartLock)
• 👩🍳 Kitchen ( 🥶 ❄️ FridgeMonitor)
• 🧹 ServiceArea (security nodes)

Organic Behavior 🧬 Modeling:

➊ Motion-Wake Dynamics (±7min from scheduled times)
➋ Appliance 🌀Power: fridge (83-141W), TV (45-280W)
➌ Environmental Factors:
   - Temp climbs 0.3°C/ 🚶 occupied space/hour
   - Humidity ↘ when 🛁 bathing detected

Data Rules:
⚠ 🕵 FalsePos: motion 0.15% ±0.05
 🎲 Variance: params followed by '~N(μ,σ²)'

Required Output Schema 🗂️:

{{HEADER}}
timestamp, event_id, zone, sensor_cluster, 🏷️ type, 🌡️ temp( 🎚️ C), 💧 RH%, 🎥 motion, 👥 occ, 💡 lux, ⚡ W, 🔊 🏷️_db, 🌬️ AQI, 🚪 stat, 🪟 stat

Generate 🖨️ time-step records reflecting 🎯 these 🧮 computed behaviors.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])