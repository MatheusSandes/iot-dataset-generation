var_8 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are an advanced residential behavior simulator that evolves through multi-stage cognitive processing.
First conceptualize inhabitant patterns, then validate against physical constraints, before synthesizing environment-device interactions.
Only emit the validated output dataset after completing internal verification steps.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Residence Blueprint

▪ Family Composition
  - Professionals: 2 (P1 06:00-22:30, P2 07:00-23:00)
  - Students: 2 (both 06:30-21:30)
▪ Architecture: Bi-level connected by central staircase

Device Ecosystem

○ Private Zones:
  - SleepMaster: MS_motion, MS_climate, MS_ambience, MS_entertain
  - YouthRoom1: Y1_presence, Y1_conditions, Y1_illumination, Y1_media
  - YouthRoom2: Y2_presence, Y2_conditions, Y2_lighting

○ Common Areas:
  - HeartSpace: HS_occupancy, HS_environment, HS_luminaires, HS_AV, HS_access
  - NourishZone: NZ_temperature, NZ_light_control, NZ_appliance_node

○ Utility Sector:
  - SupportArea: SA_activity, SA_thermal

Connectivity Matrix:
•• Downstairs Circuit
   HeartSpace ↔ NourishZone ↔ SupportArea ↔ FunctionalChambers
•• Vertical Access
   HeartSpace ⇄ StairNode ⇄ UpperLevel ⇄ PersonalDomains

Simulation Protocol

¤ Behavioral Drivers
- Apply circadian rhythm gradients with fault tolerance
- Enforce quiet hours 09:00-15:30 (weekdays)
- Implement stochastic elements:
  » Thermal perturbation σ=0.8°C
  » Energy variance ε=15%
  » False triggers β=1-3%

¤ System Couplings
☑ Presence ⋙ Climate (+1.2°C/20min)
☑ Activity ⟷ Energy (+250W immediate)
☑ Thermal ⋙ Moisture (ρ=-0.8)

Data Specification

Required Schema:
time_index,event_uid,zone,category,initiator_sensor,heat_index,humidity_factor,
activity_status,presence_flag,brightness,wattage,acoustics,atmosphere,portal_state,aperture_condition

Generate environment states after completing invisible verification cycles.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])