
var_5 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are an advanced home automation simulator that employs cognitive decomposition to model household behaviors. 
Analyze daily routines through temporal segmentation and spatial mapping before generating the optimal device interaction sequence.
Only provide the final simulated dataset without intermediate reasoning.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Residential Simulation Parameters

Household: 4 occupants (2 working adults, 2 school-aged children) in a bi-level smart residence.

- Occupant Schedules:
  ▶ Primary Caregiver:
    06:00 Wake | 07:45 Depart | 17:15 Return | 22:45 Sleep
  ▶ Secondary Caregiver:
    06:30 Wake | 08:15 Depart | 18:30 Return | 23:15 Sleep
  ▶ Dependents (Juveniles A & B):
    06:45 Wake | 07:15 Depart | 15:45 Return | 21:00 Sleep

Consider these operational constraints (internal analysis):
1. Zone activity during peak transition periods (06:00-08:00, 15:00-19:00)
2. Device utilization patterns based on occupant age cohorts
3. Ambient condition fluctuations correlated with presence
4. Quiet hour compliance (22:00-06:00 workdays)
5. Energy conservation protocols during unoccupied periods

Smart Infrastructure Configuration:

¤ Upper Level:
  • Primary Suite:
    ^ motion_detector_ps, thermal_sensor_ps, adaptive_lighting_ps, media_display_ps
  • Junior Chamber A:
    ^ presence_sensor_jca, climate_monitor_jca, illumination_jca, entertainment_unit_jca
  • Junior Chamber B:
    ^ presence_sensor_jcb, climate_monitor_jcb, illumination_jcb

¤ Ground Level:
  • Social Hub (Living/Dining):
    ^ area_sensor_lv, environmental_sensor_lv, smart_ambiance_lv, multimedia_system_lv, secure_entry_lv
  • Culinary Center:
    ^ climate_probe_kit, task_lighting_kit, appliance_monitor_fridge
  • Utility Zone:
    ^ motion_detector_util, thermal_sensor_util

Connectivity Matrix:
  Social Hub ↔ Culinary Center ↔ Utility Zone ↔ Services Node
  Social Hub → Sanitation Module 1
  Social Hub → Vertical Transit → Distribution Network → All Upper Level Zones

Simulation Protocol:
→ Maintain circadian rhythm-based activation sequences
→ Enforce quiescent periods (08:30-15:30 weekdays, post-quiet hours)
→ Incorporate environmental stochasticity:
   ±0.8°C thermal variation
   ±9% power fluctuation
   P(motion false positive) ∈ [0.08%, 0.25%]

System Correlations:
◆ Motion → Thermal: Δ0.7-2.0°C per 20-40 minute window
◆ Presence → Energy: +150-450W impulse response
◆ Temperature ∝ Humidity: ρ ≈ -0.8

Data Schema:
timestamp,event_id,zone,event_class,initiator_device,ambient_temp,relative_humidity,presence_state,occupancy_count,illumination_status,energy_draw,acoustic_level,atmospheric_quality,portal_status,fenestration_state

Generate the complete simulation dataset following spatial-temporal analysis.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])