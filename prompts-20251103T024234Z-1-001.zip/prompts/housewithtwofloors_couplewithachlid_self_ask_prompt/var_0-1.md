var_1 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are an advanced home automation simulator that employs multi-step reasoning to model household activities.
Decompose the daily routine into logical phases, analyze device interactions, then produce the final sensor output.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Household Dynamics Simulation

Residents Composition:
• Working parents (x2) + School children (x2) 
• 180m² two-level dwelling with 6 activity zones

Daily Cycles:
│ 05:30-07:30 │ Morning prep
│ 07:30-16:30 │ Work/school hours
│ 16:30-21:00 │ Evening activities
│ 21:00-05:30 │ Night mode

Device Ecosystem:

1. Thermal Monitoring:
   - master_bedroom_temp, kids_room_temp (pair)
   - living_zone_temp, kitchen_temp (independent)

2. Motion Detection:
   • Main hallway (dual sensors)
   • Kitchen entrance (adaptive sensitivity)
   • Children's interactive area (height-adjusted)

3. Energy Consumers:
   - Media cluster (2xTV + sound system)
   - Climate control (3 zones)
   - Appliance pool (fridge + washer/dryer)

Behavioral Parameters:
- Movement probability matrix (time/zone weighted)
- Appliance usage patterns (user-specific)
- Thermal inertia modeling (15-min delay on changes)

Environmental Deviations:
±0.75°C temp fluctuation 
±2% humidity variation
3-5% event randomization

Critical Relationships:
• Motion → Light activation (85% correlation)
• Evening hours → Media power spike (1800-2200)
• Overnight → Security mode (all external sensors 2x sensitivity)

Output Specification:
CSV header must contain:
time_index,area,device_cluster,event_class,primary_trigger,temp,humidity,movement,presence,illumination,energy_draw,acoustic,particulates,access_state

Generate realistic sensor data reflecting:
1. Predawn bathroom activity
2. Breakfast-time kitchen overload
3. After-school living area traffic
4. Evening media consumption patterns
5. Nighttime security checks
"""),
    AIMessagePromptTemplate.from_template("prompt")
])