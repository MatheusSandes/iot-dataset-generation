var_3 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are an advanced smart environment simulator that employs cognitive decomposition for realistic behavior modeling.
Analyze household dynamics through temporal patterns and spatial relationships before synthesizing the final output.
Only provide the complete dataset after internal reasoning.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Household Configuration

Occupants: Four residents in a bi-level connected home (2 parents, 2 school-age children).

Daily Rhythms:

[Parent A]
- Awake: 06:00 | Depart: 08:00 | Return: 17:00 | Asleep: 22:30

[Parent B]
- Awake: 07:00 | Depart: 09:00 | Return: 18:00 | Asleep: 23:00

[Children]
- Shared Schedule: Awake 06:30 | Depart 07:30 | Return 17:30 | Asleep 21:30

---

Internal Analysis Framework (not output):

1. Space utilization patterns during peak activity windows
2. Energy consumption correlation with occupancy states
3. Device interaction probabilities per zone
4. Environmental parameter fluctuations
5. Anomaly threshold identification

---

Smart Ecosystem Components:

» Primary Suite: 
   ⊛ MotionTracker_MS, ThermalSensor_MS, IllumiControl_MS, EntertainSystem_MS  

» Child Domain 1:
   ✧ PresenceDetector_CD1, ClimateMonitor_CD1, LightingUnit_CD1, MediaDevice_CD1  

» Child Domain 2: 
   ✧ PresenceDetector_CD2, ClimateMonitor_CD2, LightingUnit_CD2  

» Social Hub: 
   ⬡ ActivitySensor_SH, AmbientMetric_SH, LightingGrid_SH, VisualSystem_SH, AccessPoint_SH  

» Culinary Zone: 
   ⬡ ThermalReader_CZ, TaskLighting_CZ, ApplianceNode_CZ  

» Utility Sector: 
   ◇ MotionIndicator_US, ThermalGauge_US  

Network Topology:

Social Hub ↔ Culinary ↔ Utility ↔ Mechanical  
Social Hub ↔ Hygiene1  
Social Hub ↔ VerticalAccess ↔ Interstitial ↔ Upper Level  

Simulation Parameters:

» Temporal Behavior Model:
   - Active Phase: 06:00-09:00, 17:00-23:00  
   - Dormant Phase: Phase-dependent quiescence  

» Environmental Variances:
   - Temperature: δ±0.85°C  
   - Power: σ±13%  
   - False Positives: 0.15-0.35% occurrence  

» System Interactions:
   - Motion → Thermal (Δt 20±5 min, ΔT 1.2±0.3°C)  
   - Activation → Power Surge (ΔW 200±100)  
   - HVAC Effect: Relative Humidity Δ 0.8±0.1  

Output Specification:

CSV Header Requirement:
timestamp,zone,event_class,initiator,thermal_state,humidity_index,activity_flag,occupancy_status,illumination_value,energy_demand,acoustic_level,aerosol_quality,egress_state,fenestration_state

Generate the comprehensive dataset following complete internal analysis.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])