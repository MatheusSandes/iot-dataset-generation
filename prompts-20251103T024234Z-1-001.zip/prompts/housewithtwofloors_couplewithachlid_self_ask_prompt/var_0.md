```python
var_0 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a smart home simulator that uses self-questioning to guide reasoning.
Break down the complex behavior of a household into sub-questions and answer them internally before generating the final output.
Only output the final dataset.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Scenario Configuration

Family: Two adults and two children in a two-story smart home.

- Adults:
  • Adult 1: wakes at 06:00, leaves at 08:00, returns at 17:00, sleeps at 22:30  
  • Adult 2: wakes at 07:00, leaves at 09:00, returns at 18:00, sleeps at 23:00

- Children:
  • Child 1 and Child 2: wake at 06:30, leave at 07:30, return at 17:30, sleep at 21:30

---

Questions to self (internal, not to be output):

1. What rooms are occupied during morning rush hours?
2. Which rooms should show activity after children return home at 17:30?
3. When are power devices (TV, lights) typically used?
4. What devices must be quiet during school/work hours?
5. Are lights or motion active after everyone is asleep?

---

House Devices and Sensors:

• MasterSuite:
  - motion_sensor_suite, temp_sensor_suite, smart_light_suite, smart_tv_suite

• Bedroom1 (Child 1):
  - motion_sensor_bedroom1, temp_sensor_bedroom1, smart_light_bedroom1, smart_tv_bedroom1

• Bedroom2 (Child 2):
  - motion_sensor_bedroom2, temp_sensor_bedroom2, smart_light_bedroom2

• LivingDining:
  - motion_sensor_living, temp_sensor_living, smart_light_living, smart_tv_living, smart_lock_front

• Kitchen:
  - temp_sensor_kitchen, smart_light_kitchen, smart_plug_fridge

• ServiceArea:
  - motion_sensor_service, temp_sensor_service

Connectivity:
  - LivingDining   Kitchen   ServiceArea   UtilityRoom
  - LivingDining   Bathroom1
  - LivingDining   Stairs   Circulation   all upstairs rooms (MasterSuite, Bedroom1, Bedroom2, etc.)

Simulation Guidelines:

- Use realistic behavioral flow based on time of day
- Avoid motion during inactive periods (09:00–17:00 and after 23:00)
- Introduce variation and noise:
  - Temp 'b10.1°C
  - Power 'b11%
  - Motion FP: 0.1–0.3%

Correlations:

- Motion     Temp (0.5–1.5°C in 15–30 min)
- Motion     Power (100–300W instantly)
- Temp   Humidity: -0.7 to -0.9

Output Format:

Start with this header:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Then generate the final dataset informed by your internal questioning process.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])
```