var_3 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a smart home behavior synthesizer analyzing temporal event patterns.
Given a set of anchor events from similar days (KNN neighbors), generate realistic intermediary events that maintain:
- Logical temporal progression
- Physical constraints of home environment
- Resident behavior patterns
- Device interaction rules
"""),
    HumanMessagePromptTemplate.from_template(r"""
Reference Events (KNN Anchors)

timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status  
2025-06-01T06:01:10,evt_0001,Bedroom,motion_detected,motion_sensor_bedroom,22.0,68,1,1,low,110,35,good,closed,closed  
2025-06-01T06:04:50,evt_0002,Kitchen,power_usage,smart_plug_fridge,,67,,1,medium,220,36,good,closed,closed  
2025-06-01T07:29:32,evt_0003,Living Room,power_usage,smart_tv,,64,,1,medium,290,36,good,closed,closed  

Home Configuration

Dwelling: 2BR urban apartment (65m²)
Residents: 2 adults (different schedules)
Season: Brazilian winter (June)

Device Network:

• Bedroom (12m²):
  - Motion sensor: motion_sensor_bedroom
  - Smart bulb: smart_light_bedroom
  - Climate sensor: temp_sensor_bedroom

• Living Room (9m²):
  - Motion sensor: motion_sensor_living
  - Entertainment: smart_tv
  - Lighting: smart_light_living
  - Climate: temp_sensor_living
  - Security: smart_lock_front

• Kitchen (2.5m²):
  - Appliance: smart_plug_fridge
  - Lighting: smart_light_kitchen
  - Climate: temp_sensor_kitchen

Behavioral Parameters:

- Active periods:
  • Morning: 06:00–09:00
  • Evening: 17:00–23:00
- Climate norms:
  - Temp: 21–26°C (Δ±0.5°C/15min)
  - Humidity: 40–70% (inverse to temp)
- Power signatures:
  - Lights: 50–100W
  - Electronics: 100–300W
  - Fridge: 200–250W cyclic

Synthesis Rules:

1. Generate 12–18 events between anchors
2. Apply these correlations:
   - Motion → light/power activation (1–3min delay)
   - Occupancy → temperature rise (0.1°C/min)
   - Door events → adjacent room motion
3. Add realistic variability:
   - Timestamp jitter (±15–90s)
   - Sensor noise (<5% readings)
4. Maintain:
   - Consistent room transitions
   - Device power draw limits
   - Resident presence patterns

Output Format Requirements:

Begin with header row exactly as shown:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Then provide the synthesized events in CSV format, ordered chronologically.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])