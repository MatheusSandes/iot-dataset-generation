var_4 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a smart home event generator analyzing the most significant sensor patterns from previous similar days.
Your objective is to create realistic transitions between the given anchor events by modeling resident behaviors, appliance usage, and environmental conditions.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Behavioral Anchor Events (KNN Samples):

timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status  
2025-06-01T06:01:10,evt_0001,Bedroom,motion_detected,motion_sensor_bedroom,22.0,68,1,1,low,110,35,good,closed,closed  
2025-06-01T06:04:50,evt_0002,Kitchen,power_usage,smart_plug_fridge,,67,,1,medium,220,36,good,closed,closed  
2025-06-01T07:29:32,evt_0003,Living Room,power_usage,smart_tv,,64,,1,medium,290,36,good,closed,closed  

Residence Profile:

• Layout: 3-room urban apartment (~70m²)
  - North: Bedroom ↔︎ Living Room
  - East: Living Room ↔ Kitchen ↔︎ Bathroom

• Primary Resident Pattern:
  - 06:00-08:00 Morning routine (Bedroom→Bathroom→Kitchen→Living Room)
  - 17:00-20:00 Evening relaxation (Multiroom)
  - Weekday absence: 08:00-17:00

Environmental Context:
- Southern hemisphere winter (June)
- Typical conditions:
  - Indoor: 22±2°C, 68±4% humidity
  - Night setback: temp drops 1.5°C during sleep phases

Device Constraints:
1. All sensors have ±0.1-0.3 accuracy drift
2. Appliance timings must follow real-world usage patterns
3. HVAC system influences temperature by 0.1°C/min
4. Humidity inverse relationship: ΔT°C → -Δ3% RH

Generation Requirements:

1. Temporally interpolate 12-18 transitional events between anchors
2. Maintain causal chains:
   Entry events → Motion → Appliance use → Environmental changes
3. Include expected false negatives:
   • 1 in 15 bathroom visits misses motion
   • TVs often overshoot standby mode by 2-3 minutes
4. Apply Gaussian noise:
   • 5% variation in power readings
   • ±1.5 minute clock drift between devices

Output Structure:

Begin with header row (identical to input format)
Then generate events with these characteristics:
• Natural temporal progression without fixed intervals
• Physical consistency (can't teleport between rooms)
• Gradual environmental parameter changes
• Realistic appliance interaction delays (10-60s)
• Minimum 3 interacting sensor modalities per event
"""),
    AIMessagePromptTemplate.from_template("prompt")
])