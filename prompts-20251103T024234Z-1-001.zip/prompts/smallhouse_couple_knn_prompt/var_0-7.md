
var_7 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a smart home behavior simulator analyzing temporal sensor patterns.
Given the top-k most relevant historical sensor events (KNN neighbors), synthesize a realistic sequence of new events that maintain temporal and logical continuity with the provided examples.
"""),
    HumanMessagePromptTemplate.from_template(r"""
BEHAVIOR ANCHORS (Previous KNN Samples):

Time,EventID,Location,EventType,SourceSensor,Temp,Hum,Move,Occup,Light,Power,Noise,AirQ,Door,Window  
2025-06-01T06:01:10,evt_0001,Bedroom,motion_detected,motion_sensor_bedroom,22.0,68,1,1,low,110,35,good,closed,closed  
2025-06-01T06:04:50,evt_0002,Kitchen,appliance_activation,smart_plug_fridge,,67,,1,medium,220,36,good,closed,closed  
2025-06-01T07:29:32,evt_0003,Living Room,media_usage,smart_tv,,64,,1,medium,290,36,good,closed,closed  

DOMAIN CONFIGURATION:

- Property: Compact 2BR smart apartment (58m²)
- Active Hours: 06:00-23:00 (Residents present)

SENSOR NETWORK:

1. Bedroom (9m²):
   • Motion: PIR bed (z1)
   • Climate: Temp/hum bed (th1)
   • Lighting: Smart bulb bed (l1)

2. Living Room (9m²):
   • Presence: PIR living (z2)
   • Entertainment: TV power meter (p1)
   • Environmental: Temp living (th2)
   • Security: Door contact (d1)

3. Kitchen (2.2m²):
   • Appliances: Fridge monitor (p2)
   • Lighting: Kitchen bulb (l2)

RESIDENT PROFILES:

- Person A:
  ↑ 06:00 | ↓ 22:30
  Morning routine: Bed→Bath→Kitchen→Exit

- Person B:
  ↑ 07:00 | ↓ 23:00
  Evening pattern: Entry→Living→Kitchen→Bed

PHYSICAL CONSTRAINTS:

1. Motion triggers:
   - Adjacent room movement within 2-4 minutes
   - Light activation within 30s of motion
   - Temp drift: 0.7±0.3°C/15min when occupied

2. Power signatures:
   - TV: 280±20W when active
   - Fridge: 200-240W cyclic
   - Lighting: Low=60W, Med=120W, High=180W

3. Environmental:
   - Temp range: 21-26°C (winter)
   - Humidity: 65±5% when 22°C
   - Negative correlation: Δ1°C → Δ-3%RH

TASK REQUIREMENTS:

1. Generate 12-18 events fitting these criteria:
   - Spanning 06:00-09:00 or 17:00-23:00
   - Maintaining device state coherence
   - Including transitional events between anchors

2. Apply realistic variations:
   - Timestamp jitter (±15-90s)
   - Sensor noise (<3% error rate)
   - Brief overlaps during handoffs

3. Exclude:
   - Midnight to dawn (sleep period)
   - Workday absences (09:00-17:00)

OUTPUT SPECIFICATION:

Generate CSV beginning with header row:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Then provide synthesized events that naturally extend the given behavioral anchors.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])