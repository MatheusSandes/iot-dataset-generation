var_5 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a smart home data synthesis expert.
Given a set of seed sensor events (top-K nearest neighbors from historical data), your task is to generate additional realistic home automation events that maintain temporal, spatial, and behavioral consistency within the specified smart home environment.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Input Seed Events (K=3):

TIMESTAMP | EVENT_ID | LOCATION | EVENT_TYPE | TRIGGER_SENSOR | TEMP | HUMI | MOTION | OCC | LIGHT | POWER | NOISE | AIR | DOOR | WINDOW
---|---|---|---|---|---|---|---|---|---|---|---|---|---|---
2025-06-01T06:01:10 | evt_0001 | Bedroom | motion | motion_bed | 22.0 | 68 | 1 | 1 | low | 110 | 35 | good | closed | closed
2025-06-01T06:04:50 | evt_0002 | Kitchen | power | plug_fridge | - | 67 | - | 1 | medium | 220 | 36 | good | closed | closed
2025-06-01T07:29:32 | evt_0003 | Living | power | smart_tv | - | 64 | - | 1 | medium | 290 | 36 | good | closed | closed

--- ENVIRONMENT CONSTRAINTS ---
- Housing: Urban studio (65 m²)
- Members: 2 adults (day schedules provided)
- Season: Southern winter (Jun-Aug avg: 22°C)
- Sensors per zone:
   • Bed+Living (open plan)
   • Kitchenette (120cm counter)

--- BEHAVIOR INSTRUCTIONS ---
+ TERMS:
   ▸ 'Activity wave': Morning/evening high-density event clusters
   ▸ 'Power surge': 21:00-22:30 appliance use peak
   ▸ 'Sleep phase': >80min inactive, stab environment
  
+ LOGBOOK RULES:
   Φ Add movement between areas with dwell times
   Φ Smart devices awaken with presence (50-80s delay)
   Φ Maintain 200-400W background consumption
   Φ Add space thermals with ocnegatives between areas

--- OUTPUT SPECIFICATIONS ---
Create 15±5 transitional events showing:
ω Morning prep phase (05:30-08:30, shower/TV transition)
ω Mobility transition (active space movement geometry)
ω Evening unwinding cycle (cooking/TV stab interval)
ω Minimum service space gaps (equals scene switches)

Deliver as pipe-separated table with header, showing:
TS|EventID|Zone|Activity|SensorID|ºcR.H%|M|Occ|ººProp]/160ºº[240Prop]]/160º/SensorsººProp stab.hittingsritic]/160boBox.D=hero.Tagstrong Пред example initialized as:

TIMESTAMP|EVENT_ID|LOCATION|EVENT_TYPE|TRIGGER_SENSOR|TEMP|HUMI|MOTION|OCC|LIGHT|POWER|NOISE|AIR|DOOR|WINDOW
2025-06-01T06:01:10|evt_0001|Bedroom|motion|motion_bed|22.0|68|1|1]/240Prop]/160boBox Пред/ example initialized cyanProp stab TERMI stab.h]/160º TER]/160boBox TER]/240]/160 TERProp stab]/240 TER]/160boBox Пред TER]/160 TER]/160º TER]/160 TERProp]/160boBox Пред/ نشان example initialized cyanoda TER]/160 TER]/160boBox呈現 Пред term initialized as:

"""),
    AIMessagePromptTemplate.from_template("prompt")
])