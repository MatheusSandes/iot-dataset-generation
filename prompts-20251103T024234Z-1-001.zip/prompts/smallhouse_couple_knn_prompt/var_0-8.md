
var_8 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
As an expert in smart home behavior analysis, you're analyzing temporal patterns between sensor events.
You'll harmonize these time-anchored events by filling gaps with plausible activities that maintain:
- Thermal dynamics between rooms
- Environmental condition correlations
- Electricity usage patterns
- Resident schedule overlays
All while preserving data relationships shown in the neighbor examples.
"""),
    HumanMessagePromptTemplate.from_template(r"""
ALIGNED EVENT SEQUENCE (3 neighbor samples acting as temporal anchors)

timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status  
2025-06-01T06:01:10,evt_0001,Bedroom,motion_detected,motion_sensor_bedroom,22.0,68,1,1,low,110,35,good,closed,closed  
2025-06-01T06:04:50,evt_0002,Kitchen,power_usage,smart_plug_fridge,,67,,1,medium,220,36,good,closed,closed  
2025-06-01T07:29:32,evt_0003,Living Room,power_usage,smart_tv,,64,,1,medium,290,36,good,closed,closed  

========================================
HOME BLUEPRINT
• Dwelling Type: Compact Urban Residence (35m²)
• Resident Schedules:
   - R1: Wake 06:00 | Depart 08:08 | Return 16:53 | Sleep 22:25 (±10 min variation)
   - R2: Wake 06:52 | Depart 08:55 | Return 18:03 | Sleep 23:15 (±8 min variation)
• Thermal Gradient Constraints:
   - Bedroom → Living Room ΔT: +0.8°C to +1.2°C morning carries
   - Night temp drop recovery: 0.8°C/hour 06:00-09:00
   - Humidity seesaws: 40min lag after temp changes
========================================

INTERPOLATION MANDATE:
1. Insert 12-17 plausible intermediate events respecting:
   - Wake chronology between residents
   - Appliance activation sequences
   - Room transit patterns (BED→LIV→KIT)

2. Sensor Fact Table:
┌───────────────────────┬─────────────────┬───────────────┐
│ Device Cluster        │ Parameter Link  │ Impact Rolls  │
├───────────────────────┼─────────────────┼───────────────┤
│ Motion carries 90W+   │ 20s→Power spike │ 30% inter-zone│
│ Bedroom temp lag      │ carries 45min   │ 0.9 carries  │
│ Lamp triggers follow  │ motion within   │ 90s ∞ light   │
└───────────────────────┴─────────────────┴───────────────┘

3. Noise/Behavior Rules:
⌛ Timestamp jitter: σ=128s morning, σ=217s evening
🌡️ Temp σ: ±0.37°C (sensor quoted 0.5)
💡 Light carries 87% motion follow within 64s

SAMPLE FORMAT:
Start chronology: (_PRIOR EVENTS BELOW_)
columns → timestamp|event_id|location|event_type|trigger_sensor|temp|humidity|motion|occ|light|power(W)|noise(dB)|air|door|window
maintain CSV continuity sans headers
"""),
    AIMessagePromptTemplate.from_template("prompt")
])