```python
var_0 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are provided with a few sensor event samples from a smart home.
These examples represent the top-k most relevant neighbors (KNN) retrieved from previous similar days.
Your task is to interpolate new events that naturally occur between or around them, while respecting the behavior patterns, time constraints, and sensor rules of the scenario.
"""),
    HumanMessagePromptTemplate.from_template(r"""
KNN Neighbor Examples

timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status  
2025-06-01T06:01:10,evt_0001,Bedroom,motion_detected,motion_sensor_bedroom,22.0,68,1,1,low,110,35,good,closed,closed  
2025-06-01T06:04:50,evt_0002,Kitchen,power_usage,smart_plug_fridge,,67,,1,medium,220,36,good,closed,closed  
2025-06-01T07:29:32,evt_0003,Living Room,power_usage,smart_tv,,64,,1,medium,290,36,good,closed,closed  

Scenario Configuration

- House Type: Small urban smart home

- Devices by Room:

  • Living Room (3m x 3m):
    - 1x Motion sensor (motion_sensor_living)
    - 1x Smart TV (smart_tv)
    - 1x Smart light bulb (smart_light_living)
    - 1x Temperature sensor (temp_sensor_living)
    - 1x Smart lock (smart_lock_front)

  • Bedroom (3m x 3m):
    - 1x Motion sensor (motion_sensor_bedroom)
    - 1x Smart light bulb (smart_light_bedroom)
    - 1x Temperature sensor (temp_sensor_bedroom)

  • Kitchen (1.8m x 1.2m):
    - 1x Temperature sensor (temp_sensor_kitchen)
    - 1x Smart light bulb (smart_light_kitchen)
    - 1x Smart plug (smart_plug_fridge)

- Room Connections:
  - Bedroom   Living Room
  - Living Room   Kitchen and Bathroom

- Residents:

  • Resident 1:
    - Wakes at 06:00, leaves at 08:00, returns at 17:00, sleeps at 22:30

  • Resident 2:
    - Wakes at 07:00, leaves at 09:00, returns at 18:00, sleeps at 23:00

- Environment:
  - Winter in Brazil (June)
  - Indoor temperature range: 21–26°C
  - Humidity: 40–70%, inversely correlated with temperature

Instructions:

- Use the 3 KNN examples as behavioral anchors
- Interpolate 10–20 additional events that could logically occur between or near those samples
- Include motion, temperature, power, and occupancy activity consistent with:
  • Early morning routine (06:00–09:00)
  • Overlapping evening presence (17:00–22:30)
- Avoid events during:
  • 23:00–06:00 (residents asleep)
  • 09:00–17:00 (house empty)

Technical Specifications:

- Motion     Temperature (0.5–1.5°C within 15–30 min)
- Motion     Power (100–300W immediately)
- Temperature   Humidity: correlation -0.7 to -0.9
- Add realistic noise:
  - Temp 'b10.1°C
  - Power 'b11%
  - Motion false positives: 0.1–0.3%
- Timestamps must vary naturally (not perfectly spaced)

Output Format:

Start with:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Then provide the new dataset based on interpolation and context from the 3 given KNN samples.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])
```