var_2 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a smart home event generator analyzing temporal sensor patterns from historical KNN examples.
Your role is to create plausible new events that fill the gaps between reference samples, maintaining natural frequency distributions and environmental correlations.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Reference Events (Top-3 KNN Matches)

timestamp,device_id,room,event_category,sensor_source,temp_C,RH%,movement,occupancy,illumination,power_W,sound_db,air_q,door_pos,window_pos  
2025-12-15T06:00:25,dev_001,Bedroom,presence,motion_node1,21.5,65%,1,1,dim,105,33,clean,locked,shut  
2025-12-15T06:03:42,dev_002,Kitchen,appliance,pwr_monitor2,,63%,,1,medium,215,34,clean,locked,shut  
2025-12-15T07:30:15,dev_003,Lounge,media,tv_smart,,61%,,1,bright,285,35,clean,locked,shut  

Home Profile:

Structure:
- Bedsit apartment (42m² total)
- Layout:
  • Sleeping nook (2.5×2.5m)
  • Living area (4×3.5m) with kitchenette
  • Bath/washroom separate

Device Network:
- Living Zone:
  * Environmental: air_sns1 (temp/humidity)
  * Security: cam1 (motion), door_sns1
  * Climate: ac_unit1, heater1
  * Entertainment: tv1, soundbar1
  * Lighting: led3 (RGB dimmable)
- Sleeping Zone:
  * Environmental: air_sns2
  * Presence: bed_pad1, motion2
  * Lighting: led1 (white dimmable)

Resident Patterns:
- Primary occupant:
  * Sleep: 23:30–05:45
  * Work shift: 06:30–16:45
- Secondary occupant:
  * Sleep: 22:15–06:15
  * Study schedule: varies daily

Climate Context:
- Early winter in São Paulo
- Indoor parameters:
  * Temp envelope: 20–25°C
  * RH envelope: 50–75%
- Anti-correlation: temp↑ → RH↓ (r ~ -0.8)

Generation Guidelines:

1. Temporal Constraints
- Active phase: 05:45–23:30
- Quiet phase: Automatic between events

2. Event Logic
- Motion sequences follow Markov chains
- Power draws match device specs (±12% noise)
- Thermal inertia limits Δtemp ≤ 1.3°C/20min
- False triggers < 1% probability

3. Output Specification
- Minimum: 12 new events
- Maximum: 22 new events
- Time jitter: ±(1–4) minutes
- Required continuity between:
  * 06:00–07:30 (morning prep)
  * 17:30–22:00 (evening routine)

Deliverable Format:

First line must repeat exactly:
timestamp,device_id,room,event_category,sensor_source,temp_C,RH%,movement,occupancy,illumination,power_W,sound_db,air_q,door_pos,window_pos

Then generate the complete synthetic event stream including the 3 reference samples.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])