var_5 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
For optimal dataset generation, analyze:
• Core use patterns and dependencies between systems
• Physical limitations and expected parameter ranges
• Temporal dynamics and event probabilities
Formulate an implementation strategy before execution.
Present only the synthetic data, not your preparation process.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Environment Specifications

- Layout:
  • Compact city apartment (60m² total)
  
- Equipment Configuration:

  SOCIAL_ZONE (5m x 4m):
  □ Presence detector: motion_A
  □ Entertainment: tv_unit 
  □ Lighting: ceiling_led
  □ Climate: thermo_A
  □ Security: main_door_lock

  REST_ZONE (4m x 3m):
  □ Presence detector: motion_B  
  □ Lighting: bedside_lamp
  □ Climate: thermo_B

  PREP_ZONE (2m x 3m):
  □ Climate: thermo_C
  □ Lighting: under_cabinet
  □ Appliance: fridge_plug

  HYGIENE_ZONE (2m x 2m): Unsensored

- Adjacency:
  SOCIAL_ZONE <-> REST_ZONE <-> PREP_ZONE
  SOCIAL_ZONE -> HYGIENE_ZONE

- Resident Profile:
  • Solitary occupant
  • Daily pattern:
    - Active phases: 06h30–08h45 | 18h00–23h15  
    - Absent phase: 08h45–18h00
    - Rest phase: 23h15–06h30

- Climate Context:
  • Winter season
  • Normal operating ranges:
    Temperature: 20°–25°C
    Humidity: 45%–75% (anti-correlated with temp, r≈-0.8)

System Interdependencies:

□ Movement -> Thermal (Δ0.7°–1.8°C over 20–45min)  
□ Movement -> Electric (+150–400W immediate)
□ Enviroment:
  - Thermal-Hygrometric relationship
  - Instrument error margins:
    * Climate: ±0.2°C
    * Power: ±2%
    * Presence: 0.15–0.35% false positives
□ Quiet periods strictly maintained during:
  - Sleep window
  - Away hours
□ Event timing must show organic irregularity

Production Steps:

1. Conceptualize system interactions holistically
2. Implement generation based on derived principles
3. Omit all planning documentation from deliverable

Output Requirements:

Mandatory initial line (verbatim):
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Follow strictly with dataset content only.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])