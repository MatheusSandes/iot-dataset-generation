var_3 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Before creating the dataset, take a moment to visualize how the smart home ecosystem operates:
• Consider typical daily routines in each space
• Map out device dependencies and interactions
• Model environmental fluctuations
• Predict power consumption patterns
Develop this conceptual model, then translate it into data without showing your thought process.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Blueprint

- Property Profile: Compact urban dwelling

- Device Inventory:

  • Main Chamber (3x3m):
    - Presence detector (m_detector_lounge)
    - Entertainment system (ent_sys)
    - Illumination unit (light_lounge)
    - Climate monitor (climate_lounge)
    - Entry mechanism (entry_system_front)

  • Rest Chamber (3x3m):
    - Presence detector (m_detector_rest)
    - Illumination unit (light_rest)
    - Climate monitor (climate_rest)

  • Preparation Area (1.8x1.2m):
    - Climate monitor (climate_prep)
    - Illumination unit (light_prep)
    - Energy port (energy_port_fridge)

  • Hygiene Space (2x1.2m): no monitoring

- Spatial Links:
  - Rest Chamber ↔ Main Chamber
  - Main Chamber → Preparation Area and Hygiene Space

Valid Operational Hours:
- Primary occupancy: 06:00–08:00 and 17:00–22:30
- Unoccupied: 08:00–17:00
- Rest period: 22:30–06:00

Environmental Context:
- Seasonal: Southern winter
Valid ranges:
  - Thermal: 21–26°C
  - Moisture: 40–70% (inverse thermal dependency)

Operational Rules:

- Movement effects:
  - Thermal rise: +0.5–1.5°C over 15–30 min windows
  - Energy spike: +100–300W immediately
- Thermal ↔ Moisture relation: -0.7 to -0.9
- Introduce natural variances:
  - Thermal readings ±0.1°C
  - Power variances ±1%
  - False triggers: 0.1–0.3% of detections
- No activity allowed outside operational periods
- Time notations must appear organic

Execution Steps:

1. Formulate a complete operational model accounting for all factors
2. Convert this understanding into clean data representation

Strictly omit all planning details from final output.

Data Structure:

Begin with this precise header (case-sensitive):
timestamp,event_id,location,event_type,trigger_sensor,thermal_read,moisture_level,movement_status,presence_status,illumination_level,energy_draw,sound_level,air_status,access_status,aperture_status

Follow with pure dataset records.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])