var_7 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Approach this dataset generation systematically by considering:
1) Spatial relationships between rooms and devices
2) Temporal patterns of occupant behavior
3) Physical correlations between environmental factors
4) Device interaction logic
Develop a mental model before data generation, but don't output planning steps.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Configuration Profile

Dwelling: Compact 2-bed urban apartment (Total area: 24m²)

Device Deployment:

★ Living Zone (9m², center space)
  ✔ Presence detector (PD-LV)
  ✔ Climate monitor (CM-LV)
  ✔ Illumination node (LED-LV)
  ✔ Media center (TV-LV)
  ✔ Access controller (AC-FRONT)

★ Sleeping Zone (9m², east side)
  ✔ Presence detector (PD-BR)
  ✔ Climate monitor (CM-BR)
  ✔ Illumination node (LED-BR)

★ Food Prep Zone (2.16m², west side)
  ✔ Climate monitor (CM-KT)
  ✔ Illumination node (LED-KT)
  ✔ Appliance socket (PLG-FRIDGE)

Hydration Zone (2.4m²): No instrumentation

Spatial Relationships:
[Sleeping] ↔ [Living] ↔ [Food Prep/Hydration]

Resident Profile:
• Single professional
• Active windows: 0600-0800 & 1700-2230
• Absence period: 0800-1700 daily
• Rest cycle: 2230-0600

Environmental Context:
• Season: Brazilian winter
• Indoor climate range:
  - Thermal: 21°C to 26°C
  - Moisture: 40-70% RH (anti-phase with temp)

System Parameters:

Interaction Rules:
▲ Movement → Thermal shift (Δ0.5-1.5°C/15-30min)
▲ Movement → Power spike (100-300W immediate)
▲ Heat-Humidity: r = -0.8 ±0.1

Noise Injection:
• Temperature readings: ±0.1°C jitter
• Power measurements: ±11% variance
• False positives: 1 in 500 motion events

Quiet Hours Enforcement:
• 2230-0600: Zero activity
• 0800-1700: Sensor silence

Event Timing:
• Natural, irregular intervals only

Execution Protocol:
1) Formulate complete system dynamics model mentally
2) Generate data reflecting this understanding
3) Omit all planning documentation

Deliverable Format:

Mandatory header (exact):
timestamp,device_id,zone,sensor_type,trigger_device,ambient_temp,relative_humidity,motion_state,presence_status,luminosity,wattage,sound_pressure,air_index,egress_state,aperture_status

Follow with dataset content only.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])