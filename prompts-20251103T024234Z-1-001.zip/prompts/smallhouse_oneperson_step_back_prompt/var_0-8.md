
var_8 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Begin by carefully analyzing the scenario requirements before dataset generation. Consider:
1. Key operational patterns and device behaviors
2. Logical relationships between sensors and actuators
3. Expected variations based on environmental factors
Keep your analysis implicit in the final output quality.
Produce the dataset according to these strategic considerations without including your thought process.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Simulation Brief

- Residence Characteristics:
  + Compact urban dwelling
  + Square footage distribution:
    • Main area (9m²): Living space
    • Private zone (9m²): Sleeping quarters
    • Food prep area (2.16m²)
    • Sanitation space (2.4m²): Sensor-free

- Installed Network:

  Living Zone:
  ◉ Environmental: thermal_sensor_main (°C)
  ◉ Security: entry_lock_system (status)
  ◉ Presence: movement_detector_primary (binary)
  ◉ Ambience: lumen_controller_main (%)
  ◉ Entertainment: television_system (wattage)

  Resting Space:
  ◉ Environmental: thermal_sensor_sleep (°C)
  ◉ Presence: movement_detector_secondary (binary)
  ◉ Ambience: lumen_controller_sleep (%)

  Culinary Space:
  ◉ Environmental: thermal_sensor_food (°C)
  ◉ Appliances: refrigeration_plug (volt-ampere)
  ◉ Ambience: lumen_controller_food (%)

- Spatial Relationships:
  ◍ Private ↔ Social
  ◍ Social ↔ Utility + Sanitation

- Resident Profile:
  ☉ Solitary professional
  ☉ Operational periods: dawn/dusk (06:00-08:00, 17:00-22:30)
  ☉ Vacant hours: daytime (08:00-17:00)
  ☉ Sleep cycle: nights (22:30-06:00)

- Climate Context:
  ☼ Southern hemisphere winter
  ☼ Indoor climate range: 21-26°C
  ☼ Moisture levels: 40-70% RH (inverse thermal relationship)

Operational Parameters:

◆ Movement → Temperature (Δ0.5-1.5°C over 15-30 min)
◆ Motion → Electricity (instant 100-300W draw)
◆ Heat/Humidity: strong negative correlation (-0.7/-0.9)
◆ Realistic signal noise:
   ▪ Thermals: ±0.1°C
   ▪ Power: ±1% reading
   ▪ False detections: 0.1-0.3% of activations
◆ No activities during sleeping/working hours
◆ Irregular, naturalistic timestamp spacing

Processing Steps:

① Conceptually model system interactions
② Produce representative dataset
③ Suppress all modeling notes in final deliverable

Required Output Structure:

Begin with this precise header line:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Follow with clean dataset output only.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])