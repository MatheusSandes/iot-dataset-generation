
var_2 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
When generating this dataset, carefully consider the following:
• Logical device interactions and dependencies
• Real-world constraints and physical limitations
• Temporal patterns and behavioral correlations
• Sensor accuracy and environmental factors
Develop a mental model first, then translate it into data.
Only output the final dataset, no intermediate reasoning.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Scenario Configuration

ARCHITECTURE:
- Property Type: Compact urban apartment
- Total Area: 38.2m²

ROOM SPECIFICATIONS:

🛋️ Living Area (9m²):
• Sensors: 
  - motion_lr (Motion)
  - temp_lr (Temperature)
  - light_lr (Illuminance)
• Devices:
  - tv_lr (Entertainment)
  - lock_main (Security)

🛏️ Sleeping Quarters (9m²):
• Sensors:
  - motion_bed (Motion)
  - temp_bed (Thermal)
• Device:
  - light_bed (Illumination)

🍳 Cooking Space (2.16m²):
• Sensors:
  - temp_kit (Thermal)
• Devices:
  - light_kit (Illumination)
  - plug_fridge (Appliance)

🚿 Sanitation Area (2.4m²): Passive zone

CONNECTIVITY:
Bedroom <-> Living <-> Kitchen/Bathroom

OCCUPANT PROFILE:
• Demographics: Solitary professional
• Active Periods: 06:00-08:00 | 17:00-22:30
• Absent Times: 08:00-17:00 (work)
• Rest Cycle: 22:30-06:00 (sleep)

ENVIRONMENTAL CONDITIONS:
• Season: Brazilian winter
• Thermal Range: 21-26°C
• Moisture Correlation: -0.8 with temperature

PHYSICAL CONSTRAINTS:
■ Motion triggers:
  - Temperature Δ: 0.5-1.5°C over 15-30 min
  - Power surge: 100-300W instantaneous
■ Environmental noise:
  - Temp: ±0.1°C error
  - Power: ±1% variance
  - False motion: 0.1-0.3% rate
■ Silent periods:
  - Night: 22:30-06:00
  - Day: 08:00-17:00
■ Timekeeping:
  - Natural timestamp variations only

GENERATION PROTOCOL:
1. Formulate complete system understanding
2. Implement as clean dataset
3. Exclude all conceptual work from output

REQUIRED OUTPUT FORMAT:
Begin with precise header line:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Follow with pure data records only.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])