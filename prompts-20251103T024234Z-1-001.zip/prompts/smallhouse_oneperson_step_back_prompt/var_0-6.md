
var_6 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Begin by thoroughly conceptualizing the holistic system before data generation:
• Map the fundamental behavioral patterns for all devices and environmental factors
• Establish the causality chains between different sensor types
• Determine the boundaries and edge cases of the simulation
• Model the typical and exceptional usage patterns
Once this conceptual framework is solidified, proceed to generate compliant data without including the framework details.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Configuration Blueprint

- Residential Profile: Compact metropolitan smart dwelling

- Room Specifications with Deployed Devices:

  • Main Living Area (9m²):
    [!] Environmental Tracker: temp_sensor_living
    [!] Presence Detector: motion_sensor_living
    [!] Entertainment Unit: smart_tv
    [!] Illumination Node: smart_light_living
    [!] Entry Control: smart_lock_front

  • Sleeping Quarters (9m²):
    [!] Environmental Tracker: temp_sensor_bedroom  
    [!] Presence Detector: motion_sensor_bedroom
    [!] Illumination Node: smart_light_bedroom

  • Food Preparation Zone (2.16m²):
    [!] Environmental Tracker: temp_sensor_kitchen
    [!] Illumination Node: smart_light_kitchen
    [!] Appliance Connector: smart_plug_fridge

  • Hygiene Chamber (2.4m²): no active monitoring

- Spatial Relationships:
  Sleeping Quarters ↔ Main Living Area
  Main Living Area → Food Prep Zone + Hygiene Chamber

- Occupant Profile:
  - Single professional resident
  - Active windows: early morning (06:00-08:00) & evening (17:00-22:30)
  - Absent period: work hours (08:00-17:00)
  - Rest cycle: deep sleep (22:30-06:00)

- Climatic Conditions:
  - Seasonal context: Southern Hemisphere winter
  - Indoor thermal range: 21°C min to 26°C max
  - Moisture levels: 40% (dry) to 70% (humid) with inverse thermal relationship

Technical Implementation Rules:

1. Sensor Interdependencies:
   - Movement triggers thermal shift (0.5-1.5°C over 15-30 minute intervals)
   - Presence detection causes energy spikes (instant 100-300W increase)

2. Environmental Relationships:
   - Temperature ↔ Humidity (ρ = -0.7 to -0.9)

3. Realistic Distortions: 
   - Temperature variations: ±0.1°C from true
   - Power fluctuations: ±1%
   - False positive movement detections: 0.1-0.3%

4. Temporal Restrictions:
   - No activity during sleep/away periods
   - Randomized but realistic timestamps only

Execution Protocol:

Phase 1: Develop complete system understanding and generation strategy silently
Phase 2: Create dataset strictly following this understanding
Phase 3: Output only the pure data results

Required Header (copy verbatim):
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Followed immediately by CSV-formatted data with no commentary.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])