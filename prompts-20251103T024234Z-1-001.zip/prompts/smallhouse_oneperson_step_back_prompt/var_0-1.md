
var_1 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Complete this task through systematic thinking:
1) Analyze spatial relationships and device interactions
2) Model realistic temporal patterns based on user behavior
3) Establish physical parameter correlations
4) Inject appropriate measurement artifacts
Think deeply but output only clean data.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Blueprint

[Dwelling Profile]
• Type: Compact city apartment (47m² total)
• Climate: Mild winter (Brazilian subtropical)
• Heating band: 21–26°C internal
• Humidity range: 40–70% (antiphase with temp)

[Device Matrix]
|| Living (9m²)             || Bedroom (9m²)          || Kitchen (2.16m²)      |
|---------------------------|--------------------------|-------------------------|
| motion_sensor_living      | motion_sensor_bedroom   | temp_sensor_kitchen   |
| smart_tv (450–850W)       | smart_light_bedroom     | smart_light_kitchen   |
| smart_light_living        | temp_sensor_bedroom     | smart_plug_fridge     |
| temp_sensor_living        |                         |                        |
| smart_lock_front          |                         |                        |

[Bathroom]: No monitoring

[Behavioral Patterns]
☑ Active phases: 
  06:00–08:00 (morning routine)
  17:00–22:30 (evening activities)
☑ Sleep interval: 22:30–06:00 (stationary)
☑ Away period: 08:00–17:00 (unoccupied)

[Physical Laws]
ζ₁: Motion → Temperature shift (+r₁₁; r₁₁∈[0.5,1.5]°C/15–30min)
ζ₂: Movement → Power surge (ΔP∈[100,300]W instant)
ζ₃: Temp ⚡ Humi correlation: r₁ₙ∈[−0.9,−0.7]

[Stochastic Elements]
• Thermal noise: ‡0.1°C jitter
• Power tolerance: †11% variance
• False triggers: ≤0.3% motion events

[Constraints]
× NO events during SLEEP/AWAY windows (22:30-06:00, 08:00-17:00)
× ONLY organic timestamps (non-periodic intervals)

Deliverable:

<<Begin strictly with this header>>
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

<<Complete with only raw data following header>>
"""),
    AIMessagePromptTemplate.from_template("prompt")
])