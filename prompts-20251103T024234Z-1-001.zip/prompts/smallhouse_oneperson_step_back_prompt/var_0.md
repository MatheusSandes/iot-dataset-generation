```python
var_0 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
Before generating the dataset, first reflect on the overall structure of the problem:
• What are the key areas of activity?
• What constraints must be respected?
• What correlations and sensor interactions are expected?
After identifying these key ideas, generate a dataset that follows this plan.
Do not include your reflection or planning in the final output.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Scenario Configuration

- House Type: Small urban smart home

- Devices by Room:

  • Living Room (3m x 3m):
    - 1x Motion sensor (motion_sensor_living)
    - 1x Smart TV (smart_tv)
    - 1x Smart light bulb (smart_light_living)
    - 1x Temperature sensor (temp_sensor_living)
    - 1x Smart lock (smart_lock_front)

  • Bedroom (3m x 3m):
    - 1x Motion sensor (motion_sensor_bedroom)
    - 1x Smart light bulb (smart_light_bedroom)
    - 1x Temperature sensor (temp_sensor_bedroom)

  • Kitchen (1.8m x 1.2m):
    - 1x Temperature sensor (temp_sensor_kitchen)
    - 1x Smart light bulb (smart_light_kitchen)
    - 1x Smart plug (smart_plug_fridge)

  • Bathroom (2m x 1.2m): no sensors

- Room Connections:
  - Bedroom   Living Room
  - Living Room   Kitchen and Bathroom

- User:
  - Single adult
  - Active from 06:00–08:00 and 17:00–22:30
  - Away from 08:00–17:00, sleeps from 22:30–06:00

- Environment:
  - Winter (Brazil), indoor temperature: 21–26°C
  - Humidity: 40–70%, inversely correlated with temperature

Technical Constraints:

- Motion     Temperature (0.5–1.5°C in 15–30 min)
- Motion     Power (100–300W instantly)
- Temperature   Humidity: correlation -0.7 to -0.9
- Add realistic noise:
  - Temperature: 'b10.1°C
  - Power: 'b11%
  - Motion FP: 0.1–0.3%
- No events during 22:30–06:00 or 08:00–17:00
- Natural, variable timestamps only

Instructions:

- Step 1: Reflect on the problem as a whole and identify key planning insights.
- Step 2: Generate the dataset based on that high-level understanding.
- Do not include the planning or reasoning in the output.

Output Format:

Start with this exact header:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Then output only the final dataset.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])
```