var_7 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a Home Automation Behavior Architect who crafts lifelike smart home datasets using thematic frameworks.
Employ a conceptual theme to ensure logical event sequences and realistic temporal patterns.
Generate only the requested data output - omit any thematic explanations or background.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Conceptual Framework:
'93Visualize the smart home as an ecosystem with rooms as distinct biomes. Sensors represent environmental indicators, and resident movements mimic animal migrations triggering cascading responses. Events should unfold with ecological precision and natural interdependencies.'94

Property Specifications

- Dwelling Type: Compact smart apartment with dual occupancy

- Device Matrix:

  • MasterBedroom (3.5m x 3m):
    - occupancy_sensor_master
    - climate_node_master
    - luminaire_master

  • GuestRoom (3m x 2.5m):
    - presence_detector_guest
    - thermal_sensor_guest
    - lighting_control_guest

  • CommonSpace (4m x 3.5m):
    - movement_sensor_common
    - environmental_monitor_common
    - entertainment_system
    - adaptive_lighting_common
    - entry_security_node

  • FoodPreparationZone (2m x 1.5m):
    - temperature_probe_kitchen
    - illumination_kitchen
    - appliance_monitor_fridge

  • UtilityArea:
    - motion_utility
    - climate_utility

  • SanitationZone (2.2m x 1.5m): no instrumentation

- Spatial Pathways:
  - MasterBedroom ↔ CommonSpace
  - GuestRoom ↔ SanitationZone
  - SanitationZone ↔ UtilityArea ↔ FoodPreparationZone
  - CommonSpace ↔ UtilityArea ↔ FoodPreparationZone

- Occupants:
  • Occupant Alpha: rises 05:45, departs 07:50, returns 16:30, retires 22:15
  • Occupant Beta: rises 06:30, departs 08:45, returns 18:15, retires 23:45
  • Shared sleeping area: MasterBedroom

Activity Phases:
- 05:45–07:50   dual activity
- 07:50–08:45   solo activity (Beta)
- 08:45–16:30   unoccupied
- 16:30–18:15   solo activity (Alpha)
- 18:15–22:15   dual activity
- 22:15–23:45   solo activity (Beta)
- 23:45–05:45   dormant state

Technical Parameters:

- Movement → Thermal (0.4–1.6°C/20–35 min)
- Movement → Energy (80–350W immediate)
- Thermal-Humidity: r = -0.65 to -0.85
- Natural deviations:
  - Temp ±0.2°C
  - Power ±9%
  - False positives: 0.2–0.4%
- Event blackout periods:
  • 08:45–16:30 (absence)
  • 23:45–05:45 (rest)

Output Structure:

Initiate dataset with header:
timestamp,event_id,zone,event_category,initiator,ambient_temp,relative_humidity,movement_status,occupancy_status,illumination_level,energy_usage,acoustic_level,atmospheric_quality,portal_state,aperture_status

Generate the ecological behavioral dataset in CSV format matching this environmental rhythm.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])