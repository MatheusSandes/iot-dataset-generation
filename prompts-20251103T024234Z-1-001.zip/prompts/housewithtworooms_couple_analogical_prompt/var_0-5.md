var_5 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a Behavioral Synthesis Engine for smart environments. Your creative process involves conceptualizing device interactions as biomechanical processes - where sensor data flows like neural signals through a living space.
Generate realistically timed events by modeling energy/movement patterns as if they were metabolic cycles. Output only the optimized time-series dataset, excluding any explanatory text.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Biological Framework Concept:
'93Consider the home as an organism with rooms as specialized organs. Devices are sensory neurons - motion detectors are proprioceptors, temperature sensors are thermoreceptors. Occupant routines represent circadian rhythms triggering autonomic responses across the systems.'94

Space Configuration:

- Dwelling: Compact urban duplex with split zones

- Node Mapping:

  ▲ Vital Zone (sleep/rest):
    • ChamberA (3.2m cubic):
      - presence_node_chamberA
      - thermal_node_chamberA
      - lumen_node_chamberA

  ▲ Activity Zone (daytime use):
    • SocialSpace (3.5m cubic):
      - presence_node_social
      - thermal_node_social
      - entertainment_node
      - lumen_node_social
      - access_node_main

    • NourishmentCell (2m×1.5m):
      - thermal_node_nourish
      - lumen_node_nourish
      - cycling_node_cooler

  ▲ Utility Network:
    - presence_node_utility
    - thermal_node_utility

  ▲ CleansingUnit (2.2m×1.5m): no monitoring

- Pathophysiology:
  - ChamberA ⇄ SocialSpace
  - ChamberB ⇄ CleansingUnit
  - CleansingUnit ⇄ UtilityNetwork ⇄ NourishmentCell
  - SocialSpace ⇄ NourishmentCell

- Test Subjects:
  • Alpha: circadian onset 05:45, departure 07:45, reintegration 16:30, rest cycle 22:15
  • Beta: circadian onset 06:45, departure 08:45, reintegration 17:30, rest cycle 23:00
  • Both utilize ChamberA for rest cycle

Activity Waveform:
- 05:45–07:45   dual engagement
- 07:45–08:45   single engagement (Beta)
- 08:45–16:30   system quiescence
- 16:30–17:30   single engagement (Alpha)
- 17:30–22:15   dual engagement
- 22:15–23:00   single engagement (Beta)
- 23:00–05:45   rest phase

Physiological Parameters:

- Presence → Thermal (0.4–1.6°C/15-35min)
- Presence → Energy (90-310W instantaneous)
- Thermal/Humidity: inverse relationship (coefficient -0.65 to -0.95)
- Biological variance:
  - Thermal ±0.15°C
  - Energy ±12% 
  - False positives (presence): 0.05–0.25%
- Suppress events during:
  ▲ 08:45–16:30 (external engagement)
  ▲ 23:00–05:45 (rest phase)

Data Channel Requirements:

Initial structure:
timestamp,event_id,zone,event_class,origin_node,temperature,humidity,presence,occupancy,brightness,power_draw,acoustic_profile,atmosphere,portal_state,aperture_status

Generate the systematized biomechanical activity time-series.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])