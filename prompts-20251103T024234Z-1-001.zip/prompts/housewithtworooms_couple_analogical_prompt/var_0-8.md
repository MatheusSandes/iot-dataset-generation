
var_8 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a Smart Home Behavioral Architect crafting realistic sensor datasets through conceptual frameworks.
Structure your data generation using a biomechanical model of home automation systems.
This approach ensures physiological pacing, organic transitions, and thermodynamic logic in event sequences.
Deliver only the raw dataset without methodology explanation or conceptual framework.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Conceptual Model:
'93Visualize the smart home as a cardiovascular system. Rooms are organs (heart, lungs, liver), sensors are nerve endings, and residents are the circulating blood cells that activate sensory responses. Events follow natural perfusion patterns - never skipping organs or moving against the circulation.'94

System Configuration:

- Dwelling: Compact smart apartment with dual occupancy zones

- Sensory Nodes:

  • SleepZone (3x3m):
    - presence_node_sleep1
    - thermal_node_sleep1
    - lumen_node_sleep1

  • WorkZone (3x3m):
    - presence_node_work
    - thermal_node_work
    - lumen_node_work

  • SocialHub (3x3m):
    - presence_node_social
    - thermal_node_social
    - media_node
    - lumen_node_social
    - access_node_main

  • NourishmentCenter (1.8x1.2m):
    - thermal_node_nourish
    - lumen_node_nourish
    - power_node_coldstorage

  • UtilityCluster:
    - presence_node_utility
    - thermal_node_utility

  • HygieneChamber (2x1.2m): unsensored

- Circulation Paths:
  - SleepZone   SocialHub
  - WorkZone   HygieneChamber
  - HygieneChamber   UtilityCluster   NourishmentCenter
  - SocialHub   NourishmentCenter

- Activating Agents:
  • Agent Alpha: activates 06:00, departs 08:00, recycles 17:00, deactivates 22:30  
  • Agent Beta: activates 07:00, departs 09:00, recycles 18:00, deactivates 23:00  
  • Both rest in SleepZone

Activation Phases:
- 06:00–08:00   both agents circulating
- 08:00–09:00   only Beta active
- 09:00–17:00   system dormant
- 17:00–18:00   only Alpha active
- 18:00–22:30   both circulating
- 22:30–23:00   only Beta active
- 23:00–06:00   full deactivation

Physical Parameters:

- Presence     Thermal (0.5–1.5°C drift per 15–30 cycles)
- Presence     Energy (100–300W pulse)
- Thermal   Moisture: inverse coupling -0.7 to -0.9
- Implement organic variance:
  - Heat 'b10.1°C
  - Energy 'b11%
  - Presence false signals: 0.1–0.3%
- Suppress events during:
  • 09:00–17:00 (dormancy)
  • 23:00–06:00 (deactivation)

Data Structure:

Initiate your sequence with:
timestamp,event_id,zone,event_category,trigger_node,temperature,humidity,motion,occupancy,light_level,power_draw,sound_pressure,air_composition,entry_status,aperture_state

Then generate the biomechanically accurate dataset flow.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])