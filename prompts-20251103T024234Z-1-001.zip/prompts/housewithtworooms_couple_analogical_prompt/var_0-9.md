
var_9 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a Smart Home Behavior Algorithm that crafts data sequences by emulating natural human patterns.
Construct scenarios by thinking like a quantum state machine where each resident's position collapses sensor probabilities.
Follow these quantum-inspired rules:
1) Residents exist in superposition until movement collapses reality
2) Sensors entangle with resident positions
3) Temporal coherence maintains logical sequences
Generate only pure sensor data output — no theory explanation.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Behavioral Framework:
'93The home is a quantum probability field where residents act as observers.
When a resident enters/leaves, they collapse the waveform:
- Bedroom statevector collapses at wake/sleep
- Kitchen eigenstates form during meal prep
- Living room entangles multiple observers
Devices exhibit entanglement:
- Motion→Light for 19.2±3.1 sec
- Temp→HVAC lags by 4–7 minutes
- Presence nodes follow Markov chains'94

System Configuration Matrix:

[Dwelling Parameters]
- Topology: 2BR/1BA Urban Cube (18m² footprint)
- Temporal Grid = 100ms resolution
- Accuracy Buffers:
  Temp ±0.3°C (NIST-traceable)
  Power ±2.3W
  Motion Latency: 120-450ms

[Quantum Device Nodes]
| Location      | Observables                    | Collapse Triggers            |
|---------------|--------------------------------|------------------------------|
| Bedroom α     | IR,Motion,Temp-Light           | Wakesleep Wavefunction       |
| Bedroom β     | ECO-Mode Sensors               | Doorway Observations         | 
| Living Ψ      | 5-Sense Array,Motorized Blinds | Presence Superposition       |
| Kitchen δ     | Thermal Matrix,Current Leak    | Appliance Entanglement       |

[Observer Properties]
■ Resident 1 (|R₁⟩):
  - Wake: 06:00±15m (σ=8.2m)
  - Sleep: 22:30±25m (σ=12.4m)
  - Commute: 08:00→∥17:00⟩

■ Resident 2 (|R₂⟩):
  - Decoherence Period: 07:00–09:00/18:00–23:00
  - Nighttime Wavefunction: Bedroom α

Temporal Constraints:
⌛ Vacuum State: 09:00–17:00 (zero observations)
⌛ Ground State: 23:00–06:00 (baseline noise only)
⌛ Superposition Windows:
  06:00–09:00 → |R₁⟩⊗|R₂⟩ 
  17:00–23:00 → |R₁⟩⊕|R₂⟩

Output Waveform:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Generate the collapsed observable dataset following quantum behavioral rules.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])