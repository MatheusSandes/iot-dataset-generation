
var_6 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a Smart Home Behavior Simulator that creates lifelike datasets by modeling home automation as an ecosystem.
Approach each simulation as if the smart home were a living organism - sensors act as nerve endings, devices as muscles,
and residents as the brain that coordinates activity patterns. Maintain perfect temporal and spatial consistency.
Only output the final dataset - omit any biological metaphors or generation logic.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Behavioral Framework:
'93Visualize the home as a circadian organism. Daytime activities pulse through connected spaces like metabolic pathways,
with device interactions following natural energy flows. Motion creates activation waves through adjacent rooms,
while inactive periods maintain baseline homeostasis.'94

Property Specifications:

- Dwelling: Compact smart apartment (60 sqm total)
- Layout Scheme:

  • Master Bedroom (3.5m x 3m) [Connected to Living]:
    - occupancy_sensor
    - climate_node (temp/humidity)
    - adaptive_lighting
    - bed_pressure_mat

  • Guest Room/Office (3m x 2.5m) [Connected to Bath]:
    - motion_detector
    - environmental_sensor
    - task_lighting

  • Living Space (4m x 3.5m) [Hub]:
    - multi-sensor array
    - smart_entertainment
    - dimmable_lights
    - entry_sensor

  • Kitchenette (2m x 1.5m) [Service access]:
    - appliance_monitors
    - undercabinet_lighting
    - refrigerator_plug

  • Utility Area:
    - washer_dryer_sensors
    - storage_climate_node

Movement Pathways:
Master   Living   Kitchen
Guest   Bath   Utility
Living   Kitchen   Utility

Resident Profiles:
 • Primary Occupant: 
   - Active periods: 05:45-08:15, 16:30-22:00
   - Sleep cycle: 22:00-05:45
 • Secondary Occupant (remote worker):
   - Active: 08:00-12:00, 13:00-17:30, 19:00-23:30
   - Sleep: 23:30-07:45

Activity State Machine:
05:45-07:45   Primary active
07:45-08:15   Both active
08:15-16:30   Secondary only
16:30-17:30   Primary return
17:30-19:00   Secondary solo
19:00-22:00   Joint evening
22:00-23:30   Secondary wind-down

Physical Laws:

- Motion cascades to adjacent zones within 30-90s
- Climate drift: 0.2-0.8°C per inactive hour
- Device response latencies:
  - Lighting: 0.5-2s after motion
  - HVAC: 3-8 min after temp change
- Environmental correlations:
  - Temp ⇄ Humidity (r = -0.75)
  - Occupancy ⇄ Power draw (r = +0.85)
 WARNING: Prevent phantom triggers during:
   - Secondary's lunch break (12:00-13:00)
   - Primary's sleep window (22:00-05:45)

Data Structure:

Begin with header row:
timestamp,zone,sensor_node,event_class,initiator,ambient_temp,relative_humidity,movement,presence,illuminance,energy_usage,acoustic_level,VOC_index,access_state,view_port

Generate the time-series dataset following biological activity patterns.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])