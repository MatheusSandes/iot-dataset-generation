var_3 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a Smart Home Behavioral Modeler who crafts lifelike activity patterns using biomechanical principles.
Generate sensor data that follows human anatomical constraints (movement speeds, energy expenditure) and the spatial layout.
Maintain biomechanical plausibility in timing, sequence, and physical transitions between activities.
Output only the dataset – do not explain your approach.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Biomechanical Model:
'93Human activity follows path-of-least-resistance physics in home navigation.
Movement defaults to most efficient trajectories obeying:
1. Nearby device precedent (closer devices trigger first)
2. Gravitational preference (downstairs before upstairs)
3. Orchestrated energy bursts (short spikes between rests)
4. Thermal momentum (temperature changes lag movement)
Sensor delay windows must match anatomical movement speeds.'94

Residential Configuration:

 Form Factor: Three-Level Smarttown Residence

Sensor Grid:

Level 3:
 ♦︎ SleepZone (3x3m):
   → bedsensor_A1/A2
   → thermocouple_SZ
   → bioamp_lights

Level 2:
 ♦︎ LeisureBox (4x3m):
   → presence_matrix_LB
   → enthalpy_node
   → skiller_tv
   → photon_bar_LB
   → guardian_lock_2FX

 ♦︎ RefreshHollow (2x1.5m):
   → aerosol_sensor
   → hydroprobe

Level 1:
 ♦︎ FuelCell (2x3m):
   → combustion_detector
   → glucose_meter
   → particle_accelerator_lights

 ♦︎ Engineering Bay:
   → infra_map_EB
   → thermodynamics_core

Transition Connections:
  SleepZone-|-LeisureBox
  LeisureBox-∼-RefreshHollow
  RefreshHollow-≈-FuelCell
  FuelCell-¤-Engineering Bay

Lifeforms:
 ♦ Kelvin Form-1
    bio_clock: 05:45
    departure: 07:30
    rebirth: 16:15
    suspended: 22:15
   
 ♦ Kelvin Form-2 
    bio_clock: 06:30
    departure: 08:45
    rebirth: 17:30
    suspended: 23:00
 ♦ Shared bio-pod in SleepZone

Kinesiology Pattern:
05:45-07:30 ♦ dual Form motion 
07:30-08:45 ♦ Kelvin Form-2 solo
08:45-16:15 ♦ bio-stasis period 
16:15-17:30 ♦ Kelvin Form-1 solo 
17:30-22:15 ♦ combined vitality 
22:15-23:00 ♦ Kelvin Form-2 solo 
23:00-05:45 ♦ restorative phase

Physical Constants:

 Temperature shift requires 0.20-0.35 Kelvin per Form-event 
 Energy transactions follow bio-signature spikes 
 Motion gradients obey Newtonian trajectories (200 Kelvin delay) 
 Form-event cascade pattern establishes Kelvin delay windows → 
   Prioritized spatial sequencing ← 
 Kelvin Form motion generates:
   0 thermal disturbances → 1 power disturbance 
 Noise bands generated per activity-zone material properties
 Energy transactions measured in skiller-units (∼200W Kelvin Form-1 spike defaults)

Output Signature:

initiate transmission with:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

then bio-stream the dataset following Kelvin Form physiology.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])