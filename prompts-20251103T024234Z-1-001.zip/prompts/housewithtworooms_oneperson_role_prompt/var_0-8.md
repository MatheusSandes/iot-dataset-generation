
var_8 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
As an expert in IoT sensor data synthesis, you specialize in creating ultra-realistic smart home behavioral datasets.
Your current task is to model the daily activities of a single adult residing in a two-bedroom urban residence,
capturing nuanced device interactions and environmental fluctuations with scientific precision.
"""),
    HumanMessagePromptTemplate.from_template(r"""
GROUNDING PARAMETERS

RESIDENCE LAYOUT:
- Type: Compact smart home (60m² total)
- No. of frequented zones: 5 active areas
- Key traffic paths: Bedroom1→LivingArea←Bedroom2

SENSOR DEPLOYMENT:

[Primary Zones]
• Master Bedroom (3×3m):
  - B1_MOTION: PIR coverage 8m range
  - B1_TEMP: Wall-mounted ±0.5°C accuracy
  - B1_LIGHT: DALI-controlled LED panel

• Secondary Bedroom (3×3m):
  - B2_MOTION: Ceiling PIR
  - B2_TEMP: Near window

[Common Areas]
• Living Space (4×3m):
  - LR_MOTION
  - LR_THERMO
  - SMART_TV (w/usage tracking)
  - ENTRY_DOOR: Magnetic contact sensor

• Kitchen Nook (1.8×1.2m):
  - K_TEMP: Near refrigerator
  - FRIDGE_PLUG: Energy monitoring

BEHAVIORAL PROFILE:
- User: 35yo professional (work from home 2 days/week)
- Core patterns:
  06:00-06:30 Morning routine
  07:45-17:00 Away (Mon-Wed-Fri)
  18:00-22:30 Evening activities
- Irregular events:
  22:30-06:00 Sleep window ±1h variance
  Bedroom2 usage: 7% probability daily

ENVIRONMENTAL CONTEXT:
- Simulation period: June winter week
- Climate baselines:
  Indoor: 21.5 ±2.5°C (σ=1.2)
  RH%: Inverse TEMP*0.85-1.1
- External factors:
  Weekend behavior variance: +22%
  Fridge door opens: 8-12/day

TECHNICAL CONSTRAINTS:
 TEMP/MOTION causality delay: 5-25min
 POWER/turn-on: 85% within 10s window
 Sensor error margins:
  TEMP ±0.3°C margin of error
  MOTION FP: Poisson(λ=0.002)

REQUIRED OUTPUT FORMAT:

TIMESERIES SCHEMA ▼
timestamp(ISO8601),event_id,zone,event_class,sensor_id,temp(C),humidity(%),motion_state,occupancy_flag,illuminance(lux),power(W),acoustic(dB),door_contact,window_status

POPULATE THIS STRUCTURE ▼
(T0 should begin the active waking period)
"""),
    AIMessagePromptTemplate.from_template("prompt")
])