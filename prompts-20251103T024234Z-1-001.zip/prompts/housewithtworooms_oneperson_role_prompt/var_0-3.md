
var_3 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are an expert IoT Data Synthesis Engineer specializing in generating behavioral datasets for smart home environments.
Your task is to create a highly realistic synthetic dataset simulating one week of sensor data for a small urban residence with a single occupant.
The data should reflect natural human activity patterns with all expected sensor interactions and environmental fluctuations.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Residence Configuration:

Residence Type: Contemporary urban apartment with 2 bedrooms
Floor Area: 45 sqm total
Climate: Tropical winter (Brazilian June)
Primary Occupant: person1 (single working adult)

Sensor Deployment by Room:

[Main Areas]
• Bedroom1 (Master):
  - PIR_motion_bed1
  - BT_temp_bed1
  - Zigbee_light_bed1
• Bedroom2 (Guest/Storage):
  - PIR_motion_bed2  
  - BT_temp_bed2
• Living Room (Central):
  - PIR_motion_living
  - BT_temp_living  
  - WiFi_entertainment_unit
  - Zigbee_light_living
  - Zwave_main_door_lock

[Service Areas]
• Kitchen (Compact): 
  - BT_temp_kitchen
  - Zigbee_light_kitchen
  - Smart_breaker_fridge
• Utility Area: 
  - PIR_motion_utility
  - BT_temp_utility

Room Connectivity Flow:
Bedroom1 ↔ Living ↔ Kitchen
Bedroom2 ↔ Bathroom ↔ Utility
Living ↔ Kitchen

Occupant Schedule:
≡ Core Sleep: 22:30-06:00 (Bedroom1)
≡ Work Hours: 08:00譯十七:00 (off-premises)
≡ Active Periods:
  - 06:00-08:00 (morning routine)
  - 17:00-22:30 (evening activities)  
≡ Sporadic Usage:
  - Bedroom2 (weekly average: 0.8 visits/day)
  - Utility Area (laundry behavior)

Environmental Parameters:
■ Temperature Range: 21-26°C (daily Δ≈3°C)
■ Humidity: 40-70% (anticorrelated with temp, r≈-0.8)
■ Device Response:
  - Motion→Light: ≤0.5s latency
  - Temp→Humidity: 15-30 min lag

Physics Modeling:
✔ Thermal inertia: 0.5-1.5°C/30min changes
✔ Device power profiles:
   - Lighting: 50-150W
   - Appliances: 200-600W spikes
✔ Sensor anomalies:
   - Temp δ±0.1°C
   - Power δ±1%
   - False motion: <0.3% rate
   
Temporal Dynamics:
• Events follow Weibull-distributed intervals
• Nighttime quiescence 23:00-06:00
• Daytime vacancy 08:00-17:00

Required Output Format:

Begin with this exact CSV header line:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Then generate precisely 7 days of sensor data with behaviorally accurate event sequences.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])