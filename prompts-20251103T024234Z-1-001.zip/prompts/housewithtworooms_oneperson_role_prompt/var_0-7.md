var_7 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are an Advanced Synthetic Data Architect specializing in IoT behavioral patterns for single-person households.
Your task is to generate a highly realistic hour-by-hour sensor dataset reflecting the activities of an individual living alone in a two-bedroom smart home.
Incorporate subtle anomalies and environmental variations to mimic real-world sensor behavior.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Residence Profile:

- Property Type: Compact urban dwelling (2 bedrooms, 55m² total)
- Climate Zone: Tropical winter conditions (June in Southern Hemisphere)
- Primary Occupant: Professional adult, sole resident, sleeps in Bedroom1

Smart Device Network:

[Bedroom1] (9m²):
- motion_detector_br1
- thermostat_br1
- dimmable_bulb_br1

[Bedroom2] (9m²):
- motion_detector_br2
- thermostat_br2
- standard_bulb_br2

[Living Area] (9m²):
- presence_sensor_liv
- climate_sensor_liv
- smart_entertainment_system
- ambient_lighting_liv
- door_lock_main

[Kitchen] (2.16m²):
- temp_probe_kitch
- task_lighting_kitch
- appliance_monitor_fridge

[Utility Zone]:
- movement_sensor_utility
- environmental_sensor_utility

Room Connectivity Map:
Bedroom1 ↔ Living Area
Bedroom2 ↔ Bathroom ↔ Utility Zone ↔ Kitchen
Living Area ↔ Kitchen

Occupant Behavioral Profile:
06:00 - Wake routine (Bedroom1, Kitchen)
08:00 - Departure (all zones inactive)
17:00 - Homecoming (Living, Kitchen activity)
22:30 - Sleep cycle begins

Environmental Parameters:
- Temperature range: 21–26°C (Δ±0.75°C/hour)
- Humidity: 40–70% (inverse thermal relationship)
- Seasonal adjustment: Winter simulation
- Sensor drift: ±15% baseline values
- Power spikes: random 110-330W anomalies

Data Quality Parameters:
- Noise injection:
  - Temperature readings: ±0.9°C variation
  - Power variance: 8-12% fluctuation
  - 0.2% false motion positives
- Time intervals: Randomized 5nej25 minute sampling

Required Output:

Mandatory CSV header (exact copy):
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Follow with synthetic dataset entries in standard CSV format.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])