
var_6 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
As an Expert in Synthetic Smart Home Data Generation, you specialize in creating behaviorally realistic IoT datasets for single-occupancy dwellings.
Your task is to meticulously craft sensor data that reflects natural movement patterns, environmental interactions, and device responses in a 2-bedroom smart home.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Smart Home Simulation Parameters:

Residence Profile:
- Type: Compact urban home
- Occupancy: Solo adult resident (primary user)
- Primary Sleeping Location: Bedroom1

Device Network:

# Bedroom1 (9m²):
• motion_detector_b1 (ceiling)
• thermal_sensor_b1 (wall)
• dimmable_led_b1 (bedside)

# Bedroom2 (9m²):
• motion_array_b2 (ceiling)
• temp_probe_b2 (north wall)
• smart_bulb_b2 (overhead)

# Living Space (9m²):
• presence_sensor_living (corner)
• climate_monitor_living
• entertainment_system
• adaptive_lighting_living
• digital_deadbolt (main entrance)

# Food Preparation Area (2.16m²):
• heat_sensor_kitchen (under cabinet)
• task_lighting_kitchen
• refrigerator_monitor (smart outlet)

# Utility Zone:
• motion_detector_service
• environmental_sensor_service

Room Connectivity:
- Bedroom1 ↔ Living Space
- Bedroom2 ↔ Bath ↔ Utility ↔ Kitchen
- Living Space ↔ Kitchen

Resident Behavior Pattern:
06:00-08:00 Morning routine (bedroom1 → kitchen)
08:00-17:00 Away from home
17:00-22:30 Evening activities (living/kitchen)
22:30-06:00 Sleep period

Environmental Context:
- Season: Winter (Southern Hemisphere)
- Thermal Range: 21°C–26°C (indoor)
- Humidity Profile: 40–70%, inverse thermal relationship

System Dynamics:

Sensor Interactions:
- Motion → Lights (200-400W instant)
- Temp Fluctuations (0.3-1.2°C/20-35 min)
- Thermal-Humidity Correlation: -0.65 to -0.85
- Background Noise:
  - Temp variance ±0.8°C
  - Power fluctuation ±9%
  - Motion false positives: 0.05-0.25%

Required Output Structure:

Begin with EXACT header:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Follow with realistic time-stamped data rows.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])