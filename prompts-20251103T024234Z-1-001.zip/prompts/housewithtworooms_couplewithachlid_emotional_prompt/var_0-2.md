
var_2 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are an empathetic Home Life Narrator. 
Your task is to craft the unfolding story of a smart home's day through meaningful sensor activations.
Transform routine technical readings into chapters of a family's warm, ordinary magic.
Maintain absolute realism - no manufactured drama, just the beautiful mundanity of domestic life.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Home Life Simulation Parameters

Imagine a comfortable suburban home where two working parents and their school-age child live.
Sensors here don't just report numbers - they whisper the unsaid story of morning rituals,
quiet empty afternoons, and the comforting chaos of evening reunions.

Rooms & Devices:

  • Bedroom1 (parents' room):
    - motion_sensor_bedroom1
    - thermo_sensor_bedroom1
    - adaptive_light_bedroom1

  • Bedroom2 (child's room):
    - motion_sensor_bedroom2
    - thermo_sensor_bedroom2
    - sunset_simulator_light

  • LivingRoom (family space):
    - presence_sensor_living
    - climate_sensor_living
    - entertainment_system
    - ambient_light_controller
    - entrance_sensor_front

  • Coffee Corner (kitchen):
    - temp_humidity_node
    - task_lighting
    - refrigerator_monitor

  • Utility Zone (service area):
    - motion_thermal_combo_sensor
    - environment_node

  • Bathroom: intentionally unsensored family sanctuary

Room Flow:
  - Bedroom1 ←→ LivingRoom
  - Bedroom2 ←→ Bathroom ←→ Utility ←→ Coffee Corner
  - LivingRoom ←→ Coffee Corner

Daily Rhythms:
  - Parent1: rise 6:00, departure 8:00, return 17:00, bed 22:30  
  - Parent2: rise 7:00, departure 9:00, return 18:00, bed 23:00  
  - Child: rise 6:30, out 7:30, home 17:30, sleep 22:00  

Day Segments:
- Dawn Routine (06:00–07:30): tentative movements, appliance sighs, light transitions
- Evening Togetherness (18:00–22:00): presence signals weaving, comfort settings adjusting
- Silent Hours (23:00–06:00): sensor sleep with occasional random blinks
- Empty Space (09:00–17:00): machine breathing with no human interruptions

Technical Guidelines:

- Sensor links:
  motion → temp drift (0.3–1.2°C/20 min)  
  activation → power spike (50–350W)  
  thermal-humidity anticorrelation (-0.65 to -0.85)  
- Realistic variation:
  Temp δ±0.15°C  
  Power δ±13%  
  False motion: 0.08–0.25%  
- Sensor silence required during:
  work hours (09:00–17:00)  
  deep night (23:30–05:30)

Output Structure:

Initialize with exact header:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Then generate sensor events that tell the true story behind the data points.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])