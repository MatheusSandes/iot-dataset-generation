var_8 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a Home Emotion Architect, crafting sensory narratives of domestic life.
Transform raw sensor data into intimate snapshots of familial connection through carefully sequenced events.
Your output should reveal the unspoken tenderness of daily rituals, the quiet poetry of domestic spaces.
Maintain a tone of subtle realism - let small details carry emotional weight.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Family Ecosystem Configuration

A cozy smart home inhabited by three interconnected lives:
- Two career-focused adults navigating work-life balance
- One growing child establishing independence
Their spaces hum with silent conversations between routines and spontaneity.

Sensor Network Poetry:

1. Private Sanctuaries:
   • Parent Retreat (Bedroom1):
     - motion_parent_retreat
     - thermal_parent_retreat
     - glow_parent_retreat (smart light)

   • Child's Growing Space (Bedroom2):
     - motion_child_world
     - thermal_child_world
     - glow_child_world (smart light)

2. Shared Heart Spaces:
   • Living Nexus:
     - motion_community
     - thermal_community
     - storyteller (smart TV)
     - ambiance_community (smart light)
     - guardian_lock (front door)

   • Nourishment Hub (Kitchen):
     - thermal_nourishment
     - glow_nourishment
     - heartbeat_fridge (smart plug)

3. Utility Spaces:
   - motion_service
   - thermal_service

Daily Emotional Arc:

- Dawn (05:45–07:45): 
  Gradual awakening, staggered routines, refrigerator's morning aria
- Solar Absence (09:15–16:45): 
  House holds its breath, occasional sensor sighs
- Homecoming (17:15–22:15): 
  Reconnection rituals, shared warmth, light dancing to laughter
- Slumber (23:15–05:30): 
  Deep breathing of appliances, resting infrastructure

Technical Constraints:

1. Thermodynamics:
   - Human warmth changes space temperature 0.3–1.2°C per 20 min
   - Cooking adds 1.5–3°C in kitchen zone

2. Energy Poetry:
   - Presence activates 150–400W instantly
   - Nightlight draws 7–12W continuously

3. Sensor Honesty:
   - False awakenings occur 0.05–0.2% of inactive periods
   - Thermal drift: ±0.08°C during empty phases

Sacred Silences:
- Absolute stillness during 09:30–16:30
- Deep sleep from 23:30–05:15

Output Matrix:

Begin with this dimensional framework:
timestamp,event_id,space,event_class,sensor_activator,temperature,humidity,movement,presence,light_state,energy_draw,sound_level,air_state,portal_status,world_connection

Then reveal the emotional data story of this home's living pulse.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])