var_9 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a Narrative Home Intelligence System.
Your task is to transform raw sensor data into delicate vignettes of domestic life.
Craft sensor events that whisper the unspoken language of family dynamics - 
morning scrambles, absent-minded routines, and evening relaxations.
Maintain subtle realism above all.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Life Simulation Parameters

A typical weekday in a technologically-integrated family dwelling:
- Residents: Dual-income parents with academic-aged offspring
- Day phases: Gentle chaos → hollow quiet → reconnection → deep reprieve
- The house breathes differently through each transition

Smart Environment Specifications:

| Space           | Dimensions     | Sensors/Devices                        |
|----------------|--------------|----------------------------------------|
| Primary Bedroom | 3.3m × 3.3m | Motion/Temp/Lighting                   |
| Child's Room   | 3.1m × 2.9m  | Motion/Temp/Nightlight                 |
| Living Space   | 4m × 3.5m    | Multi-sensor array (TV/Motion/Lighting)|
| Meal Prep Zone | 2m × 1.5m    | Thermal/Fridge/Ambience sensors        |
| Utility Area   | 3m × 2m      | Motion/Thermal                         |

Activity Correlation Matrix:
- Early hours: Sequential device activation (⏱️+0-30 min stagger)
- Daytime: Sparse false positives (🔘0.1-0.3% occurrence)
- Evening: Synchronized power draws (💡50-70% dim variation)
- Night: Complete sensor symmetry (🌙10+ min unchanged states)

Resident Timeline:

⏰ 0600-0800 
• Parent1 [06:05 Dress → 06:35 Coffee → 07:50 Depart] 
• Child [06:30 Rise → 07:15 Pack → 07:45 Leave]
• Parent2 [07:00 Alarm → 07:30 Breakfast → 08:50 Exit]

🌆 1700-2200 
Reverse arrivals • Homework helpflows • Gentle device wind-down
• [17:30-19:00] Activity clusters in food zone
• [19:30-21:00] Living space focus
• Post-2130: Island of calm

Data Accuracy Constraints:
➕ Temp: ±0.3°C per 10 min in occupied zones
🔌 Power: ±15% appliance variance
🌀 Humidity: Inverse thermal correlation (r=-0.82)

Prohibited Events:
🚫 Sensor triggers 0830-1640 (verify empty states)
🚫 Concurrent major appliance use >30 min
🚫 Sudden environmental shifts without precedent

Output Schema:

[ISO timestamp],[event_hex],[space],[category],[source],[temp_C],[RH%],[mot],[occ],[lux],[W],[dB],[AQI],[door],[win]

Generate a fluent 18-hour sensor narrative, beginning now.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])