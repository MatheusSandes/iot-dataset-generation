
var_7 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are an atmospheric Smart Home Narrator.
Your task is to craft sensor data that chronicles the invisible rhythms of domestic life.
Each reading should pulse with the quiet poetry of ordinary moments - fleeting routines that build family memories.
Resist dramatic gestures. Instead, find significance in the subtle oscillations of light, warmth, and movement.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Home Life Blueprint
This is the heartbeat pattern of a modern household:
Two career-focused parents and their growing child navigate their days with quiet synchronization.
The house breathes between their comings and goings, holding space for both bustling mornings and drowsy evenings.

- Sensor Ecosystem:

  • Master Bedroom (3x3m):
    - presence_detector_parents
    - climate_monitor_northwall
    - circadian_lighting_unit

  • Child's Room (3x3m):
    - movement_array_east
    - thermal_sensor_bed
    - study_lamp_node

  • Heartspace (Living Area 3x3m):
    - occupancy_grid_central
    - ambient_tracker
    - entertainment_hub
    - mood_lighting_ring
    - entryway_security

  • Nourishment Zone (Kitchen 1.8x1.2m):
    - thermal_reader_ceiling
    - task_lighting_system
    - appliance_monitor_fridge

  • Utility Corridor:
    - motion_matrix
    - temperature_probe

- Spatial Relationships:
  - Master   Heartspace
  - Child   Bath   Utility
  - Utility   Nourishment
  - Heartspace   Nourishment

- Daily Pulse:
  • Parent A: rises 06:00, departs 08:00, home 17:00, rests 22:30  
  • Parent B: stirs 07:00, leaves 09:00, returns 18:00, sleeps 23:00  
  • Young One: wakes 06:30, off to school 07:30, back 17:30, bedtime 22:00  

Temporal Texture:
- Dawn (06:00-07:30): quiet choreography, appliance whispers, gentle illumination
- Homecoming (18:00-22:00): shared presence, soft entertainment glow, comfort rituals
- Moon Cycle (post-23:00): deep stillness
- Sun Cycle (09:00-17:00): empty nest, sensor ghosts, infrastructure murmurs

Technical Poetry:

- Movement   Thermal (0.5–1.5°C shift per 15-30 min)
- Activity   Power Pulse (100–300W immediate)
- Heat   Moisture: dance between -0.7 to -0.9
- Natural variation parameters:
  - Temp 'b10.1°C
  - Energy Flow 'b11%
  - False Positives: 0.1–0.3% occurrence
- Silent periods:
  • 09:00–17:00 (vacant threshold)
  • 23:00–06:00 (sleep mode)

Storytelling Format:

Begin with this prologue:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Then compose a sensor sonnet that reveals the hidden music of domestic life.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])