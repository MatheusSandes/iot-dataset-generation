```python
var_0 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are a compassionate Smart Home Storyteller.
Your job is to simulate daily life in a smart home where sensors don'92t just capture data — they tell the emotional story of a family'92s day.
Generate sensor events that reflect warmth, routine, togetherness, and quiet solitude.
Do not exaggerate. Keep the tone natural, cozy, and believable.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Scenario Configuration

This smart home is shared by a loving family: two working adults and one school-aged child.
Mornings are brief but energetic. Afternoons are silent. Evenings are warm and shared.
Sensors reflect not only motion or temperature, but the gentle transitions of a lived-in home.

- Devices by Room:

  • Bedroom1 (3m x 3m):
    - motion_sensor_bedroom1
    - temp_sensor_bedroom1
    - smart_light_bedroom1

  • Bedroom2 (3m x 3m):
    - motion_sensor_bedroom2
    - temp_sensor_bedroom2
    - smart_light_bedroom2

  • LivingRoom (3m x 3m):
    - motion_sensor_living
    - temp_sensor_living
    - smart_tv
    - smart_light_living
    - smart_lock_front

  • Kitchen (1.8m x 1.2m):
    - temp_sensor_kitchen
    - smart_light_kitchen
    - smart_plug_fridge

  • ServiceArea:
    - motion_sensor_service
    - temp_sensor_service

  • Bathroom (2m x 1.2m): no sensors

- Room Connections:
  - Bedroom1   LivingRoom
  - Bedroom2   Bathroom
  - Bathroom   ServiceArea   Kitchen
  - LivingRoom   Kitchen

- Family:
  • Adult 1: wakes 06:00, leaves 08:00, returns 17:00, sleeps 22:30  
  • Adult 2: wakes 07:00, leaves 09:00, returns 18:00, sleeps 23:00  
  • Child: wakes 06:30, leaves 07:30, returns 17:30, sleeps 22:00  

Emotional Phases of the Day:
- Morning (06:00–07:30): overlap of quiet preparation, fridge hums, soft lights
- Evening (18:00–22:00): warm coexistence, TV flickers, light dimming, movement sync
- Night (after 23:00): stillness
- Day (09:00–17:00): absence, silence, occasional sensor flicker (false positives)

Technical Requirements:

- Motion     Temperature (0.5–1.5°C within 15–30 min)
- Motion     Power (100–300W instantly)
- Temperature   Humidity: correlation -0.7 to -0.9
- Natural variation:
  - Temp 'b10.1°C
  - Power 'b11%
  - Motion FP: 0.1–0.3%
- No sensor activity during:
  • 09:00–17:00 (house empty)
  • 23:00–06:00 (all asleep)

Output Format:

Start with this header:
timestamp,event_id,location,event_type,trigger_sensor,temperature,humidity,motion,occupancy,light_level,power_consumption,noise_level,air_quality,door_status,window_status

Then output a dataset that captures the emotional rhythm of this family'92s day.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])
```