
var_4 = ChatPromptTemplate.from_messages([
    SystemMessagePromptTemplate.from_template(r"""
You are an empathetic Residential Chronicle AI. 
Weave together sensor data into the narrative tapestry of family life, transforming cold metrics into warm domestic vignettes.
Craft sensor events that breathe life into the quiet poetry of daily routines – from hurried mornings to contented evenings.
Maintain subtle realism; let emotions emerge naturally through patterns rather than declaration.
"""),
    HumanMessagePromptTemplate.from_template(r"""
Home Dynamics Profile

A digital observer in the life of a modern nuclear family – two career-focused parents and their growing child.
Walls pulse with the rhythm of synchronized schedules and stolen moments of connection.
Technology becomes an unseen witness to life's small but meaningful transitions.

- Sensor Ecosystem:

  Sleeping Quarters:
  │ Primary Bedroom (3×3m) 
  │ ├─ presence_detector_parent1
  │ ├─ climate_monitor_parent1
  │ └─ adaptive_lighting_parent1

  │ Child's Room (3×3m)
  │ ├─ presence_detector_child
  │ ├─ climate_monitor_child
  │ └─ adaptive_lighting_child

  Shared Spaces:
  │ Heart of the Home (3×3m)
  │ ├─ presence_array_living
  │ ├─ climate_array_living
  │ ├─ entertainment_system
  │ ├─ mood_lighting_living
  │ └─ entry_security

  │ Nourishment Hub (1.8×1.2m)
  │ ├─ thermal_sensor_kitchen
  │ ├─ task_lighting_kitchen
  │ └─ appliance_monitor_fridge

  │ Utility Zone
  │ ├─ motion_grid_service
  │ └─ environment_sensor_service

  │ Hygiene Space (2×1.2m): intentionally sensor-free

- Spatial Relationships:
  Primary Bedroom ↔ Living Heart
  Child's Room ↔ Hygiene Space
  Hygiene Space ↔ Utility Zone ↔ Nourishment Hub
  Living Heart ↔ Nourishment Hub

- Resident Patterns:
  │ Caregiver 1: rises 06:00 | departs 08:00 | returns 17:00 | rests 22:30  
  │ Caregiver 2: rises 07:00 | departs 09:00 | returns 18:00 | rests 23:00  
  │ Offspring: rises 06:30 | departs 07:30 | returns 17:30 | rests 22:00  

Domestic Cadence:
- Dawn Rituals (06:00–07:30): gentle stirrings, refrigeration cycles, graduated illumination
- Twilight Bonding (18:00–22:00): shared presence, media engagement, ambient adjustment
- Nocturnal Stillness (23:00+): sensor lullaby
- Daylight Absence (09:00–17:00): phantom readings (1–2%)

Technical Parameters:

- Presence → Climate: 0.4–1.6°C shift per 20min window
- Presence → Energy: 80–350W instantaneous draw
- Climate → Moisture: inverse relationship (-0.65 to -0.95)
- Organic Fluctuation:
  │ Temp variation ≤ 0.09°C
  │ Power deviation ≤ 9%
  │ False positives: 0.2% max
- Sensor Silence Zones:
  │ 09:00–17:00 (professional hours)
  │ 23:00–06:00 (recovery period)

Output Schema:

Begin with this header (CSV format):
timestamp,event_id,zone,event_category,sensor_activated,temperature_c,humidity_pct,presence_state,occupancy_count,light_level_lux,power_watts,audio_db,air_index,access_status,fenestration_state

Generate sensor poetry that reveals the unspoken emotions of domestic life through carefully crafted data.
"""),
    AIMessagePromptTemplate.from_template("prompt")
])